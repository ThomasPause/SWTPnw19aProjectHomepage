package com.oktopoi

import com.oktopoi.utility.Complex
import org.junit.Assert
import org.junit.Test
import kotlin.math.*

class ComplexTest {

    /* calculating with floating point numbers may cause rounding errors which we don't want to detect
    therefor we specify here the accuracy to which we want to test these numbers*/
    private val delta = 0.00001f

    // since we need pi as a Float number regularly, we initiate it here instead of casting PI (Double) to Float every time
    private val pi = PI.toFloat()

    // Complex numbers in cartesian coordinates to test if all functions work properly in all 4 quadrants
    private val cart1 = Pair(3f, 4f)
    private val cart2 = Pair(-1f, sqrt(3f))
    private val cart3 = Pair(-2f, -2f)
    private val cart4 = Pair(12f, -5f)

    // Complex numbers in cartesian coordinates to test if all functions work properly if coordinates are 0
    private val cart5 = Pair(0f, 0f)
    private val cart6 = Pair(0f, 1f)
    private val cart7 = Pair(0f, -0.5f)
    private val cart8 = Pair(1f, 0f)
    private val cart9 = Pair(-1f, 0f)

    // Complex number in polar coordinates to test if the functions work properly
    private val polar1 = Pair(0f, 0f)
    private val polar2 = Pair(0f, pi)
    private val polar3 = Pair(3f, 0f)
    private val polar4 = Pair(-2f, pi / 4f)
    private val polar5 = Pair(4f, -pi / 6f)
    private val polar6 = Pair(-10f, -3f * pi / 8f)
    private val polar7 = Pair(5f, 0.927295f)
    private val polar8 = Pair(3f, 3f * pi)

    @Test
    fun `test calcRadius`() {

        val radius1 = Complex.calcRadius(cart1)
        Assert.assertEquals("cart1 (3+4i)", radius1, 5f, delta)

        val radius2 = Complex.calcRadius(cart2)
        Assert.assertEquals("cart2 (-1 + i*sqrt(3))", radius2, 2f, delta)

        val radius3 = Complex.calcRadius(cart3)
        Assert.assertEquals("number3 (-2-2i)", radius3, 2 * sqrt(2f), delta)

        val radius4 = Complex.calcRadius(cart4)
        Assert.assertEquals("cart4 (12-5i)", radius4, 13f, delta)

        val radius5 = Complex.calcRadius(cart5)
        Assert.assertEquals("cart5 (0)", radius5, 0f, delta)

        val radius6 = Complex.calcRadius(cart6)
        Assert.assertEquals("cart6 (i)", radius6, 1f, delta)

        val radius7 = Complex.calcRadius(cart7)
        Assert.assertEquals("cart7 (-0.5*i)", radius7, 0.5f, delta)

        val radius8 = Complex.calcRadius(cart8)
        Assert.assertEquals("cart8 (1)", radius8, 1f, delta)
    }

    @Test
    fun `test calcAngle`() {

        val angle1 = Complex.calcAngle(cart1)
        Assert.assertEquals("cart1 (3 + 4i)", angle1, 0.92730f, delta)

        val angle2 = Complex.calcAngle(cart2)
        Assert.assertEquals("cart2 (-1 + i*sqrt(3))", angle2, 2f / 3f * PI.toFloat(), delta)

        val angle3 = Complex.calcAngle(cart3)
        Assert.assertEquals("cart3 (-2 - 2i)", angle3, 5f * pi / 4f, delta)

        val angle4 = Complex.calcAngle(cart4)
        Assert.assertEquals("cart4 (12 - 5i)", angle4, -0.39479f, delta)

        val angle5 = Complex.calcAngle(cart5)
        Assert.assertEquals("cart5 (0)", angle5, 0f, delta)

        val angle6 = Complex.calcAngle(cart6)
        Assert.assertEquals("cart6 (i)", angle6, pi / 2f, delta)

        val angle7 = Complex.calcAngle(cart7)
        Assert.assertEquals("cart7 (-i)", angle7, -pi / 2f, delta)

        val angle8 = Complex.calcAngle(cart8)
        Assert.assertEquals("cart8 (1)", angle8, 0f, delta)

        val angle9 = Complex.calcAngle(cart9)
        Assert.assertEquals("cart9 (-1)", angle9, pi, delta)
    }

    @Test
    fun `test calcReal`() {

        val real1 = Complex.calcRe(polar1)
        Assert.assertEquals("polar1 = 0*exp(0i) ", real1, 0f, delta)

        val real2 = Complex.calcRe(polar2)
        Assert.assertEquals("polar2 = 0*exp(i*pi) ", real2, 0f, delta)

        val real3 = Complex.calcRe(polar3)
        Assert.assertEquals("polar3 = 3*exp(0i) ", real3, 3f, delta)

        val real4 = Complex.calcRe(polar4)
        Assert.assertEquals("polar4 = -2*exp(i*pi/4) ", real4, -sqrt(2f), delta)

        val real5 = Complex.calcRe(polar5)
        Assert.assertEquals("polar5 = 4*exp(-i*pi/6) ", real5, 3.46410f, delta)

        val real6 = Complex.calcRe(polar6)
        Assert.assertEquals("polar 6 = -10*exp(-i*3/8*pi) ", real6, -3.82683f, delta)

        val real7 = Complex.calcRe(polar7)
        Assert.assertEquals("polar7 = 5*exp(i*0.927295) ", real7, 3f, delta)

        val real8 = Complex.calcRe(polar8)
        Assert.assertEquals("3*exp(3i*pi)", real8, -3f, delta)
    }

    @Test
    fun `test calcIm`() {

        val im1 = Complex.calcIm(polar1)
        Assert.assertEquals("polar1 = 0*exp(0i) ", im1, 0f, delta)

        val im2 = Complex.calcIm(polar2)
        Assert.assertEquals("polar2 = 0*exp(i*pi) ", im2, 0f, delta)

        val im3 = Complex.calcIm(polar3)
        Assert.assertEquals("polar3 = 3*exp(0i) ", im3, 0f, delta)

        val im4 = Complex.calcIm(polar4)
        Assert.assertEquals("polar4 = -2*exp(i*pi/4) ", im4, -sqrt(2f), delta)

        val im5 = Complex.calcIm(polar5)
        Assert.assertEquals("polar5 = 4*exp(-i*pi/6) ", im5, -2f, delta)

        val im6 = Complex.calcIm(polar6)
        Assert.assertEquals("polar 6 = -10*exp(-i*3/8*pi) ", im6, 9.23879f, delta)

        val im7 = Complex.calcIm(polar7)
        Assert.assertEquals("polar7 = 5*exp(i*0.927295) ", im7, 4f, delta)

        val im8 = Complex.calcIm(polar8)
        Assert.assertEquals("3*exp(3i*pi)", im8, 0f, delta)
    }


}