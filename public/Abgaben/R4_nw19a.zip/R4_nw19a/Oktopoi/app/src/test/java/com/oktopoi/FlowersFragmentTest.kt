package com.oktopoi

import com.oktopoi.flowers.FlowersFragment
import org.junit.Assert
import org.junit.Test


class FlowersFragmentTest {

    private val testFragment = FlowersFragment()

    @Test
    fun `validateInput regex matching`() {
        Assert.assertFalse("Value 0 should fail", testFragment.validateInput("0"))
        Assert.assertFalse("Value 05 should fail", testFragment.validateInput("05"))
        Assert.assertFalse("Value - should fail", testFragment.validateInput("-"))
        Assert.assertFalse("Value -0.5 should fail", testFragment.validateInput("-0.5"))
        Assert.assertTrue("Value -102 should pass", testFragment.validateInput("-102"))
        Assert.assertTrue("Value 99999950 should pass", testFragment.validateInput("99999950"))


    }
}
