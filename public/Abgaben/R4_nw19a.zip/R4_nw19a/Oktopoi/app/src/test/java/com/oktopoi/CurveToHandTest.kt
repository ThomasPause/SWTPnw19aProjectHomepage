package com.oktopoi

import com.oktopoi.curvetohand.CurveToHand
import kotlin.math.*
import org.junit.Assert
import org.junit.Test

class CurveToHandTest {

    /* calculating with floating point numbers may cause rounding errors which we don't want to detect
       therefor we specify here the accuracy to which we want to test these numbers */
    private val delta = 0.00001f

    // we often need pi as a Float number, therefor we initialize it here instead of casting it every time
    private val pi = PI.toFloat()

    // test curves

    private val circleX = Array(12) { t -> cos(pi * t.toFloat() / 6) }
    private val circleY = Array(12) { t -> sin(pi * t.toFloat() / 6) }
    private val circle = circleX.zip(circleY)
    private val testCircle = CurveToHand(circle, -5, 5)

    private val infinityX = Array(24) { t -> 2f * sin(pi * t / 12) }
    private val infinityY = Array(24) { t -> sin(pi * t / 6) }
    private val infinity = infinityX.zip(infinityY)
    private val testInfinity = CurveToHand(infinity, -10, 10)

    private val appleX = Array(72) { t -> 3 * (sin(pi * t / 18) + sin(pi * t / 36)) }
    private val appleY = Array(72) { t -> 3 * cos(pi * t / 18) + 2 * cos(pi * t / 36) }
    private val apple = appleX.zip(appleY)
    private val testApple = CurveToHand(apple, -3, 3)

    /*
     * This test checks for some frequencies and all 3 test curves
     * if the fourier coefficients are calculated correctly by fourier(freq),
     */
    @Test
    fun `test fourier(freq)`() {

        val fourierCircle1 = testCircle.fourier(1)
        Assert.assertEquals("circle, freq = 1, real part", fourierCircle1.first, 1f, delta)
        Assert.assertEquals("circle, freq = 1, imag part", fourierCircle1.second, 0f, delta)

        val fourierCircle2 = testCircle.fourier(-2)
        Assert.assertEquals("circle, freq = 2, real part", fourierCircle2.first, 0f, delta)
        Assert.assertEquals("circle, freq = 2, imag part", fourierCircle2.second, 0f, delta)

        val fourierInfinity1 = testInfinity.fourier(-3)
        Assert.assertEquals("infinity, freq = -3, real part", fourierInfinity1.first, 0f, delta)
        Assert.assertEquals("infinity, freq = -3, imag part", fourierInfinity1.second, 0f, delta)

        val fourierInfinity2 = testInfinity.fourier(-2)
        Assert.assertEquals("infinity, freq = -2, real part", fourierInfinity2.first, -0.5f, delta)
        Assert.assertEquals("infinity, freq = -2, imag part", fourierInfinity2.second, 0f, delta)

        val fourierInfinity3 = testInfinity.fourier(-1)
        Assert.assertEquals("infinity, freq = -1, real part", fourierInfinity3.first, 0f, delta)
        Assert.assertEquals("infinity, freq = -1, imag part", fourierInfinity3.second, 1f, delta)

        val fourierInfinity4 = testInfinity.fourier(1)
        Assert.assertEquals("infinity, freq = 1, real part", fourierInfinity4.first, 0f, delta)
        Assert.assertEquals("infinity, freq = 1, imag part", fourierInfinity4.second, -1f, delta)

        val fourierInfinity5 = testInfinity.fourier(2)
        Assert.assertEquals("infinity, freq = 2, real part", fourierInfinity5.first, 0.5f, delta)
        Assert.assertEquals("infinity, freq = 2, imag part", fourierInfinity5.second, 0f, delta)

        val fourierApple1 = testApple.fourier(-3)
        Assert.assertEquals("apple, freq = -3, real part", fourierApple1.first, 0f, delta)
        Assert.assertEquals("apple, freq = -3, imag part", fourierApple1.second, 0f, delta)

        val fourierApple2 = testApple.fourier(-2)
        Assert.assertEquals("apple, freq = -2, real part", fourierApple2.first, 0f, delta)
        Assert.assertEquals("apple, freq = -2, imag part", fourierApple2.second, 3f, delta)

        val fourierApple3 = testApple.fourier(-1)
        Assert.assertEquals("apple, freq = -1, real part", fourierApple3.first, 0f, delta)
        Assert.assertEquals("apple, freq = -1, imag part", fourierApple3.second, 2.5f, delta)

        val fourierApple4 = testApple.fourier(1)
        Assert.assertEquals("apple, freq = 1, real part", fourierApple4.first, 0f, delta)
        Assert.assertEquals("apple, freq = 1, imag part", fourierApple4.second, -0.5f, delta)

        val fourierApple5 = testApple.fourier(2)
        Assert.assertEquals("apple, freq = 2, real part", fourierApple5.first, 0f, delta)
        Assert.assertEquals("apple, freq = 2, imag part", fourierApple5.second, 0f, delta)

        val fourierApple6 = testApple.fourier(3)
        Assert.assertEquals("apple, freq = 3, real part", fourierApple6.first, 0f, delta)
        Assert.assertEquals("apple, freq = 3, imag part", fourierApple6.second, 0f, delta)

    }

    /*
     * This test examines for the 3 test curves if main frequency, radius and phase shift
     * are calculated correctly by the mainCircle() function
     */
    @Test
    fun `test mainCircle()`() {

        val mainCircle = testCircle.mainCircle()
        Assert.assertEquals("circle main frequency", mainCircle.first, 1)
        Assert.assertEquals("circle main radius", mainCircle.second, 1f, delta)
        Assert.assertEquals("circle main phase shift", mainCircle.third, 0f, delta)

        val mainInfinity = testInfinity.mainCircle()
        Assert.assertEquals("infinity main frequency", mainInfinity.first, -2)
        Assert.assertEquals("infinity main radius", mainInfinity.second, 0.5f, delta)
        Assert.assertEquals("infinity main phase shift", mainInfinity.third, pi, delta)

        val mainApple = testApple.mainCircle()
        Assert.assertEquals("apple main frequency", mainApple.first, -2)
        Assert.assertEquals("apple main radius", mainApple.second, 3f, delta)
        Assert.assertEquals("apple main phase shift", mainApple.third, pi / 2f, delta)

    }

    /*
     * This test examines for the curves testCircle and testInfinity,
     * if the calculated hand curve matches the expected one
     */
    @Test
    fun `test calcHand()`() {

        val resultCircle = testCircle.calcHand()
        val handCircle = resultCircle.second
        //val infoCircle = resultCircle.first
        for (t in 0..11) {
            Assert.assertEquals("circle t=$t, x coordinate", handCircle[t].first, 0f, delta)
            Assert.assertEquals("circle t=$t, y coordinate", handCircle[t].second, 0f, delta)
        }
        //Assert.assertEquals("circle infoText", infoCircle, "Frequenz 1 | Radius 1.0 | PhaseShift 0.0")

        val resultInfinity = testInfinity.calcHand()
        val handInfinity = resultInfinity.second
        //val infoInfinity = resultInfinity.first
        val actualInfinity = listOf(
            Pair(0.5f, 0.0f),
            Pair(0.9506507920972609f, 0.24999999999999997f),
            Pair(1.25f, 0.43301270189221935f),
            Pair(1.414213562373095f, 0.5f),
            Pair(1.4820508075688772f, 0.43301270189221935f),
            Pair(1.4988389506859172f, 0.25f),
            Pair(1.5f, 0.0f),
            Pair(1.4988389506859172f, -0.2499999999999998f),
            Pair(1.4820508075688772f, -0.43301270189221913f),
            Pair(1.4142135623730951f, -0.5f),
            Pair(1.25f, -0.43301270189221935f),
            Pair(0.9506507920972613f, -0.2500000000000003f),
            Pair(0.5000000000000002f, 0.0f),
            Pair(-0.08462538831282229f, 0.24999999999999994f),
            Pair(-0.7499999999999992f, 0.4330127018922192f),
            Pair(-1.4142135623730938f, 0.5f),
            Pair(-1.9820508075688763f, 0.43301270189221963f),
            Pair(-2.364864354470356f, 0.24999999999999994f),
            Pair(-2.5f, 0.0f),
            Pair(-2.3648643544703565f, -0.24999999999999953f),
            Pair(-1.982050807568877f, -0.4330127018922193f),
            Pair(-1.4142135623730956f, -0.5f),
            Pair(-0.7500000000000013f, -0.4330127018922196f),
            Pair(-0.08462538831282418f, -0.2500000000000008f)
        )

        for (t in 0..23) {

            Assert.assertEquals(
                "infinity t=$t, x coordinate",
                handInfinity[t].first,
                actualInfinity[t].first,
                delta
            )

            Assert.assertEquals(
                "infinity t=$t, y coordinate",
                handInfinity[t].second,
                actualInfinity[t].second,
                delta
            )
        }
        //Assert.assertEquals("infinity infoText", infoInfinity, "Frequenz -1 | Radius 1.0 | PhaseShift 0.0")


    }


}
