package com.oktopoi

import com.oktopoi.flowers.FlowersCalc
import com.oktopoi.library.Converter
import org.junit.Test
import org.junit.Assert


class ConverterTest {

    @Test
    fun `if stringToFlower creates the intended FlowersCalc object`() {

        val string = "1.3 2 -7 0.25"
        val result = Converter.stringToFlower(string)
        val flower = FlowersCalc(1.3f, 2, -7, 0.25f, 720)
        Assert.assertEquals(string, result.toString(), flower.toString())
    }

    @Test
    fun `if pointsToString converts a list of points into a string correctly`() {

        //arrange
        //val list1 = emptyList<Pair<Float, Float>>()
        val testList = listOf(
            Pair(1f, 0f),
            Pair(1.5f, -1.5f),
            Pair(2f, -3f),
            Pair(1f, -3.5f),
            Pair(-1.5f, -4f),
            Pair(-2f, -3f)
        )

        //act
        val result = Converter.pointsToString(testList)

        //assert
        Assert.assertEquals(
            "1.0 0.0\n1.5 -1.5\n2.0 -3.0\n1.0 -3.5\n-1.5 -4.0\n-2.0 -3.0\n", result
        )
    }


}