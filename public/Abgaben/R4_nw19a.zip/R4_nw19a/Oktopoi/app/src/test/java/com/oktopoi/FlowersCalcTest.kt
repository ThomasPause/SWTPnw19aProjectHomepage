package com.oktopoi


import com.oktopoi.flowers.FlowersCalc
import org.junit.Assert
import org.junit.Test

class FlowersCalcTest {

    /* calculating with floating point numbers may cause rounding errors which we don't want to detect
        therefor we specify here the accuracy to which we want to test these numbers*/
    private val delta = 0.0001f

    // Arrange
    private val flower0 = FlowersCalc(0.0f, 0, 0, 270f, 600)
    private val flower1 = FlowersCalc(1.5f, 0, 1, 90f, 30)
    private val flower2 = FlowersCalc(1f, 2, 0, 700f, 50)
    private val flower3 = FlowersCalc(2.7f, -4, 1, 0f, 12)
    private val flower4 = FlowersCalc(0.8f, -7, -12, -47.22f, 48)
    private val flower5 = FlowersCalc(0.001f, 12, 8, 30.9f, 120)
    private val flower6 = FlowersCalc(4f / 3f, 10, -5, 45f, 12)
    private val flower7 = FlowersCalc(1.2f, 117000, 65000, -450f, 24)
    private val flower8 = FlowersCalc(0.5f, 3, -3, 720f, 9)
    private val flower9 = FlowersCalc(1f, 1, -1, 0.999f, 20)

    /*
         * In this test we verify that the greatestCommonDivisor() function works correctly
         * cases tested: normal input, big numbers, zero input, different signs
         */
    @Test
    fun `greatestCommonDivisor to assert greatest common divisor of freq1 and freq 2`() {

        val gcd0 = flower0.greatestCommonDivisor()
        Assert.assertEquals("flower0: freq1 = 0, freq2 = 0", gcd0, 1)

        val gcd1 = flower1.greatestCommonDivisor()
        Assert.assertEquals("flower1: freq1 = 0, freq2 = 1", gcd1, 1)

        val gcd2 = flower2.greatestCommonDivisor()
        Assert.assertEquals("flower2: freq1 = 2, freq2 = 0", gcd2, 1)

        val gcd3 = flower3.greatestCommonDivisor()
        Assert.assertEquals("flower3: freq1 = -4, freq2 = 1", gcd3, 1)

        val gcd4 = flower4.greatestCommonDivisor()
        Assert.assertEquals("flower4: freq1 = -7, freq2 = -12", gcd4, 1)

        val gcd5 = flower5.greatestCommonDivisor()
        Assert.assertEquals("flower5: freq1 = 12, freq2 = 8", gcd5, 4)

        val gcd6 = flower6.greatestCommonDivisor()
        Assert.assertEquals("flower6: freq1 = 10, freq2 = -5", gcd6, 5)

        val gcd7 = flower7.greatestCommonDivisor()
        Assert.assertEquals("flower7: freq1 = 117000, freq2 = 65000", gcd7, 13000)

        val gcd8 = flower8.greatestCommonDivisor()
        Assert.assertEquals("flower8: freq1 = 3, freq2 = 3", gcd8, 3)

        val gcd9 = flower9.greatestCommonDivisor()
        Assert.assertEquals("flower9: freq1 = 1, freq2 = -1", gcd9, 1)

    }


    /*
         * this test makes sure that the xHand(t) function calculates the x position of the hand at time t correctly
         */
    @Test
    fun `xHand to assert x position of hand at time t`() {

        val xHand0 = flower0.xHand(0)
        Assert.assertEquals("flower0 (t=0)", xHand0, 1f, delta)

        val xHand1 = flower1.xHand(5)
        Assert.assertEquals("flower1 (t=5)", xHand1, 1f, delta)

        val xHand2 = flower2.xHand(30)
        Assert.assertEquals("flower2 (t=30)", xHand2, 0.30902f, delta)

        val xHand3 = flower3.xHand(15)
        Assert.assertEquals("flower3 (t=15)", xHand3, 1f, delta)

        val xHand4 = flower4.xHand(11)
        Assert.assertEquals("flower4 (t=11)", xHand4, -0.79335f, delta)

        val xHand5 = flower5.xHand(55)
        Assert.assertEquals("flower5 (t=55)", xHand5, -0.70711f, delta)

        val xHand6 = flower6.xHand(1)
        Assert.assertEquals("flower6 (t=1)", xHand6, 0.5f, delta)

        val xHand7 = flower7.xHand(0)
        Assert.assertEquals("flower7 (t=0)", xHand7, 1f, delta)

        val xHand8 = flower8.xHand(4)
        Assert.assertEquals("flower8 (t=4)", xHand8, -0.93969f, delta)

        val xHand9 = flower9.xHand(11)
        Assert.assertEquals("flower9 (t=11)", xHand9, -0.95106f, delta)
    }

    /*
         * this test makes sure that the yHand(t) function calculates the x position of the hand at time t correctly
         */
    @Test
    fun `yHand to assert y position of hand at time t`() {

        val yHand0 = flower0.yHand(0)
        Assert.assertEquals("flower0 (t=0)", yHand0, 0f, delta)

        val yHand1 = flower1.yHand(5)
        Assert.assertEquals("flower1 (t=0)", yHand1, 0f, delta)

        val yHand2 = flower2.yHand(30)
        Assert.assertEquals("flower2 (t=0)", yHand2, 0.95106f, delta)

        val yHand3 = flower3.yHand(15)
        Assert.assertEquals("flower3 (t=0)", yHand3, 0f, delta)

        val yHand4 = flower4.yHand(11)
        Assert.assertEquals("flower4 (t=0)", yHand4, 0.60876f, delta)

        val yHand5 = flower5.yHand(55)
        Assert.assertEquals("flower5 (t=0)", yHand5, 0.70711f, delta)

        val yHand6 = flower6.yHand(1)
        Assert.assertEquals("flower6 (t=0)", yHand6, 0.86603f, delta)

        val yHand7 = flower7.yHand(0)
        Assert.assertEquals("flower7 (t=0)", yHand7, 0f, delta)

        val yHand8 = flower8.yHand(4)
        Assert.assertEquals("flower8 (t=0)", yHand8, 0.34202f, delta)

        val yHand9 = flower9.yHand(11)
        Assert.assertEquals("flower9 (t=0)", yHand9, -0.30901f, delta)
    }

    /*
         * this test makes sure that the xFlower(t) function calculates the x position of the poi head at time t correctly
         */
    @Test
    fun `xFlower to assert x position of poi at time t`() {

        val xFlower0 = flower0.xFlower(0)
        Assert.assertEquals("flower0 (t=0)", xFlower0, 1f, delta)

        val xFlower1 = flower1.xFlower(5)
        Assert.assertEquals("flower1 (t=5)", xFlower1, 1.75f, delta)

        val xFlower2 = flower2.xFlower(30)
        Assert.assertEquals("flower2 (t=30)", xFlower2, 1.30901699437495f, delta)

        val xFlower3 = flower3.xFlower(15)
        Assert.assertEquals("flower3 (t=15)", xFlower3, 1f, delta)

        val xFlower4 = flower4.xFlower(11)
        Assert.assertEquals("flower4 (t=11)", xFlower4, -0.793353340291239f, delta)

        val xFlower5 = flower5.xFlower(55)
        Assert.assertEquals("flower5 (t=55)", xFlower5, -0.706240755782763f, delta)

        val xFlower6 = flower6.xFlower(1)
        Assert.assertEquals("flower6 (t=1)", xFlower6, 1.65470053837925f, delta)

        val xFlower7 = flower7.xFlower(0)
        Assert.assertEquals("flower7 (t=0)", xFlower7, 2.2f, delta)

        val xFlower8 = flower8.xFlower(4)
        Assert.assertEquals("flower8 (t=4)", xFlower8, -1.40953893117886f, delta)

        val xFlower9 = flower9.xFlower(11)
        Assert.assertEquals("flower9 (t=11)", xFlower9, -1.90211303259031f, delta)
    }

    /*
         * this test makes sure that the yFlower(t) function calculates the y position of the poi head at time t correctly
         */
    @Test
    fun `yFlower to assert y position of poi at time t`() {

        val yFlower0 = flower0.yFlower(0)
        Assert.assertEquals("flower0 (t=0)", yFlower0, 0f, delta)

        val yFlower1 = flower1.yFlower(5)
        Assert.assertEquals("flower1 (t=0)", yFlower1, 1.29904f, delta)

        val yFlower2 = flower2.yFlower(30)
        Assert.assertEquals("flower2 (t=0)", yFlower2, 0.951056516295153f, delta)

        val yFlower3 = flower3.yFlower(15)
        Assert.assertEquals("flower3 (t=0)", yFlower3, 2.7f, delta)

        val yFlower4 = flower4.yFlower(11)
        Assert.assertEquals("flower4 (t=0)", yFlower4, 1.40876142900872f, delta)

        val yFlower5 = flower5.yFlower(55)
        Assert.assertEquals("flower5 (t=0)", yFlower5, 0.70661f, delta)

        val yFlower6 = flower6.yFlower(1)
        Assert.assertEquals("flower6 (t=0)", yFlower6, 0.199358737117772f, delta)

        val yFlower7 = flower7.yFlower(0)
        Assert.assertEquals("flower7 (t=0)", yFlower7, 0f, delta)

        val yFlower8 = flower8.yFlower(4)
        Assert.assertEquals("flower8 (t=0)", yFlower8, 0.17101f, delta)

        val yFlower9 = flower9.yFlower(11)
        Assert.assertEquals("flower9 (t=0)", yFlower9, 0f, delta)
    }

    /*
         * This test verifies that calcHand() calculates the hand coordinates of flower6 correctly
         */
    @Test
    fun `calcHand() to assert list of hand coordinates`() {

        // the following values often emerge in the expected result
        val a = 0.707106781186548f
        val b = 0.258819045102521f
        val c = 0.965925826289068f

        val result6: List<Pair<Float, Float>> = listOf(
            Pair(a, a),
            Pair(-b, c),
            Pair(-c, b),
            Pair(-a, -a),
            Pair(b, -c),
            Pair(c, -b),
            Pair(a, a),
            Pair(-b, c),
            Pair(-c, b),
            Pair(-a, -a),
            Pair(b, -c),
            Pair(c, -b)
        )
        val hand6 = flower6.calcHand()

        for (i in 0 until flower6.steps) {
            Assert.assertEquals(
                "flower6: x coordinate at time $i",
                hand6[i].first,
                result6[i].first,
                delta
            )
            Assert.assertEquals(
                "flower6: y coordinate at time $i",
                hand6[i].second,
                result6[i].second,
                delta
            )
        }
    }

    /*
         * This test verifies that calcFlower() calculates the flower coordinates of flower6 correctly*/

    @Test
    fun `calcFlower() to assert list of flower coordinates`() {

        val result6: List<Pair<Float, Float>> = listOf(
            Pair(1.64991582276861f, 1.64991582276861f),
            Pair(1.02908205661623f, 1.31101788642576f),
            Pair(0.321975275429686f, -0.086273015034173f),
            Pair(0.235702260395513f, -1.64991582276861f),
            Pair(0.603911105239214f, -2.25382692800782f),
            Pair(0.620833766152375f, -1.54672014682128f),
            Pair(-0.235702260395512f, -0.235702260395515f),
            Pair(-1.54672014682127f, 0.620833766152375f),
            Pair(-2.25382692800782f, 0.603911105239215f),
            Pair(-1.64991582276861f, 0.235702260395514f),
            Pair(-0.086273015034173f, 0.321975275429686f),
            Pair(1.31101788642576f, 1.02908205661623f)
        )
        val f6 = flower6.calcFlower()

        for (i in 0 until flower6.steps) {
            Assert.assertEquals(
                "flower6: x coordinate at time $i",
                f6[i].first,
                result6[i].first,
                delta
            )
            Assert.assertEquals(
                "flower6: y coordinate at time $i",
                f6[i].second,
                result6[i].second,
                delta
            )
        }
    }

}