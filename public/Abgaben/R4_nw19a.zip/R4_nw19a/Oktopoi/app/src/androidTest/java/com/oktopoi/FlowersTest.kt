package com.oktopoi


import android.view.View
import android.view.ViewGroup
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.filters.LargeTest
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.rule.ActivityTestRule
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers.`is`
import org.hamcrest.Matchers.allOf
import org.hamcrest.TypeSafeMatcher
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/*
Agenda:
open NavigationDrawer
go to Flowers
enable hand
change radius to 1
change freq1 to 3
change freq2 to 7
change rotation to 55
click Live
Start Animation
change speed to 1/2x
pause Animation
go back
save as "1"
press OK
 */

@LargeTest
@RunWith(AndroidJUnit4ClassRunner::class)
class FlowersTest {

    @Rule
    @JvmField
    var mActivityTestRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun flowersTest() {
        //needed for delay from the splash screen
        Thread.sleep(5000)

        val appCompatImageButton = onView(
            allOf(
                withContentDescription("Open navigation drawer"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withId(R.id.appBarLayout),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton.perform(click())

        val navigationMenuItemView = onView(
            allOf(
                childAtPosition(
                    allOf(
                        withId(R.id.design_navigation_view),
                        childAtPosition(
                            withId(R.id.nav_view),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        navigationMenuItemView.perform(click())

        val appCompatButton = onView(
            allOf(
                withId(R.id.FlowerHandButton),
                childAtPosition(
                    childAtPosition(
                        withClassName(`is`("android.widget.FrameLayout")),
                        1
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton.perform(click())

        val appCompatEditText = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("0.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText.perform(replaceText("1"))

        val appCompatEditText2 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("1"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText2.perform(closeSoftKeyboard())

        val appCompatEditText3 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("1"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText3.perform(pressImeActionButton())

        val appCompatEditText4 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText4.perform(replaceText("3"))

        val appCompatEditText5 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("3"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText5.perform(closeSoftKeyboard())

        val appCompatEditText6 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("3"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText6.perform(pressImeActionButton())

        val appCompatEditText7 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("14"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText7.perform(replaceText("7"))

        val appCompatEditText8 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("7"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText8.perform(closeSoftKeyboard())

        val appCompatEditText9 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("7"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText9.perform(pressImeActionButton())

        val appCompatEditText10 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.0°"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText10.perform(replaceText("555"))

        val appCompatEditText11 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("555"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText11.perform(closeSoftKeyboard())

        val appCompatEditText12 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("555"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText12.perform(pressImeActionButton())

        val appCompatButton2 = onView(
            allOf(
                withId(R.id.FlowersLiveButton), withText("live"),
                childAtPosition(
                    childAtPosition(
                        withClassName(`is`("android.widget.FrameLayout")),
                        1
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatButton2.perform(click())

        val appCompatButton3 = onView(
            allOf(
                withId(R.id.PlayButton),
                childAtPosition(
                    childAtPosition(
                        withClassName(`is`("android.widget.FrameLayout")),
                        1
                    ),
                    2
                ),
                isDisplayed()
            )
        )
        appCompatButton3.perform(click())

        val appCompatButton4 = onView(
            allOf(
                withId(R.id.SpeedButton), withText("1/1x"),
                childAtPosition(
                    childAtPosition(
                        withClassName(`is`("android.widget.FrameLayout")),
                        1
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatButton4.perform(click())

        val appCompatButton5 = onView(
            allOf(
                withId(R.id.btnHalfSpeed), withText("1/2x"),
                childAtPosition(
                    allOf(
                        withId(R.id.LivePlaybackSpeedContainer),
                        childAtPosition(
                            withId(R.id.LiveModeParent),
                            2
                        )
                    ),
                    2
                ),
                isDisplayed()
            )
        )
        appCompatButton5.perform(click())

        val appCompatButton6 = onView(
            allOf(
                withId(R.id.PlayButton),
                childAtPosition(
                    childAtPosition(
                        withClassName(`is`("android.widget.FrameLayout")),
                        1
                    ),
                    2
                ),
                isDisplayed()
            )
        )
        appCompatButton6.perform(click())

        val appCompatImageButton2 = onView(
            allOf(
                withContentDescription("Navigate up"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withId(R.id.appBarLayout),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton2.perform(click())

        val appCompatButton7 = onView(
            allOf(
                withId(R.id.SaveButton),
                childAtPosition(
                    childAtPosition(
                        withClassName(`is`("android.widget.FrameLayout")),
                        1
                    ),
                    2
                ),
                isDisplayed()
            )
        )
        appCompatButton7.perform(click())

        val textInputEditText = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText.perform(replaceText("1"), closeSoftKeyboard())

        val appCompatButton8 = onView(
            allOf(
                withId(R.id.saveDialogButtonAccept), withText("OK"),
                childAtPosition(
                    allOf(
                        withId(R.id.saveDialogButtonContainer),
                        childAtPosition(
                            withId(R.id.saveDialogElementContainer),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton8.perform(click())
    }

    private fun childAtPosition(
        parentMatcher: Matcher<View>, position: Int
    ): Matcher<View> {

        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
                description.appendText("Child at position $position in parent ")
                parentMatcher.describeTo(description)
            }

            public override fun matchesSafely(view: View): Boolean {
                val parent = view.parent
                return parent is ViewGroup && parentMatcher.matches(parent)
                        && view == parent.getChildAt(position)
            }
        }
    }
}
