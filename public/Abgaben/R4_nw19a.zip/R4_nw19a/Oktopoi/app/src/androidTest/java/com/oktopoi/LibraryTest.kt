package com.oktopoi


import android.view.View
import android.view.ViewGroup
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.scrollTo
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.filters.LargeTest
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.rule.ActivityTestRule
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers.`is`
import org.hamcrest.Matchers.allOf
import org.hamcrest.TypeSafeMatcher
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/*
Agenda:
uncheck Flowers
uncheck Touchpad Curves
check Flowers
check Touchpad Curves
open "Church Window"
Tap on NavigationDrawer
go back to Library
open "inkblob"
Tap on NavigationDrawer
go back to Library
*/

@LargeTest

@RunWith(AndroidJUnit4ClassRunner::class)
class LibraryTest {

    @Rule
    @JvmField
    var mActivityTestRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun libraryTest() {
        //needed for delay from the splash screen
        Thread.sleep(5000)

        val appCompatCheckBox = onView(
            allOf(
                withId(R.id.flower_check_box), withText("Flowers"),
                childAtPosition(
                    allOf(
                        withId(R.id.LibraryLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatCheckBox.perform(click())

        val appCompatCheckBox2 = onView(
            allOf(
                withId(R.id.touch_pad_check_box), withText("Touchpad Curves"),
                childAtPosition(
                    allOf(
                        withId(R.id.LibraryLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatCheckBox2.perform(click())

        val appCompatCheckBox3 = onView(
            allOf(
                withId(R.id.flower_check_box), withText("Flowers"),
                childAtPosition(
                    allOf(
                        withId(R.id.LibraryLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatCheckBox3.perform(click())

        val appCompatCheckBox4 = onView(
            allOf(
                withId(R.id.touch_pad_check_box), withText("Touchpad Curves"),
                childAtPosition(
                    allOf(
                        withId(R.id.LibraryLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatCheckBox4.perform(click())

        val textView = onView(
            allOf(
                withId(R.id.libraryEntryTextView), withText("ChurchWindow"),
                childAtPosition(
                    allOf(
                        withId(R.id.library_entry_layout),
                        childAtPosition(
                            withClassName(`is`("com.oktopoi.library.LibraryEntryView")),
                            0
                        )
                    ),
                    1
                )
            )
        )
        textView.perform(scrollTo(), click())

        val appCompatImageButton = onView(
            allOf(
                withContentDescription("Open navigation drawer"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withId(R.id.appBarLayout),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton.perform(click())

        val appCompatImageButton2 = onView(
            allOf(
                withContentDescription("Open navigation drawer"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withId(R.id.appBarLayout),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton2.perform(click())

        val navigationMenuItemView = onView(
            allOf(
                childAtPosition(
                    allOf(
                        withId(R.id.design_navigation_view),
                        childAtPosition(
                            withId(R.id.nav_view),
                            0
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        navigationMenuItemView.perform(click())

        val textView2 = onView(
            allOf(
                withId(R.id.libraryEntryTextView), withText("inkblob"),
                childAtPosition(
                    allOf(
                        withId(R.id.library_entry_layout),
                        childAtPosition(
                            withClassName(`is`("com.oktopoi.library.LibraryEntryView")),
                            0
                        )
                    ),
                    1
                )
            )
        )
        textView2.perform(scrollTo(), click())

        val appCompatImageButton3 = onView(
            allOf(
                withContentDescription("Open navigation drawer"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withId(R.id.appBarLayout),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton3.perform(click())

        val navigationMenuItemView2 = onView(
            allOf(
                childAtPosition(
                    allOf(
                        withId(R.id.design_navigation_view),
                        childAtPosition(
                            withId(R.id.nav_view),
                            0
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        navigationMenuItemView2.perform(click())
    }

    private fun childAtPosition(
        parentMatcher: Matcher<View>, position: Int
    ): Matcher<View> {

        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
                description.appendText("Child at position $position in parent ")
                parentMatcher.describeTo(description)
            }

            public override fun matchesSafely(view: View): Boolean {
                val parent = view.parent
                return parent is ViewGroup && parentMatcher.matches(parent)
                        && view == parent.getChildAt(position)
            }
        }
    }
}
