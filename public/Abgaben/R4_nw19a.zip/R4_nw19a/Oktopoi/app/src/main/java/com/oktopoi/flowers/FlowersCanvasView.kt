package com.oktopoi.flowers

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.graphics.Paint.ANTI_ALIAS_FLAG
import androidx.core.content.ContextCompat
import com.oktopoi.R
import com.oktopoi.utility.CanvasView
import com.oktopoi.utility.scalePath
import com.oktopoi.utility.translatePath
import java.lang.Exception

/**
 * Class to show and animate hand and flower path. Inherits all path functions from CanvasView
 *
 * @property showHand indicates if hand curve visualization shall be displayed
 * @property renderThread thread for drawing onto canvas
 * @property running indicates if renderThread is running
 * @property flowerPath path of flower coordinates
 * @property handPath path of hand coordinates
 * @property padding distance to screen margin in percent of screensize
 *
 */
@SuppressLint("ViewConstructor")
class FlowersCanvasView(context: Context?, viewSize: Pair<Int, Int>) :
    CanvasView(context, viewSize), Runnable {

    var showHand = false

    private var renderThread = Thread(this)
    private var running = false

    private var flowerPath: Path = Path()
    private var handPath: Path = Path()

    override val padding = 0.05f

    /* Defines flower visual appearance. */
    private val flowerPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(getContext().applicationContext, R.color.color_flower)
        style = Paint.Style.STROKE
        strokeWidth = baseStrokeWidth
        alpha = 200
        pathEffect = CornerPathEffect(10f)
    }

    /* Defines hand curve visual appearance. */
    private val handPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(getContext().applicationContext, R.color.colorAccent)
        style = Paint.Style.STROKE
        strokeWidth = baseStrokeWidth
    }

    /**
     * updateFlowerAndHand uses the pointsToPath-method for converting the lists of flower and hand
     * coordinates to a separate path each. These two paths are then merged into the combinedPath object
     * in order to get the control points of the entire contour's enclosing rectangle (a RectF object).
     *
     * Since the flower/hand contour initially is placed in the upper left corner of the canvas and its size
     * hasn't yet been adjusted to the canvas size, it needs to be scaled and relocated. The first step to scaling
     * is realized by calling getScaleFactor.
     *
     * Due to the asymmetrical shape of some flowers, their actual enclosing
     * rectangle's center can differ from the canvas' 0,0 position and thus scaling the path will also change
     * such a center point's coordinates.
     * However, the center of the scaled path is needed as reference point for correctly placing any flower form in the
     * middle of the canvas. Therefore the scale factor needs to be taken in account when translatePath (which handles the
     * path's relocating) is called. This is realized by calculating in advance where scaling will put the center of the
     * path and storing it in combinedPathCenterScaled, which later is given as argument for translatePath.
     *
     * The flower and hand paths are scaled and put in the
     * center of the canvas separately. The combined path is not used so that users can choose to view the flower only.
     *
     * @param flowerPointList list of flower coordinates (pairs of x,y positions)
     * @param handPointList list of hand coordinates (pairs of x,y positions)
     */

    fun update(
        flowerPointList: List<Pair<Float, Float>>,
        handPointList: List<Pair<Float, Float>>
    ) {
        flowerPath = pointsToPath(flowerPointList)
        handPath = pointsToPath(handPointList)
        val combinedPath = Path()
        combinedPath.apply {
            addPath(flowerPath)
            addPath(handPath)
        }

        val combinedPathBounds = RectF()
        combinedPath.computeBounds(combinedPathBounds, true)
        val combinedPathBoundsCenter =
            Pair(combinedPathBounds.centerX(), combinedPathBounds.centerY())

        val scaleFactor = getScaleFactor(combinedPathBounds)

        flowerPath.apply {
            scalePath(scaleFactor, padding, combinedPathBoundsCenter)
            translatePath(combinedPathBoundsCenter, canvasWidth, canvasHeight)
        }

        handPath.apply {
            scalePath(scaleFactor, padding, combinedPathBoundsCenter)
            translatePath(combinedPathBoundsCenter, canvasWidth, canvasHeight)
        }
    }

    /**
     * draw creates a canvas object to be drawn on via the SurfaceHolder's lockCanvas-method.
     * The flower and if required the hand curve will be drawn and, as soon as unlockCanvasAndPost
     * is called, shown on the surface.
     */
    override fun draw() {
        if (holder.surface.isValid) {
            canvas = holder.lockCanvas()

            canvas.drawPaint(backgroundPaint)

            if (showHand) {
                canvas.drawPath(handPath, handPaint)
            }
            canvas.drawPath(flowerPath, flowerPaint)

            holder.unlockCanvasAndPost(canvas)
        }
    }

    override fun run() {
        while (running) {
            draw()
        }
    }

    /**
     * When FlowerFragment calls resume and running is set to true, the process of drawing onto the
     * canvas is launched by the run and draw methods. For each resume a new renderThread is created
     * and started.
     *
     */
    fun resume() {
        running = true
        if (renderThread.state == Thread.State.TERMINATED) {
            renderThread = Thread(this)
        }
        renderThread.start()
    }

    /**
     * When FlowerFragment calls pause, the main thread waits for the renderThread to terminate.
     *
     * @throws Exception
     *
     */
    fun pause() {
        running = false
        while (true) {
            try {
                renderThread.join()
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
