package com.oktopoi.drawbyhand

import android.annotation.SuppressLint
import android.graphics.RectF
import android.os.Bundle
import android.text.InputType
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.lifecycle.SavedStateViewModelFactory
import androidx.navigation.fragment.findNavController
//import androidx.navigation.fragment.navArgs
import androidx.navigation.navGraphViewModels
import com.oktopoi.MainActivity
import com.oktopoi.R
import com.oktopoi.curvetohand.CurveToHand
import com.oktopoi.library.*
import com.oktopoi.livemode.LiveModeViewModel
import com.oktopoi.utility.*
import kotlinx.android.synthetic.main.layout_drawbyhand_fragment.*

/**
 * This class allows the user to draw different closed figures with a touchpad, clear the drawing
 * and eventually calculate the figure.
 *
 * @property isLocked tells if the touch pad input is locked, default value is 'false'
 * @property libraryViewModel
 * @property liveButton button leading to LiveMode
 * @property liveModeViewModel shared ViewModel with LiveModeFragment, allows passing a Drawing to
 * LiveMode in order to animate it
 */

class DrawbyhandFragment : Fragment(R.layout.layout_drawbyhand_fragment) {


    //    private val args: DrawbyhandFragmentArgs by navArgs() -> deprecated, replaced with ViewModel
    private var isLocked = false

    private lateinit var liveButton: Button

    private val liveModeViewModel: LiveModeViewModel by navGraphViewModels(R.id.mobile_navigation)
    private val libraryViewModel: LibraryViewModel by navGraphViewModels(R.id.mobile_navigation)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //Set title bar text
        (activity as MainActivity).supportActionBar?.title =
            resources.getString(R.string.menu_drawbyhand)

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        //Set LiveModeViewModel
        liveModeViewModel.apply {
            SavedStateViewModelFactory(requireActivity().application, requireParentFragment())
        }
        //Set LibraryViewModel
        libraryViewModel.apply {
            SavedStateViewModelFactory(requireActivity().application, requireParentFragment())
        }

        liveButton = DrawByHandLiveButton
        /*set it invisible on default and show it in cases:
            1. file is loaded from library
            2. drawing is stored in the viewmodel
            3. sth was drawn on the canvas*/
        liveButton.visibility = View.INVISIBLE

        //paintView is instantiated
        val paintView = PaintView(context!!)

        /*
        DrawPaintView is just a linear layout defined within the layout xml-file, so
        paintView with all its contents is added to DrawPaintView
         */
        DrawPaintView.addView(paintView)

        //See if a File is loaded from library or a Drawing is stored in the viewModel
        if (libraryViewModel.format == FileFormat.TouchPad) {
            println("Got a curve from library")
            //case 1: file is loaded from library
            liveButton.visibility = View.VISIBLE
            val poiList = libraryViewModel.pointList

            //Get width of display (therefore width of Canvas) from displayMetrics
            val displayMetrics = DisplayMetrics()
            activity!!.windowManager.defaultDisplay.getMetrics(displayMetrics)
            val canvasWidth = displayMetrics.widthPixels

            //Scale to canvas Size
            val poiPath = genericPointsToPath(poiList)
            val bounds = RectF()
            poiPath.computeBounds(bounds, true)

            val scaleFactor = genericGetScaleFactor(bounds, canvasWidth)
            val padding = 0.10f
            val scaledPoiList = genericTransformPointsInPointList(
                poiList,
                scaleFactor,
                Pair(bounds.centerX(), bounds.centerY()),
                padding,
                canvasWidth,
                canvasWidth
            )

            //Send the scaled pointList to PaintView
            paintView.receiveDrawing(scaledPoiList)
            isLocked = true

            //reset the file in the viewModel
            libraryViewModel.format = FileFormat.Unknown
        } else if (liveModeViewModel.getCurrentDrawing() != null) {
            println("received Drawing from viewModel")
            //case 2: drawing is stored in the viewmodel
            liveButton.visibility = View.VISIBLE
            val drawing = liveModeViewModel.getCurrentDrawing()
            val poiList = drawing?.poi
            paintView.receiveDrawing(poiList!!)
            isLocked = true
        }


        /*
        1. (formerly) DrawClearButton: attach onClickListener which clears the drawing and unlocks the touchpad
        input

        2. DrawCalculateButton: attach onClickListener which eventually returns the point list of the
        sampled path from the drawing
         */
        ClearButton.setOnClickListener {
            paintView.onClear()
            //nothing there to animate
            liveButton.visibility = View.INVISIBLE
            isLocked = false
        }

        liveButton.apply {

            setOnClickListener {

                val poiList = paintView.pointList
                if (poiList.isNotEmpty()) {

                    val curveToHand = CurveToHand(poiList, -20, 20)
                    val handAndInfo = curveToHand.calcHand()
                    val handList = handAndInfo.second
                    val infoText = handAndInfo.first
                    val drawing = Drawing(handList, poiList, infoText)

                    liveModeViewModel.setCurrentObjectToAnimate(drawing)
                    liveModeViewModel.setCurrentDrawing(drawing)

                    val action =
                        DrawbyhandFragmentDirections.actionNavDrawbyhandToLiveModeFragment()
                    findNavController().navigate(action)
                }
            }
        }

        DrawByHandSaveButton.apply {
            setOnClickListener {
                val saveDialog = makeEditTextDialog {
                    setTitle(context.resources.getString(R.string.hint_save_as_dialog))
                    eText.inputType = InputType.TYPE_CLASS_TEXT
                    positiveButtonClickListener {
                        val title = getInput().toString()
                        val fileHandler = FileHandler(context, LibraryFragment.directory)

                        val pointsList = paintView.onCalculate()
                        val data = Converter.pointsToString(pointsList)

                        if (fileHandler.fileExists("$title${FileFormatStrings[FileFormat.TouchPad]}")) {
                            showToast(context.resources.getString(R.string.file_name_taken))
                        } else if (!fileHandler.isValidFileName(title)) {
                            showToast(context.resources.getString(R.string.invalid_file_name))
                        } else if (fileHandler.writeFile(
                                "$title${FileFormatStrings[FileFormat.TouchPad]}",
                                data
                            )
                        ) {
                            showToast(
                                context.resources.getString(
                                    R.string.successfully_saved_file,
                                    title
                                )
                            )
                        } else {
                            showToast(context.resources.getString(R.string.failed_to_save_file))
                        }
                    }
                    negativeButtonClickListener {}
                }
                saveDialog.show()
            }
        }


        //attach onTouchListener which allows the user to draw if the touchpad is not locked
        paintView.setOnTouchListener { _, event ->
            val posX = event.x
            val posY = event.y

            // only 'false' if you start this fragment for the first time or if you press 'clear'
            if (!isLocked) {
                //case 3: sth was drawn on the canvas
                liveButton.visibility = View.VISIBLE
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> paintView.onActionDown(posX, posY)
                    MotionEvent.ACTION_MOVE -> paintView.onActionDrag(posX, posY)
                    MotionEvent.ACTION_UP -> {
                        //after closing the path, you can't draw again until you press 'clear'
                        paintView.onActionUp()
                        isLocked = true
                    }
                }
            }
            true
        }
    }
}
