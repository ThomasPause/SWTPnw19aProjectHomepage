package com.oktopoi.utility

import android.graphics.Matrix
import android.graphics.Path
import android.graphics.RectF

/**
 * pointsToPath converts a given list of 2-dimensional coordinates to a Path object.
 * After the first tuple in the list is set as the path's starting point, an iterator over the list
 * delivers one point after the other and adds it to the path. At the end of the process, the contour of the path
 * is closed.
 *
 * @param pointList list of cartesian coordinates (pairs of x,y positions)
 * @return Path
 */
fun genericPointsToPath(pointList: List<Pair<Float, Float>>): Path {
    val path = Path()
    path.moveTo(pointList[0].first, pointList[0].second)
    for (point in pointList) {
        path.lineTo(point.first, point.second)
    }
    path.close()
    return path
}

/**
 * transformPointsInPointList scales and translates every point (coordinate) in a list
 * corresponding to a scale factor and a center point, which has to be determined beforehand
 * depending on the combined size of the poi and hand curve to be displayed.
 *
 * @param list list of coordinates
 * @param scaleFactor factor by which every point is supposed to be scaled by
 * @param center shifted center point towards which every point is supposed to be translated
 * @return the scaled and translated list of coordinates
 */
fun genericTransformPointsInPointList(
    list: List<Pair<Float, Float>>,
    scaleFactor: Float,
    center: Pair<Float, Float>,
    padding: Float,
    canvasWidth: Int,
    canvasHeight: Int
): MutableList<Pair<Float, Float>> {
    val transformedPoints = mutableListOf<Pair<Float, Float>>()
    list.forEach {
        val scale = scaleFactor * (1 - (2 * padding))

        //Scale around center of path boundary
        val centerToIt = Pair(it.first - center.first, it.second - center.second)
        val itScaled = Pair(centerToIt.first * scale, centerToIt.second * scale)

        val transX = canvasWidth / 2f
        val transY = canvasHeight / 2f

        val itTranslated =
            Pair(itScaled.first + transX, itScaled.second + transY)
        transformedPoints.add(itTranslated)
    }
    return transformedPoints
}

/**
 * getScaleFactor computes the factor by which a given rectangle needs to be
 * scaled to fit into the canvas. Between rectangle width and height, the greater value is used for
 * computing the scale factor. Since the canvas is designed to be square, the canvas width can be used
 * as numerator for either.
 *
 * @param pathBounds bounding rectangle of the path(s)
 * @return canvasWidth / scaleBy
 *
 */
fun genericGetScaleFactor(pathBounds: RectF, canvasWidth: Int): Float {
    val scaleBy = maxOf(pathBounds.width(), pathBounds.height())
    return canvasWidth.toFloat() / scaleBy
}

/**
 * scalePath scales a given path object to the desired size by calling the path class' transform-method.
 * The path is scaled around a pivot point, which is the center of the path' bounds.
 * The associated matrix object is defined to be scaled by the factor that getScaleFactor computes,
 * although factoring in a small distance to the canvas margin for design reasons.
 *
 * @param scaleFactor Float
 */
fun Path.scalePath(scaleFactor: Float, padding: Float, pivotPoint: Pair<Float, Float>) {
    val scaleMatrix = Matrix()
    val scaleFactorWithPadding = scaleFactor * (1 - padding * 2)
    scaleMatrix.setScale(
        scaleFactorWithPadding,
        scaleFactorWithPadding,
        pivotPoint.first,
        pivotPoint.second
    )
    this.transform(scaleMatrix)
}

/**
 * translatePath relocates a given path object to the middle of the canvas. For that, the distance
 * between the canvas center and the center of the path contour (which will already be scaled when
 * this method is called) is used as translating factor for the associated matrix object.
 *
 * @param center Pair<Float, Float>
 */
fun Path.translatePath(center: Pair<Float, Float>, canvasWidth: Int, canvasHeight: Int) {
    val translateMatrix = Matrix()
    translateMatrix.setTranslate(
        canvasWidth / 2f - center.first,
        canvasHeight / 2f - center.second
    )
    this.transform(translateMatrix)
}
