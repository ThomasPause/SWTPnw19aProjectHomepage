package com.oktopoi.drawbyhand

import android.content.Context
import android.graphics.*
import android.view.View
import androidx.core.content.ContextCompat
import com.oktopoi.R
import com.oktopoi.utility.genericPointsToPath
import kotlin.math.abs

/**
 * PaintView provides a canvas to draw on.
 * The parent class handles touch events and calls the corresponding functions within this class.
 *
 * @param context
 * @property drawPaint initializes drawPaint
 * @property path initializes path for drawing
 * @property pathMeasure
 * @property lastPosX last position on x-coordinate
 * @property lastPosY last position on y-coordinate
 * @property TOLERANCE min distance to last point
 * @property INCREMENT_LENGTH_FOR_SAMPLING
 * @property pointList point list of the path
 */
class PaintView(context: Context) : View(context) {

    private val drawPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(getContext().applicationContext, R.color.color_flower)
        strokeWidth = 20f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        pathEffect = CornerPathEffect(10f)
    }

    private var path: Path = Path()
    private val pathMeasure = PathMeasure()
    private var lastPosX = 0f
    private var lastPosY = 0f

    private val TOLERANCE = 4
    private val INCREMENT_LENGTH_FOR_SAMPLING = 10

    var pointList = mutableListOf<Pair<Float, Float>>()

    /**
     * onDraw renders the painted path to the canvas.
     *
     * @param canvas the canvas where the path is rendered onto
     */
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawPath(path, drawPaint)
    }

    /**
     * When the cleared view is touched, the path instance is initialized with a moveTo-order to
     * the position where the view has been touched.
     *
     * @param posX x-coordinate of the touch position
     * @param posY y-coordinate of the touch position
     */
    fun onActionDown(posX: Float, posY: Float) {
        path.moveTo(posX, posY)
        lastPosX = posX
        lastPosY = posY
    }

    /**
     * When the finger is moved across the screen, a new point is added to path (if the distance
     * to the last point is greater than TOLERANCE). This point is then connected to the last point via quadratic
     * bezier curves. Also the canvas is only redrawn if distance
     * is greater than TOLERANCE.
     *
     * @param posX x-coordinate of the touch position
     * @param posY y-coordinate of the touch position
     */
    fun onActionDrag(posX: Float, posY: Float) {
        //Calc distance to last Point
        val dx = abs(posX - lastPosX)
        val dy = abs(posX - lastPosX)

        /*
        Add a quadratic bezier from the last point, approaching control point (x1,y1),
        and ending at (x2,y2).
        */
        if (dx >= TOLERANCE || dy >= TOLERANCE) {
            path.connectPointsViaQuadraticBezier(lastPosX, lastPosY, posX, posY)
            lastPosX = posX
            lastPosY = posY
            invalidate()
        }
    }

    /**
     * When the finger is lifted, the path is closed and sampled. Also the canvas is redrawn.
     */
    fun onActionUp() {
        path.close()
        samplePath()
        invalidate()
    }

    /**
     * The path information gets cleared and the canvas is redrawn.
     */
    fun onClear() {
        path.rewind()
        pointList.clear()
        invalidate()
    }

    /**
     * A point list of the sampled path is returned.
     *
     * @return the point list of the sampled path
     */
    fun onCalculate(): List<Pair<Float, Float>> {
        return pointList
    }

    /**
     * Sets the current path to a PointList that is coming from either the library or is a drawing
     * by the user, that has been stored temporarily, so it is still available when navigating
     * back to DrawByHand from LiveMode
     * stored
     *
     * @param pointList list of coordinates
     */
    fun receiveDrawing(pointList: List<Pair<Float, Float>>) {
        path = genericPointsToPath(pointList)
        samplePath()
        invalidate()
    }

    /*
     * The path is sampled with a certain resolution defined by INCREMENT_LENGTH_FOR_SAMPLING.
     * The sampled points are stored in a list as a pair of Floats.
     * Simultaneously a new path object is created and built up with the sampled points.
     * In the end the original path is overwritten with the sampled one, which has a
     * smoothing effect on the path when displayed.
     */
    private fun samplePath() {
        pointList.clear()
        val sampledPath = Path()
        val incrementLength = INCREMENT_LENGTH_FOR_SAMPLING
        pathMeasure.setPath(path, false)
        val resolution = (pathMeasure.length / incrementLength).toInt()

        for (i in 0..resolution) {
            val sampledPoint = FloatArray(2)
            pathMeasure.getPosTan(i * incrementLength.toFloat(), sampledPoint, null)
            pointList.add(Pair(sampledPoint[0], sampledPoint[1]))

            if (i == 0) {
                sampledPath.moveTo(sampledPoint[0], sampledPoint[1])
            } else {
                val lastPoint = pointList[i - 1]
                sampledPath.connectPointsViaQuadraticBezier(
                    lastPoint.first,
                    lastPoint.second,
                    sampledPoint[0],
                    sampledPoint[1]
                )
            }
        }
        path = sampledPath
    }

    /*
     * Extends Path functionality. Connect two Points via Quadratic Bezier Curve.
     *
     * @param fromX x-coordinate of the origin point
     * @param fromY y-coordinate of the origin point
     * @param toX x-coordinate of the target point
     * @param toY y-coordinate of the target point
     */
    private fun Path.connectPointsViaQuadraticBezier(
        fromX: Float, fromY: Float, toX: Float, toY: Float
    ) {
        this.quadTo(fromX, fromY, (fromX + toX) / 2, (fromY + toY) / 2)
    }
}
