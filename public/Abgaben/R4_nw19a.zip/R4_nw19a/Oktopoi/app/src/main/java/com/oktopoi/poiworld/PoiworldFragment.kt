package com.oktopoi.poiworld

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.oktopoi.MainActivity
import com.oktopoi.R

/**
 * This class inflates additional texts about Poi for the user.
 * */
class PoiworldFragment : Fragment(R.layout.layout_poiworld_fragment) {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //Set title bar text
        (activity as MainActivity).supportActionBar?.title =
            resources.getString(R.string.menu_poiworld)

        return super.onCreateView(inflater, container, savedInstanceState)
    }
}