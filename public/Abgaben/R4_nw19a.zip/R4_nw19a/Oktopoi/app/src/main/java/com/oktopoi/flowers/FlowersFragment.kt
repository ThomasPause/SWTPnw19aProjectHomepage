package com.oktopoi.flowers

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.ImageView
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.SavedStateViewModelFactory
import androidx.navigation.fragment.navArgs
import androidx.navigation.navGraphViewModels
import com.oktopoi.MainActivity
import com.oktopoi.R
import com.oktopoi.library.*
import com.oktopoi.utility.makeEditTextDialog
import com.oktopoi.utility.showToast
import kotlinx.android.synthetic.main.layout_flower_fragment.*
import androidx.navigation.fragment.findNavController
import com.oktopoi.livemode.LiveModeViewModel
import kotlinx.android.synthetic.main.layout_flower_fragment.SaveButton

/**
 * This class handles all the user-interface, user-input, visual output and calculations for the
 * flower-functionality.
 *
 * @property flowersCalc instance of FlowerCalc-class, that handles calculation of the flower
 * @property flowerCanvasView instance of FlowerCanvasView-class, that provides canvas for the
 * flower to be drawn and animated on
 *
 * @property etRadius editText-view that accepts decimal input for the flower radius
 * @property etFreq1 editText-view that accepts whole number input for the inner frequency
 * @property etFreq2 editText-view that accepts whole number input for the outer frequency
 * @property etOffset editText-view that accepts decimal input for the rotation offset
 * @property ivShowHand image-view that allows for showing the hand movement or not
 *
 * default values for flower parameters to have a flower ready when activity is called
 * @property radius radius
 * @property freq1 inner frequency
 * @property freq2 outer frequency
 * @property offset rotation offset
 * @property lastFreq1 stores the last valid user input for inner frequency
 * @property lastFreq2 stores the last valid user input for outer frequency
 * @property lastOffset stores the last valid user input for offset
 */
class FlowersFragment : Fragment(R.layout.layout_flower_fragment) {

    private val args: FlowersFragmentArgs by navArgs()

    private lateinit var flowersCalc: FlowersCalc
    private lateinit var flowerCanvasView: FlowersCanvasView

    private lateinit var etRadius: EditText
    private lateinit var etFreq1: EditText
    private lateinit var etFreq2: EditText
    private lateinit var etOffset: EditText
    private lateinit var ivShowHand: ImageView

    private var radius = 0.5f
    private var freq1 = 2
    private var freq2 = 14
    private var offset = 0f

    private var lastRadius = radius.toString()
    private var lastFreq1 = freq1.toString()
    private var lastFreq2 = freq2.toString()
    private var lastOffset = offset.toString()

    private var maxRadius = 3f

    private lateinit var displayMetrics: DisplayMetrics

    private var primaryButtonColor: Int? = null
    private var secondaryButtonColor: Int? = null

    private val mViewModel: LiveModeViewModel by navGraphViewModels(R.id.mobile_navigation)

    private val libraryViewModel: LibraryViewModel by navGraphViewModels(R.id.mobile_navigation)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        displayMetrics = DisplayMetrics()
        activity!!.windowManager.defaultDisplay.getMetrics(displayMetrics)

        //Set title bar text
        (activity as MainActivity).supportActionBar?.title =
            resources.getString(R.string.menu_flowers)

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        //Set ViewModel
        mViewModel.apply {
            SavedStateViewModelFactory(requireActivity().application, requireParentFragment())
        }

        primaryButtonColor = ContextCompat.getColor(context!!, R.color.textColor)
        secondaryButtonColor = ContextCompat.getColor(context!!, R.color.colorAccent)

        /*Check if there is a flower stored in the ViewModel; if so, display that, if not display
        the default flower, which by now still comes from the navArgs*/
        //TODO("Change inner Fragment communication to ViewModels")

        val flowerFromViewModel = mViewModel.getCurrentFlower()
        if (flowerFromViewModel != null) {
            radius = flowerFromViewModel.radius
            freq1 = flowerFromViewModel.freq1
            freq1 = flowerFromViewModel.freq1
            freq2 = flowerFromViewModel.freq2
            offset = flowerFromViewModel.radius
        } else {
            radius = args.radius
            freq1 = args.freq1
            freq2 = args.freq2
            offset = args.offset
        }

        if (libraryViewModel.format == FileFormat.Flower) {
            radius = libraryViewModel.radius
            freq1 = libraryViewModel.freq1
            freq2 = libraryViewModel.freq2
            offset = libraryViewModel.offset

            libraryViewModel.format = FileFormat.Unknown
        }

        /*
        flowerCalc is instantiated and initialized with default values for flower parameters
        specified above.
         */
        flowersCalc = FlowersCalc(radius, freq1, freq2, offset, 1440)

        //flowerCanvasView is instantiated
        val sizeOfCanvasView = Pair(displayMetrics.widthPixels, displayMetrics.widthPixels)
        flowerCanvasView = FlowersCanvasView(context, sizeOfCanvasView)
        updateFlowerCanvasView()

        /*
        flowerCanvas is just an empty layout defined within the layout xml-file, so
        flowerCanvasView with all its contents is added to flowerCanvas.
         */
        flowerCanvas.addView(flowerCanvasView)

        /*
        The four EditText-Views for inputting the flower parameters are instantiated here.
        The procedure for every one is roughly the same:
        1. fill in the input field of the EditText with the corresponding default value

        2. attach onEditorActionListener that listens to a confirmation of user-input by
        pressing the enter-button on the soft keyboard. It triggers an update of the flower

        3. attach onFocusChangeListener that also triggers an update of the flower, when a value
        has been given but without confirming it, the user switches directly to another EditText

        for all inputs a additional check condition is implemented, to make sure,
        that a valid number has been entered. If that's not the case, but the user tries to
        confirm the input anyways, the value in the textField is reset to the last known valid value
        */
        etRadius = TextInputRadius.apply {
            setText(radius.toString())
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val input = text.toString().toFloatOrNull()
                    if (input != null) {
                        //cast user input to floating point number for consistency
                        setText(input.toString())
                        flowersCalc.radius = input
                        updateFlowerCanvasView()
                        lastRadius = input.toString()
                        radius = input
                    } else {
                        setText(lastRadius)
                        showToast(resources.getString(R.string.invalid_number_hint))
                    }
                    hideKeyboard()
                    clearFocus()
                    true
                } else {
                    false
                }
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val input = text.toString().toFloatOrNull()
                    if (input != null) {
                        //cast user input to floating point number for consistency
                        setText(input.toString())
                        flowersCalc.radius = input
                        updateFlowerCanvasView()
                        lastRadius = input.toString()
                        radius = input
                    } else {
                        setText(lastRadius)
                        showToast(resources.getString(R.string.invalid_number_hint))
                    }
                }
            }
        }

        etFreq1 = TextInputFreq1.apply {
            setText(freq1.toString())
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val userInput = text.toString()
                    if (validateInput(userInput)) {
                        flowersCalc.freq1 = userInput.toInt()
                        updateFlowerCanvasView()
                        lastFreq1 = userInput
                        freq1 = userInput.toInt()
                    } else {
                        setText(lastFreq1)
                        if (userInput == "0") {
                            showToast(resources.getString(R.string.invalid_value, 0))
                        } else {
                            showToast(resources.getString(R.string.invalid_number_hint))
                        }
                    }
                    hideKeyboard()
                    clearFocus()
                    true
                } else {
                    false
                }
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val userInput = text.toString()
                    if (validateInput(userInput)) {
                        flowersCalc.freq1 = userInput.toInt()
                        updateFlowerCanvasView()
                        lastFreq1 = userInput
                        freq1 = userInput.toInt()
                    } else {
                        setText(lastFreq1)
                        if (userInput == "0") {
                            showToast(resources.getString(R.string.invalid_value, 0))
                        } else {
                            showToast(resources.getString(R.string.invalid_number_hint))
                        }
                    }
                }
            }
        }

        etFreq2 = TextInputFreq2.apply {
            setText(freq2.toString())
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val userInput = text.toString()
                    if (validateInput(userInput)) {
                        flowersCalc.freq2 = userInput.toInt()
                        updateFlowerCanvasView()
                        lastFreq2 = userInput
                        freq2 = userInput.toInt()
                    } else {
                        setText(lastFreq2)
                        if (userInput == "0") {
                            showToast(resources.getString(R.string.invalid_value, 0))
                        } else {
                            showToast(resources.getString(R.string.invalid_number_hint))
                        }
                    }
                    hideKeyboard()
                    clearFocus()
                    true
                } else {
                    false
                }
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val userInput = text.toString()
                    if (validateInput(userInput)) {
                        flowersCalc.freq2 = userInput.toInt()
                        updateFlowerCanvasView()
                        lastFreq2 = userInput
                        freq2 = userInput.toInt()
                    } else {
                        setText(lastFreq2)
                        if (userInput == "0") {
                            showToast(resources.getString(R.string.invalid_value, 0))
                        } else {
                            showToast(resources.getString(R.string.invalid_number_hint))
                        }
                    }
                }
            }
        }

        etOffset = TextInputOffset.apply {
            setText("$offset°")
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val userInput = text.toString()
                    val input: Float?
                    input = when (userInput.takeLast(1) == "°") {
                        true -> text.toString().dropLast(1).toFloatOrNull()
                        false -> text.toString().toFloatOrNull()
                    }

                    if (input != null) {
                        setText("$input°")
                        flowersCalc.rotation = input
                        updateFlowerCanvasView()
                        lastOffset = input.toString()
                        offset = input
                    } else {
                        setText("$lastOffset°")
                        showToast(resources.getString(R.string.invalid_number_hint))
                    }
                    hideKeyboard()
                    clearFocus()
                    true
                } else {
                    false
                }
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val userInput = text.toString()
                    var input: Float?
                    input = when (userInput.takeLast(1) == "°") {
                        true -> text.toString().dropLast(1).toFloatOrNull()
                        false -> text.toString().toFloatOrNull()
                    }
                    if (input != null) {
                        setText("$input°")
                        flowersCalc.rotation = input as Float
                        updateFlowerCanvasView()
                        lastOffset = input.toString()
                        offset = input as Float
                    } else {
                        setText("$lastOffset°")
                        showToast(resources.getString(R.string.invalid_number_hint))
                    }
                }
            }
        }

        /*
        The button for showing the hand is instantiated and a onClickListener is
        attached. It is triggered when the user clicks the hand and then changes
        its status.
         */
        // ivShowHand = FlowersHandButton
        val handButton = FlowerHandButton
        handButton.apply {
            setBackgroundResource(R.drawable.ic_hand)
            //     val icHand = context?.getDrawable(R.drawable.ic_hand)
            //   ivShowHand.apply {
            //      setImageDrawable(icHand)
            setOnClickListener {
                if (flowerCanvasView.showHand) {
                    flowerCanvasView.showHand = false
                    setBackgroundResource(R.drawable.ic_hand)

                } else {
                    flowerCanvasView.showHand = true
                    setBackgroundResource(R.drawable.ic_hand_2)
                }
            }
        }
        /*If the global showHand within the view model is true,
        perform a click on the button, because the default is false.*/
        if (mViewModel.showHand) {
            handButton.performClick()
        }


        /*
        The SaveButton opens a dialog to enter a file name under which to save the flower.
         */
        SaveButton.apply {
            setOnClickListener {
                val saveDialog = makeEditTextDialog {
                    setTitle(context.resources.getString(R.string.hint_save_as_dialog))
                    eText.inputType = InputType.TYPE_CLASS_TEXT
                    positiveButtonClickListener {
                        val title = getInput().toString()
                        val fileHandler = FileHandler(context, LibraryFragment.directory)

                        if (fileHandler.fileExists("$title${FileFormatStrings[FileFormat.Flower]}")) {
                            showToast(context.resources.getString(R.string.file_name_taken))
                        } else if (!fileHandler.isValidFileName(title)) {
                            showToast(context.resources.getString(R.string.invalid_file_name))
                        } else if (fileHandler.writeFile(
                                "$title${FileFormatStrings[FileFormat.Flower]}",
                                flowersCalc.toString()
                            )
                        ) {
                            showToast(
                                context.resources.getString(
                                    R.string.successfully_saved_file,
                                    title
                                )
                            )
                        } else {
                            showToast(context.resources.getString(R.string.failed_to_save_file))
                        }
                    }
                    negativeButtonClickListener {}
                }
                saveDialog.show()
            }
        }

        FlowersLiveButton.setOnClickListener {

            //Before navigating to LiveMode set the CurrentObjectToAnimate to the currentFlower
            mViewModel.getCurrentFlower()?.let { it1 -> mViewModel.setCurrentObjectToAnimate(it1) }
            mViewModel.showHand = flowerCanvasView.showHand

            //Navigate to LiveMode
            val action = FlowersFragmentDirections.actionNavFlowersToLiveModeFragment()
            findNavController().navigate(action)
        }
    }

    /**
     * onResume is called once after the activity has been created and every time
     * the activity has been paused and is resumed again (e.g. went to background,
     * the app has lost focus to another app, etc.).
     */
    override fun onResume() {
        super.onResume()
        flowerCanvasView.resume()
    }

    /**
     * onPause is called every time the activity is paused, e.g. lost focus to another activity/app.
     * flowerCanvasView is paused then, which prevents a thread rendering on the canvas in the
     * background, even though the activity isn't even visible.
     */
    override fun onPause() {
        super.onPause()
        flowerCanvasView.pause()
    }

    /*
     * EditText.hideKeyboard makes the soft keyboard disappear after the user confirmed the input.
     * This would not happen automatically with the editText-Views.
     */
    private fun EditText.hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }

    /*
     * validateInput compares user input for the frequency parameters to a regex,
     * to make sure the input is neither "0", nor starts with "0", nor is just a "-" sign
     */
    internal fun validateInput(input: String): Boolean {
        return input.matches("-?[1-9]\\d*".toRegex())
    }

    /*
     * updateFlowerCanvasView is called every time the user changes one of the flower parameters,
     * either by inputting values in the corresponding editText-Views and switching to another
     * editText, or simply by confirming the input by clicking the enter-button on the soft keyboard.
     * Based on the altered parameters, the coordinates of the new flower are being calculated
     * within the calcFlower-instance and passed through to flowerCanvasView in order to be
     * processed there.
     * Also the ViewModel is updated with the newest Flower.
     */
    private fun updateFlowerCanvasView() {
        flowerCanvasView.update(flowersCalc.calcFlower(), flowersCalc.calcHand())
        updateViewModelWithCurrentFlower()
    }

    /*
     * sends the current Flower to the ViewModel, so it can be displayed again when the
     * user navigates back to this Fragment.
     */
    private fun updateViewModelWithCurrentFlower() {
        mViewModel.setCurrentFlower(flowersCalc)
    }
}
