package com.oktopoi.flowers

import kotlin.math.PI
import kotlin.math.absoluteValue
import kotlin.math.cos
import kotlin.math.sin

/**
 * Provides methods for calculating flower coordinates.
 *
 * @property radius ratio of the radii of the two flower circles
 * @property freq1 frequency of the hand circle
 * @property freq2 frequency of the poi circle
 * @property rotation rotation of the flower on the x-y-plane in degree
 * @property steps number of steps used to calculate the flower coordinates
 */
class FlowersCalc(
    var radius: Float,
    var freq1: Int,
    var freq2: Int,
    var rotation: Float,
    var steps: Int
) {
    private val pi = PI.toFloat()

    /*
     * This function calculates the greatest common divisor of the 2 frequencies.
     * Since only the ratio of these frequencies is relevant for the hand and flower curve,
     * we might as well divide freq1 and freq2 by their greatest common divisor whenever they appear.
     * This way we ensure that every point along the flower path is calculated exactly once
     * to avoid division by 0. This function evaluates to 1 if one of the frequencies is 0.
     */
    internal fun greatestCommonDivisor(): Int {
        var f1: Int = freq1.absoluteValue
        var f2: Int = freq2.absoluteValue
        if (f1 * f2 == 0) {
            return 1
        }
        while (f1 != f2) {
            if (f1 < f2) {
                f2 -= f1
            } else {
                f1 -= f2
            }
        }
        return f1
    }

    /*
     * xHand calculates the x coordinate of the hand position at a given time t by the formula
     *
     * xHand(t) = cos(2*PI*t*f1/steps)
     *
     * where f1 is freq1/gcd (frequency 1 divided by the greatest common divisor of the 2 frequencies)
     * and steps is the number of points along the hand path we are going to calculate.
     */
    internal fun xHand(time: Int): Float {
        val t = time.toFloat()
        val f1 = (freq1 / greatestCommonDivisor()).toFloat()
        return cos(2f * pi * t * f1 / steps.toFloat())
    }

    /*
     * yHand calculates the y coordinate of the hand position at a given time t by the formula
     *
     * yHand(t) = sin(2*PI*t*f1/steps)
     *
     * where f1 is freq1/gcd (frequency 1 divided by the greatest common divisor of the 2 frequencies)
     * and steps is the number of points along the hand path we are going to calculate.
     */
    internal fun yHand(time: Int): Float {
        val t = time.toFloat()
        val f1 = (freq1 / greatestCommonDivisor()).toFloat()
        return sin(2f * pi * t * f1 / steps.toFloat())
    }

    /**
     * calcHand returns a list of coordinates which represent the hand curve.
     *
     * @return list of coordinates (pairs of Floats)
     */
    fun calcHand(): List<Pair<Float, Float>> {
        val rot = rotation * pi / 180f //rotation in radians
        /*
         * We first create 2 separate arrays for x and y coordinates of the poi movement respectively,
         * then zip them together in a list of coordinates (Float pairs).
         */
        val xCoord: Array<Float> = Array(steps) { t -> xHand(t) * cos(rot) - yHand(t) * sin(rot) }
        val yCoord: Array<Float> = Array(steps) { t -> xHand(t) * sin(rot) + yHand(t) * cos(rot) }
        return xCoord.zip(yCoord)
    }

    /*
     * xFlower calculates the x coordinate of the poi position at time t without rotation.
     * Since this position is obtained by the sum of the hand and the poi circle, it is calculated by the following formula
     *
     * xFlower(t) = xHand(t) + r*cos(2*PI*(t*f2/steps))
     *
     * where f2 is freq2/gcd (frequency 2 divided by the greatest common divisor of the 2 frequencies)
     * and steps is the number of points along the hand path we are going to calculate.
     * offset is a parameter that corresponds to a rotation of the flower.
     */
    internal fun xFlower(time: Int): Float {
        val t = time.toFloat()
        val f2 = (freq2 / greatestCommonDivisor()).toFloat()
        return xHand(time) + radius * cos(2.0f * PI.toFloat() * (t * f2 / steps.toFloat()))
    }

    /*
     * yFlower calculates the y coordinate of the poi position at time t without rotation.
     * Since this position is obtained by the sum of the hand and the poi circle, it is calculated by the following formula
     *
     * yFlower(t) = yHand(t) + r*sin(2*PI*(t*f2/steps))
     *
     * where f2 is freq2/gcd (frequency 2 divided by the greatest common divisor of the 2 frequencies)
     * and steps is the number of points along the hand path we are going to calculate.
     * offset is a parameter that corresponds to a rotation of the flower.
     */
    internal fun yFlower(time: Int): Float {
        val t = time.toFloat()
        val f2 = (freq2 / greatestCommonDivisor()).toFloat()
        return yHand(time) + radius * sin(2f * PI.toFloat() * (t * f2 / steps))
    }

    /**
     * calcFlower returns a list of coordinates which represent the poi movement.
     *
     * @return list of coordinates (pairs of Floats)
     */
    fun calcFlower(): List<Pair<Float, Float>> {
        val rot = rotation * pi / 180 //rotation in radians
        /*
         * We first create 2 separate arrays for x and y coordinates of the poi movement respectively.
         * since xFlower and yFlower are calculated without rotation, we have to rotate them here as well.
         */
        val xCoord: Array<Float> =
            Array(steps) { t -> xFlower(t) * cos(rot) - yFlower(t) * sin(rot) }
        val yCoord: Array<Float> =
            Array(steps) { t -> xFlower(t) * sin(rot) + yFlower(t) * cos(rot) }

        //Now the x and y coordinates are zipped together into one list of points (Float-Pairs)

        return xCoord.zip(yCoord)
    }

    /**
     * Returns a string representation of the Flower:
     * radius, freq1, freq2 and offset (space separated) (note that we don't pass steps).
     */
    override fun toString(): String {
        return "$radius $freq1 $freq2 $rotation"
    }

}