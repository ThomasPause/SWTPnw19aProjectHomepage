package com.oktopoi.library

import androidx.lifecycle.ViewModel

/**
 * LibraryFirstEntryViewModel
 *
 * ViewModel to check if the Library is entered fo the first time in the lifecycle
 * @property checker: Boolean to set the decision
 *
 */
class LibraryFirstEntryViewModel : ViewModel() {
    var checker = false
}