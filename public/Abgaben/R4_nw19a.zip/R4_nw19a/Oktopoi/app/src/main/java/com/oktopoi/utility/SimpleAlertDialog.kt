package com.oktopoi.utility

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.widget.Button
import android.widget.TextView
import com.oktopoi.R

/**
 * SimpleAlertDialog extends the BaseDialogClass and provides several Methods to show
 * a custom AlertDialog, that is based on the alert_dialog_fragment.
 * It holds a title bar, a TextView containing a message and a positive and negative button.
 *
 * @constructor
 * The constructor expects a context where the dialog is supposed to be shown in.
 *
 * @param context the context of the calling Fragment/Activity
 *
 * @property dialogView a View that will be inflated with a layout and set to the dialog via the
 * builder
 * @property builder AlertDialog.Builder that handles the creation of the dialog
 * @property titleTextView TextView that contains the title of the dialog
 * @property messageTextView TextView that contains the message of the dialog
 * @property positiveButton confirmation Button of the dialog
 * @property negativeButton cancel Button of the dialog
 */

@SuppressLint("InflateParams")
class SimpleAlertDialog(context: Context) : BaseDialogClass() {

    override val dialogView: View by lazy {
        LayoutInflater.from(context).inflate(R.layout.alert_dialog_fragment, null)
    }

    override val builder: AlertDialog.Builder = AlertDialog.Builder(context).setView(dialogView)

    private val titleTextView: TextView by lazy {
        dialogView.findViewById<TextView>(R.id.alertDialogTitle)
    }

    private val messageTextView: TextView by lazy {
        dialogView.findViewById<TextView>(R.id.alertDialogMessage)
    }

    private val positiveButton: Button by lazy {
        dialogView.findViewById<Button>(R.id.alertDialogButtonAccept)
    }

    private val negativeButton: Button by lazy {
        dialogView.findViewById<Button>(R.id.alertDialogButtonCancel)
    }

    /**
     * setTitle sets the text of the title bar of the dialog.
     *
     * @param title a String containing the title
     */
    fun setTitle(title: String) {
        titleTextView.text = title
    }

    /**
     * setMessage sets the text of the message of the dialog.
     *
     * @param message String containing the message
     */
    fun setMessage(message: String) {
        messageTextView.text = message
    }

    /**
     * positiveButtonClickListener attaches a ClickListener to the positive button
     *
     * @param func expects a function that is called when the ClickListener triggers
     */
    fun positiveButtonClickListener(func: (() -> Unit)? = null) =
        with(positiveButton) {
            setClickListenerToButton(func)
        }

    /**
     * negativeButtonClickListener attaches a ClickListener to the negative button
     *
     * @param func expects a function that is called when the ClickListener triggers
     */
    fun negativeButtonClickListener(func: (() -> Unit)? = null) =
        with(negativeButton) {
            setClickListenerToButton(func)
        }

    /**
     * View.setClickListenerToButton is a extension method of View and attaches a ClickListener
     * to it. Also makes sure functions is called and the dialog "window" is closed (dismissed)
     * after any of the buttons has been clicked.
     *
     * @param func expects a function that is called when the ClickListener triggers
     */
    private fun View.setClickListenerToButton(func: (() -> Unit)?) =
        setOnClickListener {
            func?.invoke()
            dialog?.dismiss()
        }
}