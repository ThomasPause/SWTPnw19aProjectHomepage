package com.oktopoi.utility

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.graphics.Paint.ANTI_ALIAS_FLAG
import androidx.core.content.ContextCompat
import com.oktopoi.R

/**
 * @property path path object which is to be drawn
 * @property padding distance to screen margin
 * @property pathPaint the paint the path is drawn with
 */
@SuppressLint("ViewConstructor")
open class ThumbnailView(context: Context?, viewSize: Pair<Int, Int>) :
    CanvasView(context, viewSize) {

    var path: Path = Path()
    override val padding = 0.05f

    private val pathPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(getContext().applicationContext, R.color.color_flower)
        alpha = 200
        style = Paint.Style.STROKE
        strokeWidth = baseStrokeWidth
        pathEffect = CornerPathEffect(10f)
    }

    fun update(pointList: List<Pair<Float, Float>>) {
        path = pointsToPath(pointList)
        val pathBounds = RectF()
        path.computeBounds(pathBounds, true)

        val pathBoundsCenter = Pair(pathBounds.centerX(), pathBounds.centerY())

        val scaleFactor = getScaleFactor(pathBounds)
        val pathCenterScaled = Pair(
            pathBounds.centerX() * scaleFactor,
            pathBounds.centerY() * scaleFactor
        )
        path.apply {
            scalePath(scaleFactor, padding, pathBoundsCenter)
            translatePath(pathCenterScaled, canvasWidth, canvasHeight)
        }

        draw()
    }

    override fun draw() {
        if (holder.surface.isValid) {
            canvas = holder.lockCanvas()
            canvas.drawPaint(backgroundPaint)
            canvas.drawPath(path, pathPaint)
            holder.unlockCanvasAndPost(canvas)
        }
    }
}
