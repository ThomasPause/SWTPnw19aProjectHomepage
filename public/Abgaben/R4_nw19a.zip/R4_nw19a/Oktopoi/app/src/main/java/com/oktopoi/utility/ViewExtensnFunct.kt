package com.oktopoi.utility

import android.view.View

/**
These Extension Functions can be called in a View directly
 **/


/**
 *  showToast shows a toast with the message within the given context
 *
 * @param message a String containing the message to Toast is supposed to show
 */

fun View.showToast(message: String) =
    android.widget.Toast.makeText(this.context, message, android.widget.Toast.LENGTH_SHORT).show()
