package com.oktopoi.livemode

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.InputType
import android.util.DisplayMetrics
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.SavedStateViewModelFactory
import androidx.navigation.navGraphViewModels
import com.oktopoi.MainActivity
import com.oktopoi.R
import com.oktopoi.drawbyhand.Drawing
import com.oktopoi.flowers.FlowersCalc
import com.oktopoi.library.*
import com.oktopoi.utility.makeEditTextDialog
import com.oktopoi.utility.showToast
import kotlinx.android.synthetic.main.layout_live_mode_fragment.*

/**
 * This Fragment holds a Canvas, that allows to animate Flowers and Drawings. Furthermore buttons
 * are implemented, that allow control over the animation, like pausing or stopping it, as well as
 * manipulating the playback speed.
 *
 * @property playing indicated whether the animation is playing or has been stopped
 * @property showHand indicated whether the hand path is to be shown or not
 * @property primaryButtonColor defining the color of a button when its selected
 * @property secondaryButtonColor defining the color of a button when its deselected
 * @property displayMetrics hold information about the size of the Fragment (important for scaling
 * operations within the animationCanvasView)
 * @property animationCanvasView responsible for rendering the animation
 * @property playButton button for pausing and resuming the animation
 * @property icPlay logo for the play button
 * @property speedButton button for opening the playback-speed-selection-menu
 * @property resetButton button for reseting the animation
 * @property liveSaveButton button for saving current flower/animation
 * @property animationControlButtonContainer layout that contains all the buttons allowing control
 * over the animation
 * @property playbackSpeedButtonContainer layout containing the different buttons for selecting the
 * playback speed
 * @property playbackSpeedControlsVisible indicates whether the playbackSpeedButtonContainer is
 * visible or not, important for toggling between this and the controller menu
 * @property currentPlayBackSpeed indicates which playback speed is currently selected
 * @property playbackSpeedButtons array containing all 5 playback speed buttons
 * @property currentObjectToAnimate hold the object which is to be animated, the object comes from
 * the shared view model
 * @property mViewModel shared view model with FlowersFragment and DrawByHandFragment, allows
 * passing either a FlowersCalc or a Drawing to LiveModeFragment
 */

class LiveModeFragment : Fragment(R.layout.layout_live_mode_fragment) {

    private var playing = false
    private var showHand = false

    private var primaryButtonColor: Int = 0
    private var secondaryButtonColor: Int = 0

    private lateinit var displayMetrics: DisplayMetrics
    private lateinit var animationCanvasView: AnimationCanvasView

    private lateinit var playButton: Button
    private lateinit var icPlay: Drawable
    private lateinit var icPause: Drawable
    private lateinit var speedButton: Button
    private lateinit var resetButton: Button
    private lateinit var liveSaveButton: Button

    private lateinit var animationControlButtonContainer: LinearLayout
    private lateinit var playbackSpeedButtonContainer: LinearLayout
    private var playbackSpeedControlsVisible = false
    private var currentPlayBackSpeed: String = "1/1x"
    private lateinit var playbackSpeedButtons: Array<Button>

    private lateinit var currentObjectToAnimate: Any

    private val mViewModel: LiveModeViewModel by navGraphViewModels(R.id.mobile_navigation)

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        displayMetrics = DisplayMetrics()
        activity!!.windowManager.defaultDisplay.getMetrics(displayMetrics)

        //Set title bar text
        (activity as MainActivity).supportActionBar?.title =
            resources.getString(R.string.menu_live_mode)

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        primaryButtonColor = ContextCompat.getColor(context!!, R.color.textColor)
        secondaryButtonColor = ContextCompat.getColor(context!!, R.color.colorAccent)

        icPlay = context?.getDrawable(R.drawable.ic_playball_mini)!!
        icPause = context?.getDrawable(R.drawable.ic_pauseball_mini)!!

        //Set ViewModel
        mViewModel.apply {
            SavedStateViewModelFactory(requireActivity().application, requireParentFragment())
        }
        currentObjectToAnimate = mViewModel.getCurrentObjectToAnimate()!!

        val animationCanvasLayout = LiveModeCanvas
        val sizeOfCanvasView = Pair(displayMetrics.widthPixels, displayMetrics.widthPixels)
        animationCanvasView =
            AnimationCanvasView(context, sizeOfCanvasView)

        val infoBox = EditTextInfoBox

        //Set canvas to current Object
        if (currentObjectToAnimate is FlowersCalc) {
            println("Flower")
            val flowersCalc = currentObjectToAnimate as FlowersCalc

            val radius = flowersCalc.radius
            val freq1 = flowersCalc.freq1
            val freq2 = flowersCalc.freq2
            val offset = flowersCalc.rotation

            //Calc PointLists for AnimationCanvas
            animationCanvasView.update(flowersCalc.calcFlower(), flowersCalc.calcHand())

            //Set params to Infobox
            val infoBoxLayout = InfoBoxLayout
            infoBoxLayout.hint = resources.getString(R.string.menu_flowers)
            infoBox.setText("radius: $radius | freq1: $freq1 | freq2: $freq2 | rotation: $offset°")
        } else if (currentObjectToAnimate is Drawing) {
            println("Drawing")
            val drawing = currentObjectToAnimate as Drawing

            //set hand and poi list in the canvasView
            animationCanvasView.update(drawing.poi, drawing.hand)

            //Set params to Infobox
            val infoBoxLayout = InfoBoxLayout
            infoBoxLayout.hint = "Drawing"
            infoBox.setText(drawing.info)
        }

        animationCanvasLayout.addView(animationCanvasView)

        val handButton = FlowerHandButton
//        val icHand = context?.getDrawable(R.drawable.ic_hand_2)
        handButton.apply {
            //setImageDrawable(icHand)
            setBackgroundResource(R.drawable.ic_hand)
            setOnClickListener {
                if (showHand) {
                    showHand = false
                    setBackgroundResource(R.drawable.ic_hand)
                    /*ImageViewCompat.setImageTintList(
                        this,
                        ColorStateList.valueOf(primaryButtonColor)
                    )*/
                } else {
                    showHand = true
                    setBackgroundResource(R.drawable.ic_hand_2)

                }
                //Update showHand within animationCanvasView
                animationCanvasView.showHand = showHand

                //Update showHand within viewModel
                mViewModel.showHand = showHand
            }
        }
        //If showHand is true, perform a click on the button, because the default is false
        if (mViewModel.showHand) {
            handButton.performClick()
        }

        playButton = PlayButton.apply {
            //setImageDrawable(icPlay)
            setOnClickListener {
                if (playing) {
                    onPressPause()
                } else {
                    onPressPlay()
                }
            }
        }

        //saves current flower/drawing in library
        liveSaveButton = SaveButton
        liveSaveButton.apply {
            setOnClickListener {
                liveSaveButtonClickHandler(this.context)
            }
        }

        resetButton = ResetButton
        resetButton.apply {
            setOnClickListener { onPressReset() }
            //make grey by default, only activate when animation has started
            setTextColor(Color.GRAY)
        }

        animationControlButtonContainer = LiveControllerContainer
        playbackSpeedButtonContainer = LivePlaybackSpeedContainer

        playbackSpeedButtons = arrayOf(
            btnEighthSpeed,
            btnQuarterSpeed,
            btnHalfSpeed,
            btnNormalSpeed,
            btnDoubleSpeed
        )
        for (button in playbackSpeedButtons) {
            button.setOnClickListener { onPlaybackSpeedButtonPressed(button) }
        }
        //Highlight 1/1x button, cause that is default
        btnNormalSpeed.setTextColor(secondaryButtonColor)

        speedButton = SpeedButton
        speedButton.apply {
            text = currentPlayBackSpeed
            setOnClickListener {
                toggleBottomBar()
            }
        }
    }

    private fun liveSaveButtonClickHandler(context: Context) {
        val saveDialog = makeEditTextDialog {
            setTitle(context.resources.getString(R.string.hint_save_as_dialog))
            eText.inputType = InputType.TYPE_CLASS_TEXT

            positiveButtonClickListener {
                val title = getInput().toString()
                setAnimatedObjectFileContent(currentObjectToAnimate, context, title)
            }
            negativeButtonClickListener {}
        }
        saveDialog.show()
    }

    //set the content depending on file type
    private fun setAnimatedObjectFileContent(
        currentObjectToAnimate: Any,
        context: Context,
        title: String
    ) {
        val fileContent: String

        if (currentObjectToAnimate is FlowersCalc) {
            fileContent = currentObjectToAnimate.toString()
            validateAnimatedObject(title, fileContent, FileFormat.Flower, context)
        } else {
            val drawing = currentObjectToAnimate as Drawing
            fileContent = Converter.pointsToString(drawing.poi)

            validateAnimatedObject(title, fileContent, FileFormat.TouchPad, context)
        }
    }

    //check what type of Animated Object is current & do fileHandler stuff
    private fun validateAnimatedObject(
        title: String,
        fileContent: String,
        fileFormat: FileFormat,
        context: Context
    ) {
        val fileHandler = FileHandler(context, LibraryFragment.directory)

        if (fileHandler.fileExists("$title${FileFormatStrings[fileFormat]}")) {
            showToast(context.resources.getString(R.string.file_name_taken))
        } else if (!fileHandler.isValidFileName(title)) {
            showToast(context.resources.getString(R.string.invalid_file_name))
        } else if (
            fileHandler.writeFile(
                "$title${FileFormatStrings[fileFormat]}",
                fileContent
            )
        ) {
            showToast(
                context.resources.getString(
                    R.string.successfully_saved_file,
                    title
                )
            )
        } else {
            showToast(context.resources.getString(R.string.failed_to_save_file))
        }
    }

    /**
     * onResume is called once after the activity has been created and every time
     * the activity has been paused and is resumed again (e.g. went to background,
     * the app has lost focus to another app, etc.).
     */
    override fun onResume() {
        super.onResume()
        animationCanvasView.resume()
    }

    /**
     * onPause is called every time the activity is paused, e.g. lost focus to another activity/app.
     * flowerCanvasView is paused then, which prevents a thread rendering on the canvas in the
     * background, even though the activity isn't even visible.
     */
    override fun onPause() {
        super.onPause()
        animationCanvasView.pause()
    }


    private fun onPressPlay() {
        playing = true
        //playButton.setImageDrawable(icPause)
        playButton.setBackgroundResource(R.drawable.ic_pauseball_mini)
        animationCanvasView.startAnimation()
        resetButton.apply {
            setTextColor(primaryButtonColor)
            isClickable = true
        }
    }

    private fun onPressPause() {
        playing = false
        //     playButton.setImageDrawable(icPlay)
        playButton.setBackgroundResource(R.drawable.ic_playball_mini)
        animationCanvasView.pauseAnimation()
    }

    private fun onPressReset() {
        playing = false
        //      playButton.setImageDrawable(icPlay)
        playButton.setBackgroundResource(R.drawable.ic_playball_mini)
        animationCanvasView.stopAnimation()
        resetButton.apply {
            setTextColor(Color.GRAY)
            isClickable = false
        }
    }

    private fun toggleBottomBar() {
        if (!playbackSpeedControlsVisible) {
            animationControlButtonContainer.visibility = View.INVISIBLE
            playbackSpeedButtonContainer.visibility = View.VISIBLE
            playbackSpeedControlsVisible = true
        } else {
            animationControlButtonContainer.visibility = View.VISIBLE
            playbackSpeedButtonContainer.visibility = View.INVISIBLE
            playbackSpeedControlsVisible = false
        }
    }

    private fun onPlaybackSpeedButtonPressed(button: Button) {
        //Highlight the current playbackSpeed and reset highlighting of previously selected button
        for (playbackSpeedButton in playbackSpeedButtons) {
            playbackSpeedButton.setTextColor(primaryButtonColor)
        }
        button.setTextColor(secondaryButtonColor)

        currentPlayBackSpeed = button.text.toString()
        speedButton.text = currentPlayBackSpeed

        var playbackSpeed = 1.0f
        when (button) {
            btnEighthSpeed -> playbackSpeed = 0.125f
            btnQuarterSpeed -> playbackSpeed = 0.25f
            btnHalfSpeed -> playbackSpeed = 0.50f
            btnNormalSpeed -> playbackSpeed = 1.00f
            btnDoubleSpeed -> playbackSpeed = 2.00f
        }
        animationCanvasView.playbackSpeed = playbackSpeed

        //Switch back to animation control bottom bar
        toggleBottomBar()
    }


}
