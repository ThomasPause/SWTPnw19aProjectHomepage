package com.oktopoi.utility

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.oktopoi.MainActivity
import com.oktopoi.R

/**
 * This class inflates several help texts for the user.
 * */
class HelpFragment : Fragment(R.layout.layout_help_fragment) {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //Set title bar text
        (activity as MainActivity).supportActionBar?.title =
            resources.getString(R.string.menu_help)

        return super.onCreateView(inflater, container, savedInstanceState)
    }
}
