package com.oktopoi.utility

import android.content.Context
import android.graphics.*
import android.view.SurfaceView
import androidx.core.content.ContextCompat
import com.oktopoi.R

/**
 * Abstract class that provides canvas for drawing on and methods for calculating paths from
 * point lists and also path transformation methods
 *
 * @param context the context where the view is embedded in
 * @param viewSize the size of the view, needs to be determined by hosting fragment, in order for
 * the scale and translate methods to work
 *
 * @property canvas canvas for displaying flower and hand forms
 * @property canvasHeight height of canvas
 * @property canvasWidth width of canvas
 * @property padding distance to screen margin in percent of screensize
 * @property baseStrokeWidth strokeWidth relative to canvas size
 *
 */
abstract class CanvasView(context: Context?, viewSize: Pair<Int, Int>) :
    SurfaceView(context) {

    var canvasWidth = 0
    var canvasHeight = 0

    var canvas: Canvas = Canvas()

    var baseStrokeWidth: Float = 0f

    abstract val padding: Float

    val backgroundPaint = Paint().apply {
        color = ContextCompat.getColor(getContext().applicationContext, R.color.backgroundColor)
    }

    /**
     * The width and the height of the view is set here, based on the passed params.
     * Also the baseStrokeWidth is set as 1/100 of the pixel of the canvas (width-wise); this
     * allows to use this canvas class in basically every size and on every device with consistent
     * stroke width.
     */
    init {
        canvasWidth = viewSize.first
        canvasHeight = viewSize.second
        baseStrokeWidth = canvasWidth / 100f
    }

    abstract fun draw()

    /**
     * uses the generic helper function genericPointsToPath to transform a coordinate list
     * into a pointList providing the necessary params
     *
     * @param pointList list of coordinates
     * @return path object generated from that list
     */
    fun pointsToPath(pointList: List<Pair<Float, Float>>): Path {
        return genericPointsToPath(pointList)
    }

    /**
     * uses the generic helper function getScaleFactor to calculate a scaleFactor according
     * to the canvas size
     *
     * @param pathBounds the bounds object providing the overall size of the path(s)
     * @return scale factor calculated from pathBounds according to the canvasWidth
     */
    fun getScaleFactor(pathBounds: RectF): Float {
        return genericGetScaleFactor(pathBounds, canvasWidth)
    }
}