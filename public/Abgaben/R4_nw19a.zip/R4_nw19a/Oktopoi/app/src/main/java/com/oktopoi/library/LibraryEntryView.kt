package com.oktopoi.library

//import androidx.lifecycle.ViewModelProviders

import android.annotation.SuppressLint
import android.content.Context
import android.view.View
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import com.oktopoi.R
import com.oktopoi.utility.showToast
import kotlinx.android.synthetic.main.library_entry_fragment.view.libraryEntryImageButtonDelete
import kotlinx.android.synthetic.main.library_entry_fragment.view.libraryEntryImageButtonEdit
import kotlinx.android.synthetic.main.library_entry_view.view.*


/**
 * This class represents an entry in the library list.
 *
 * @property textView displays the title of the file
 * @property editButton allows to edit the file name
 * @property deleteButton allows to delete the file
 *
 * */
@SuppressLint("ViewConstructor")
class LibraryEntryView(
    context: Context,
    var title: String,
    var format: FileFormat,
    library: LibraryFragment
) : LinearLayout(context) {

    private var textView: TextView
    private var editButton: ImageButton
    private var deleteButton: ImageButton

    init {
        // the linear layout in which all the other views are located
        inflate(context, R.layout.library_entry_view, this)

        textView = libraryEntryTextView.apply {

            // display the title in the TextView
            this.text = title

            // When the title is clicked, open the file
            this.setOnClickListener {

                val fileName = "$title${FileFormatStrings[format]}"
                // start the appropriate fragment according to the file format that is going to be loaded
                println("About to load $fileName")
                when (format) {
                    FileFormat.Flower -> LibraryFragment.instance.startFlowersFragment(fileName)
                    FileFormat.TouchPad -> LibraryFragment.instance.startDrawByHandFragment(fileName)
                    FileFormat.Unknown -> showToast(
                        resources.getString(R.string.unknown_file_format)
                    )
                }
            }
        }

        // defines the dialogue window for editing the file name
        editButton = libraryEntryImageButtonEdit.apply {
            this.setOnClickListener {

                library.showEditDialogue(this@LibraryEntryView)
            }
        }

        deleteButton = libraryEntryImageButtonDelete.apply {
            this.setOnClickListener {

                library.showDeletionDialog(this@LibraryEntryView)
            }
        }

        if (example_files.containsKey("$title${FileFormatStrings[format]}")) {
            editButton.visibility = View.INVISIBLE
            deleteButton.visibility = View.INVISIBLE
        }
    }
}
