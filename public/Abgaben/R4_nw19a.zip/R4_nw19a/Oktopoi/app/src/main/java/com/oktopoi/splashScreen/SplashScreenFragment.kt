package com.oktopoi.splashScreen

import android.graphics.drawable.Animatable
import android.os.Bundle
import android.os.Handler
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.vectordrawable.graphics.drawable.AnimatedVectorDrawableCompat
import com.oktopoi.MainActivity
import com.oktopoi.R
import kotlinx.android.synthetic.main.layout_splashscreen_fragment.*

/**
 * SplashScreenFragment
 * shows splashscreen with animated oktopoi-logo for 2s when app is started
 */
class SplashScreenFragment : Fragment(R.layout.layout_splashscreen_fragment) {

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        val logoView = logoView
        (activity as MainActivity).supportActionBar?.hide()

        Handler().postDelayed({
            val action = SplashScreenFragmentDirections.actionSplashFragmentToHomeFragment()
            findNavController().navigate(action)
        }, 2000)

        val animR: AnimatedVectorDrawableCompat? =
            context?.let { AnimatedVectorDrawableCompat.create(it, R.drawable.animated_oktopoi) }
        animR?.let {
            logoView.setImageDrawable(it)
        }
        (logoView.drawable as Animatable?)?.start()
    }

}