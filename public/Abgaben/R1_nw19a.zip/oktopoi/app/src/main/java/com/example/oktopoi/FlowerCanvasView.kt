package com.example.oktopoi

import android.content.Context
import android.graphics.*
import android.graphics.Paint.ANTI_ALIAS_FLAG
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.core.content.ContextCompat
import java.lang.Exception

/**
 * Class for transforming flower and hand coordinates to a path, then scaling, centering and displaying
 * them on the canvas.
 *
 * @property showHand indicates if hand curve visualization shall be displayed
 * @property surfaceCreated indicates if surface is created and available
 * @property canvas canvas for displaying flower and hand forms
 * @property canvasHeight height of canvas
 * @property canvasWidth width of canvas
 * @property renderThread thread for drawing onto canvas
 * @property running indicates if renderThread is running
 * @property flowerPath path of flower coordinates
 * @property handPath path of hand coordinates
 * @property padding distance to screen margin
 *
 */
class FlowerCanvasView(context: Context?) : SurfaceView(context), Runnable, SurfaceHolder.Callback {

    var showHand = false
    var surfaceCreated = false

    private var canvas: Canvas = Canvas()
    private var canvasWidth = 0
    private var canvasHeight = 0

    private var renderThread = Thread(this)
    private var running = false

    private var flowerPath: Path = Path()
    private var handPath: Path = Path()

    private val padding = 10f

    /* Defines flower visual appearance. */
    private val flowerPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(getContext().applicationContext, R.color.color_flower)
        alpha = 200
        strokeWidth = 10f
        style = Paint.Style.STROKE
        pathEffect = CornerPathEffect(10f)
    }

    /* Defines hand curve visual appearance. */
    private val handPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(getContext().applicationContext, R.color.colorAccent)
        strokeWidth = 10f
        style = Paint.Style.STROKE
    }

    /**
     * Constructor for FlowerCanvasView. Setting setZOrderOnTop on true puts the SurfaceView's
     * surface on top of any other elements that might sit in its window, regardless of view
     * hierarchy.
     *
     * The SurfaceHolder interface and its callback methods can be used for passing on information
     * about the current state of the surface(see surfaceCreated, surfaceChanged and surfaceDestroyed).
     *
     * SurfaceHolder also provides methods for control over drawing on the canvas (see draw).
     *
     */
    init {
        setZOrderOnTop(true)
        holder.addCallback(this)
        holder.setFormat(PixelFormat.TRANSPARENT)
    }

    /*
     * pointsToPath converts a given list of 2-dimensional coordinates to a Path object.
     * After the first tuple in the list is set as the path's starting point, an iterator over the list
     * delivers one point after the other and adds it to the path. At the end of the process, the contour of the path
     * is closed.
     *
     * @param flowerPointList list of flower coordinates (pairs of x,y positions)
     * @return Path
     */
    private fun pointsToPath(flowerPointList: List<Pair<Float, Float>>): Path {
        val path = Path()
        path.moveTo(flowerPointList[0].first, flowerPointList[0].second)
        for (point in flowerPointList) {
            path.lineTo(point.first, point.second)
        }
        path.close()
        return path
    }

    /**
     * updateFlowerAndHand uses the pointsToPath-method for converting the lists of flower and hand
     * coordinates to a separate path each. These two paths are then merged into the combinedPath object
     * in order to get the control points of the entire contour's enclosing rectangle (a RectF object).
     *
     * Since the flower/hand contour initially is placed in the upper left corner of the canvas and its size
     * hasn't yet been adjusted to the canvas size, it needs to be scaled and relocated. The first step to scaling
     * is realized by calling getScaleFactor.
     *
     * Due to the asymmetrical shape of some flowers, their actual enclosing
     * rectangle's center can differ from the canvas' 0,0 position and thus scaling the path will also change
     * such a center point's coordinates.
     * However, the center of the scaled path is needed as reference point for correctly placing any flower form in the
     * middle of the canvas. Therefore the scale factor needs to be taken in account when translatePath (which handles the
     * path's relocating) is called. This is realized by calculating in advance where scaling will put the center of the
     * path and storing it in combinedPathCenterScaled, which later is given as argument for translatePath.
     *
     * The flower and hand paths are scaled and put in the
     * center of the canvas separately. The combined path is not used so that users can choose to view the flower only.
     *
     * @param flowerPointList list of flower coordinates (pairs of x,y positions)
     * @param handPointList list of hand coordinates (pairs of x,y positions)
     */
    fun updateFlowerAndHand(
        flowerPointList: List<Pair<Float, Float>>,
        handPointList: List<Pair<Float, Float>>
    ) {
        flowerPath = pointsToPath(flowerPointList)
        handPath = pointsToPath(handPointList)
        val combinedPath = Path()
        combinedPath.apply {
            addPath(flowerPath)
            addPath(handPath)
        }

        val combinedPathBounds = RectF()
        combinedPath.computeBounds(combinedPathBounds, true)
        val scaleFactor = getScaleFactor(combinedPathBounds)
        val combinedPathCenterScaled = Pair(
            combinedPathBounds.centerX() * scaleFactor,
            combinedPathBounds.centerY() * scaleFactor
        )

        flowerPath.apply {
            scalePath(scaleFactor)
            translatePath(combinedPathCenterScaled)
        }

        handPath.apply {
            scalePath(scaleFactor)
            translatePath(combinedPathCenterScaled)
        }
    }

    /*
     * getScaleFactor computes the factor by which a given rectangle needs to be
     * scaled to fit into the canvas. Between rectangle width and height, the greater value is used for
     * computing the scale factor. Since the canvas is designed to be square, the canvas width can be used
     * as numerator for either.
     *
     * @param combinedPathBounds rectangle enclosing the combined flower-hand-contour
     * @return canvasWidth / scaleBy
     *
     */
    private fun getScaleFactor(combinedPathBounds: RectF): Float {
        val scaleBy = maxOf(combinedPathBounds.width(), combinedPathBounds.height())
        return canvasWidth / scaleBy
    }

    /*
     * scalePath scales a given path object to the desired size by calling the path class' transform-method.
     * The associated matrix object is defined to be scaled by the factor that getScaleFactor computes,
     * although factoring in a small distance to the canvas margin for design reasons.
     *
     * @param scaleFactor Float
     */
    private fun Path.scalePath(scaleFactor: Float) {
        val scaleMatrix = Matrix()
        scaleMatrix.setScale(
            scaleFactor - padding,
            scaleFactor - padding
        )
        this.transform(scaleMatrix)
    }

    /*
     * translatePath relocates a given path object to the middle of the canvas. For that, the distance
     * between the canvas center and the center of the path contour (which will already be scaled when
     * this method is called) is used as translating factor for the associated matrix object.
     *
     * @param center Pair<Float, Float>
     */
    private fun Path.translatePath(center: Pair<Float, Float>) {
        val translateMatrix = Matrix()
        translateMatrix.setTranslate(
            canvasWidth / 2f - center.first,
            canvasHeight / 2f - center.second
        )
        this.transform(translateMatrix)
    }


    /*
     * draw waits for the surfaceCreated call, then creates a canvas object to be drawn on via the
     * SurfaceHolder's lockCanvas-method. The flower and if required the hand curve will be drawn and,
     * as soon as unlockCanvasAndPost is called, shown on the surface.
     *
     */
    private fun draw() {
        if (surfaceCreated) {
            if (holder.surface.isValid) {
                canvas = holder.lockCanvas()

                canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)

                if (showHand) {
                    canvas.drawPath(handPath, handPaint)
                }
                canvas.drawPath(flowerPath, flowerPaint)

                holder.unlockCanvasAndPost(canvas)
            }
        }
    }

    override fun run() {
        while (running) {
            draw()
        }
    }

    /**
     * When FlowerActivity calls resume and running is set to true, the process of drawing onto the
     * canvas is launched by the run and draw methods. For each resume a new renderThread is created
     * and started.
     *
     */
    fun resume() {
        running = true
        if (renderThread.state == Thread.State.TERMINATED) {
            renderThread = Thread(this)
        }
        renderThread.start()
    }

    /**
     * When FlowerActivity calls pause, the main thread waits for the renderThread to terminate.
     *
     * @throws Exception
     *
     */
    fun pause() {
        running = false
        while (true) {
            try {
                renderThread.join()
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    override fun surfaceCreated(p0: SurfaceHolder?) {

    }

    override fun surfaceChanged(p0: SurfaceHolder?, p1: Int, p2: Int, p3: Int) {
        println("SurfaceChanged: p1: $p1, p2: $p2, p3:$p3 | thread:  " + renderThread.state)
        canvasWidth = width
        canvasHeight = height

        surfaceCreated = true
    }

    override fun surfaceDestroyed(p0: SurfaceHolder?) {
        surfaceCreated = false
    }


}
