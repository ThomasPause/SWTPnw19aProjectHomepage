package com.example.oktopoi

import kotlin.math.*

/**
 * provides methods for calculating flower coordinates
 *
 * @property radius ratio of the radii of the two flower circles
 * @property freq1 frequency of the hand circle
 * @property freq2 frequency of the poi circle
 * @property offset rotation of the flower on the x-y-plane (offset=1 corresponds to a full rotation)
 * @property steps number of steps used to calculate the flower coordinates
 */
class FlowerCalc(
    var radius: Float,
    var freq1: Int,
    var freq2: Int,
    var offset: Double,
    var steps: Int
) {

    /*
     * this function calculates the greatest common divisor of the 2 frequencies.
     * since for the hand and flower curve only the ratio of these frequencies is relevant,
     * we might as well divide freq1 and freq2 by their greatest common divisor whenever they appear.
     * This way we ensure that every point along the flower path is calculated exactly once
     * to avoid division by 0 this function evaluates to 1 if one of the frequencies is 0
     */
    internal fun greatestCommonDivisor(): Int {
        var f1: Int = freq1.absoluteValue
        var f2: Int = freq2.absoluteValue
        if(f1 * f2 == 0){
            return 1
        }
        while (f1 != f2) {
            if (f1 < f2) {
                f2 -= f1
            } else {
                f1 -= f2
            }
        }
        return f1
    }

    /*
     * xHand calculates the x coordinate of the hand position at a given time t by the formula
     *
     * xHand(t) = cos(2*PI*t*f1/steps)
     *
     * where f1 is freq1/gcd (frequency 1 divided by the greatest common divisor of the 2 frequencies)
     * and steps is the number of points along the hand path we are going to calculate
     */
    internal fun xHand(time: Int): Float {
        val t = time.toDouble()
        val f1 = (freq1 / greatestCommonDivisor()).toDouble()
        return cos(2.0 * PI * t * f1 / steps.toDouble()).toFloat()
    }

    /*
     * yHand calculates the y coordinate of the hand position at a given time t by the formula
     *
     * yHand(t) = sin(2*PI*t*f1/steps)
     *
     * where f1 is freq1/gcd (frequency 1 divided by the greatest common divisor of the 2 frequencies)
     * and steps is the number of points along the hand path we are going to calculate
     */
    internal fun yHand(time: Int): Float {
        val t = time.toDouble()
        val f1 = (freq1 / greatestCommonDivisor()).toDouble()
        return sin(2.0 * PI * (t) * f1 / steps.toDouble()).toFloat()
    }

    /**
     * calcHand returns a list of coordinates which represent the hand curve
     *
     * @return list of coordinates (pairs of Floats)
     */
    fun calcHand(): List<Pair<Float, Float>> {
        /*
         * We first create 2 separate arrays for x and y coordinates of the poi movement respectively
         * then zip them together in a list of coordinates (float pairs)
         */
        val xCoord: Array<Float> = Array(steps) { t -> xHand(t) }
        val yCoord: Array<Float> = Array(steps) { t -> yHand(t) }
        return xCoord.zip(yCoord)
    }

    /*
     * xFlower calculates the x coordinate of the poi position at time t.
     * Since this position is obtained by the sum of the hand and the poi circle it is calculated by the following formula
     *
     * xFlower(t) = xHand(t) + r*cos(2*PI*(t*f2/steps+offset))
     *
     * where f2 is freq2/gcd (frequency 2 divided by the greatest common divisor of the 2 frequencies)
     * and steps is the number of points along the hand path we are going to calculate
     * offset is a parameter that correspondents to a rotation of the flower
     */
    internal fun xFlower(time: Int): Float {
        val t = time.toDouble()
        val f2 = (freq2 / greatestCommonDivisor()).toDouble()
        return xHand(time) + radius * cos(2.0 * PI * ((t) * f2 / steps.toDouble() + offset)).toFloat()
    }

    /*
     * yFlower calculates the y coordinate of the poi position at time t.
     * Since this position is obtained by the sum of the hand and the poi circle it is calculated by the following formula
     *
     * yFlower(t) = yHand(t) + r*sin(2*PI*(t*f2/steps+offset))
     *
     * where f2 is freq2/gcd (frequency 2 divided by the greatest common divisor of the 2 frequencies)
     * and steps is the number of points along the hand path we are going to calculate
     * offset is a parameter that correspondents to a rotation of the flower
     */
    internal fun yFlower(time: Int): Float {
        val t = time.toDouble()
        val f2 = (freq2 / greatestCommonDivisor()).toDouble()
        return yHand(time) + radius * sin(2.0 * PI * ((t) * f2 / steps.toDouble() + offset)).toFloat()
    }

    /**
     * calcFlower returns a list of coordinates which represent the poi movement
     *
     * @return list of coordinates (pairs of Floats)
     */
    fun calcFlower(): List<Pair<Float, Float>> {
        /*
         * We first create 2 separate arrays for x and y coordinates of the poi movement respectively
         * then zip them together in a list of coordinates (float pairs)
         */
        val xCoord: Array<Float> = Array(steps) { t -> xFlower(t) }
        val yCoord: Array<Float> = Array(steps) { t -> yFlower(t) }
        return xCoord.zip(yCoord)
    }

}