package com.example.oktopoi

import org.junit.Assert
import org.junit.Test

class FlowerActivityTest {

    private val testActivity = FlowerActivity()

    @Test
    fun `validateInput regex matching`() {
        Assert.assertFalse("Value 0 should fail", testActivity.validateInput("0"))
        Assert.assertFalse("Value 05 should fail", testActivity.validateInput("05"))
        Assert.assertFalse("Value - should fail", testActivity.validateInput("-"))
        Assert.assertFalse("Value -0.5 should fail", testActivity.validateInput("-0.5"))
        Assert.assertTrue("Value -102 should pass", testActivity.validateInput("-102"))
        Assert.assertTrue("Value 99999950 should pass", testActivity.validateInput("99999950"))


    }
}