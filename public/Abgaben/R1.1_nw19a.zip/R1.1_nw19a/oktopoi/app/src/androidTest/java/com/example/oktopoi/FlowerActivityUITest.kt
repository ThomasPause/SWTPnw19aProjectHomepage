package com.example.oktopoi


import android.view.View
import android.view.ViewGroup
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.filters.LargeTest
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.rule.ActivityTestRule
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers.allOf
import org.hamcrest.TypeSafeMatcher
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@LargeTest
@RunWith(AndroidJUnit4ClassRunner::class)
class FlowerActivityUITest {

    @Rule
    @JvmField
    var mActivityTestRule = ActivityTestRule(FlowerActivity::class.java)

    //UI-Tests validate all User Interface objects
    @Test
    fun flowerActivityUITest() {
        //activate switch
        val switch = onView(
            allOf(
                withId(R.id.SwitchShowHand),
                childAtPosition(
                    allOf(
                        withId(R.id.HandSwitchContainer),
                        childAtPosition(
                            withId(R.id.FlowerLayoutParent),
                            1
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        switch.perform(click())

        //replace text
        val appCompatEditText = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("0.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText.perform(replaceText("1.5"))

        //close keyboard
        val appCompatEditText2 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("1.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText2.perform(closeSoftKeyboard())

        //click done button
        val appCompatEditText3 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("1.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText3.perform(pressImeActionButton())

        //replace text
        val appCompatEditText4 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText4.perform(replaceText("8"))

        //close keyboard
        val appCompatEditText5 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("8"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText5.perform(closeSoftKeyboard())

        //click done button
        val appCompatEditText6 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("8"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText6.perform(pressImeActionButton())

        //replace text
        val appCompatEditText7 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("14"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText7.perform(replaceText("4"))

        //close keyboard
        val appCompatEditText8 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("4"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText8.perform(closeSoftKeyboard())

        //click done button
        val appCompatEditText9 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("4"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText9.perform(pressImeActionButton())

        //replace text
        val appCompatEditText10 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.0"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText10.perform(replaceText("0.2"))

        //close keyboard
        val appCompatEditText11 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText11.perform(closeSoftKeyboard())

        //click done button
        val appCompatEditText12 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText12.perform(pressImeActionButton())

        //deactivate switch
        val switch2 = onView(
            allOf(
                withId(R.id.SwitchShowHand),
                childAtPosition(
                    allOf(
                        withId(R.id.HandSwitchContainer),
                        childAtPosition(
                            withId(R.id.FlowerLayoutParent),
                            1
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        switch2.perform(click())
    }

    private fun childAtPosition(
        parentMatcher: Matcher<View>, position: Int
    ): Matcher<View> {

        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
                description.appendText("Child at position $position in parent ")
                parentMatcher.describeTo(description)
            }

            public override fun matchesSafely(view: View): Boolean {
                val parent = view.parent
                return parent is ViewGroup && parentMatcher.matches(parent)
                        && view == parent.getChildAt(position)
            }
        }
    }
}
