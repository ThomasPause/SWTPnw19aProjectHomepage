package com.example.oktopoi

import org.junit.Assert
import org.junit.Test
import kotlin.math.sqrt

class FlowerCalcTest {

    /* calculating with floating point numbers may cause rounding errors which we don't want to detect
    therefor we specify here the accuracy to which we want to test these numbers*/
    private val delta = 0.0001f

    // Arrange
    private val flower0 = FlowerCalc(0.0f, 0, 0, 0.0, 600)
    private val flower1 = FlowerCalc(1.5f, 0, 1, 0.5, 30)
    private val flower2 = FlowerCalc(1f, 2, 0, 2.25, 50)
    private val flower3 = FlowerCalc(2.7f, -4, 1, 1.0 / 3.0, 12)
    private val flower4 = FlowerCalc(0.8f, -7, -12, 0.25, 48)
    private val flower5 = FlowerCalc(0.001f, 12, 8, 4.0, 120)
    private val flower6 = FlowerCalc(4f/3f, 10, -5, 0.75, 12)
    private val flower7 = FlowerCalc(1.2f, 117000, 65000, 0.125, 24)
    private val flower8 = FlowerCalc(0.5f, 3, -3, 0.0, 9)
    private val flower9 = FlowerCalc(1f, 1, -1, 0.5, 20)

    /*
     * In this test we verify that the greatestCommonDivisor() function works correctly
     * cases tested: normal input, big numbers, zero input, different signs
     */
    @Test
    fun `greatestCommonDivisor to assert greatest common divisor of freq1 and freq 2`(){

        val gcd0 = flower0.greatestCommonDivisor()
        Assert.assertEquals("flower0: freq1 = 0, freq2 = 0", gcd0, 1)

        val gcd1 = flower1.greatestCommonDivisor()
        Assert.assertEquals("flower1: freq1 = 0, freq2 = 1", gcd1, 1)

        val gcd2 = flower2.greatestCommonDivisor()
        Assert.assertEquals("flower2: freq1 = 2, freq2 = 0", gcd2, 1)

        val gcd3 = flower3.greatestCommonDivisor()
        Assert.assertEquals("flower3: freq1 = -4, freq2 = 1", gcd3, 1)

        val gcd4 = flower4.greatestCommonDivisor()
        Assert.assertEquals("flower4: freq1 = -7, freq2 = -12", gcd4, 1)

        val gcd5 = flower5.greatestCommonDivisor()
        Assert.assertEquals("flower5: freq1 = 12, freq2 = 8", gcd5, 4)

        val gcd6 = flower6.greatestCommonDivisor()
        Assert.assertEquals("flower6: freq1 = 10, freq2 = -5", gcd6, 5)

        val gcd7 = flower7.greatestCommonDivisor()
        Assert.assertEquals("flower7: freq1 = 117000, freq2 = 65000", gcd7, 13000)

        val gcd8 = flower8.greatestCommonDivisor()
        Assert.assertEquals("flower8: freq1 = 3, freq2 = 3", gcd8, 3)

        val gcd9 = flower9.greatestCommonDivisor()
        Assert.assertEquals("flower9: freq1 = 1, freq2 = -1", gcd9, 1)

    }


    /*
     * this test makes sure that the xHand(t) function calculates the x position of the hand at time t correctly
     */
    @Test
    fun `xHand to assert x position of hand at time t`() {

        val xHand0 = flower0.xHand(0)
        Assert.assertEquals("flower0 (t=0)", xHand0, 1f, delta)

        val xHand1 = flower1.xHand(5)
        Assert.assertEquals("flower1 (t=0)", xHand1, 1f, delta)

        val xHand2 = flower2.xHand(30)
        Assert.assertEquals("flower2 (t=0)", xHand2, 0.30902f, delta)

        val xHand3 = flower3.xHand(15)
        Assert.assertEquals("flower3 (t=0)", xHand3, 1f, delta)

        val xHand4 = flower4.xHand(11)
        Assert.assertEquals("flower4 (t=0)", xHand4, -0.79335f, delta)

        val xHand5 = flower5.xHand(55)
        Assert.assertEquals("flower5 (t=0)", xHand5, -0.70711f, delta)

        val xHand6 = flower6.xHand(1)
        Assert.assertEquals("flower6 (t=0)", xHand6, 0.5f, delta)

        val xHand7 = flower7.xHand(0)
        Assert.assertEquals("flower7 (t=0)", xHand7, 1f, delta)

        val xHand8 = flower8.xHand(4)
        Assert.assertEquals("flower8 (t=0)", xHand8, -0.93969f, delta)

        val xHand9 = flower9.xHand(11)
        Assert.assertEquals("flower9 (t=0)", xHand9, -0.95106f, delta)
    }

    /*
     * this test makes sure that the yHand(t) function calculates the x position of the hand at time t correctly
     */
    @Test
    fun `yHand to assert y position of hand at time t`() {

        val yHand0 = flower0.yHand(0)
        Assert.assertEquals("flower0 (t=0)", yHand0, 0f, delta)

        val yHand1 = flower1.yHand(5)
        Assert.assertEquals("flower1 (t=0)", yHand1, 0f, delta)

        val yHand2 = flower2.yHand(30)
        Assert.assertEquals("flower2 (t=0)", yHand2, 0.95106f, delta)

        val yHand3 = flower3.yHand(15)
        Assert.assertEquals("flower3 (t=0)", yHand3, 0f, delta)

        val yHand4 = flower4.yHand(11)
        Assert.assertEquals("flower4 (t=0)", yHand4, 0.60876f, delta)

        val yHand5 = flower5.yHand(55)
        Assert.assertEquals("flower5 (t=0)", yHand5, 0.70711f, delta)

        val yHand6 = flower6.yHand(1)
        Assert.assertEquals("flower6 (t=0)", yHand6, 0.86603f, delta)

        val yHand7 = flower7.yHand(0)
        Assert.assertEquals("flower7 (t=0)", yHand7, 0f, delta)

        val yHand8 = flower8.yHand(4)
        Assert.assertEquals("flower8 (t=0)", yHand8, 0.34202f, delta)

        val yHand9 = flower9.yHand(11)
        Assert.assertEquals("flower9 (t=0)", yHand9, -0.30901f, delta)
    }

    /*
     * this test makes sure that the xFlower(t) function calculates the x position of the poi head at time t correctly
     */
    @Test
    fun `xFlower to assert x position of poi at time t`() {

        val xFlower0 = flower0.xFlower(0)
        Assert.assertEquals("flower0 (t=0)", xFlower0, 1f, delta)

        val xFlower1 = flower1.xFlower(5)
        Assert.assertEquals("flower1 (t=0)", xFlower1, 0.25f, delta)

        val xFlower2 = flower2.xFlower(30)
        Assert.assertEquals("flower2 (t=0)", xFlower2, 0.30902f, delta)

        val xFlower3 = flower3.xFlower(15)
        Assert.assertEquals("flower3 (t=0)", xFlower3, -1.338269f, delta)

        val xFlower4 = flower4.xFlower(11)
        Assert.assertEquals("flower4 (t=0)", xFlower4, -1.59335f, delta)

        val xFlower5 = flower5.xFlower(55)
        Assert.assertEquals("flower5 (t=0)", xFlower5, -0.70624f, delta)

        val xFlower6 = flower6.xFlower(1)
        Assert.assertEquals("flower6 (t=0)", xFlower6, -1f/6f, delta)

        val xFlower7 = flower7.xFlower(0)
        Assert.assertEquals("flower7 (t=0)", xFlower7, 1.84853f, delta)

        val xFlower8 = flower8.xFlower(4)
        Assert.assertEquals("flower8 (t=0)", xFlower8, -1.40954f, delta)

        val xFlower9 = flower9.xFlower(11)
        Assert.assertEquals("flower9 (t=0)", xFlower9, 0f, delta)
    }

    /*
     * this test makes sure that the yFlower(t) function calculates the y position of the poi head at time t correctly
     */
    @Test
    fun `yFlower to assert y position of poi at time t`() {

        val yFlower0 = flower0.yFlower(0)
        Assert.assertEquals("flower0 (t=0)", yFlower0, 0f, delta)

        val yFlower1 = flower1.yFlower(5)
        Assert.assertEquals("flower1 (t=0)", yFlower1, -1.29904f, delta)

        val yFlower2 = flower2.yFlower(30)
        Assert.assertEquals("flower2 (t=0)", yFlower2, 1.95106f, delta)

        val yFlower3 = flower3.yFlower(15)
        Assert.assertEquals("flower3 (t=0)", yFlower3, -1.35f, delta)

        val yFlower4 = flower4.yFlower(11)
        Assert.assertEquals("flower4 (t=0)", yFlower4, 0.60876f, delta)

        val yFlower5 = flower5.yFlower(55)
        Assert.assertEquals("flower5 (t=0)", yFlower5, 0.70661f, delta)

        val yFlower6 = flower6.yFlower(1)
        Assert.assertEquals("flower6 (t=0)", yFlower6, -0.28868f, delta)

        val yFlower7 = flower7.yFlower(0)
        Assert.assertEquals("flower7 (t=0)", yFlower7, 0.84853f, delta)

        val yFlower8 = flower8.yFlower(4)
        Assert.assertEquals("flower8 (t=0)", yFlower8, 0.17101f, delta)

        val yFlower9 = flower9.yFlower(11)
        Assert.assertEquals("flower9 (t=0)", yFlower9, -0.61803f, delta)
    }

    /*
     * This test verifies that calcHand() calculates the hand coordinates of flower6 correctly
     */
    @Test
    fun `calcHand() to assert list of hand coordinates`(){

        val a = sqrt(0.75f) // auxiliary variable emerges often in the expected result

        val result6: List<Pair<Float,Float>> = listOf(
            Pair(1f,0f),
            Pair(0.5f,a),
            Pair(-0.5f,a),
            Pair(-1f,0f),
            Pair(-0.5f,-a),
            Pair(0.5f,-a),
            Pair(1f,0f),
            Pair(0.5f,a),
            Pair(-0.5f,a),
            Pair(-1f,0f),
            Pair(-0.5f,-a),
            Pair(0.5f,-a))
        val hand6 = flower6.calcHand()

        for(i in 0 until flower6.steps){
            Assert.assertEquals("flower6: x coordinate at time $i", hand6[i].first, result6[i].first, delta )
            Assert.assertEquals("flower6: y coordinate at time $i", hand6[i].second, result6[i].second, delta )
        }
    }

    /*
     * This test verifies that calcFlower() calculates the flower coordinates of flower6 correctly
     */
    @Test
    fun `calcFlower() to assert list of flower coordinates`(){

        val a = 0.65470f // auxiliary variable emerges often in the expected result
        val b = 0.28868f // auxiliary variable emerges often in the expected result
        val c = 0.19936f // auxiliary variable emerges often in the expected result
        val d = 2.02073f // auxiliary variable emerges often in the expected result
        val e = 1.53269f // auxiliary variable emerges often in the expected result

        val result6: List<Pair<Float,Float>> = listOf(
            Pair(1f,-4f/3f),
            Pair(-1f/6f,-b),
            Pair(-1f-a,c),
            Pair(-7f/3f,0f),
            Pair(-1f-a,-c),
            Pair(-1f/6f,b) ,
            Pair(1f,4f/3f),
            Pair(7f/6f,d),
            Pair(a,e),
            Pair(1f/3f,0f),
            Pair(a,-e),
            Pair(7f/6f,-d))
        val f6 = flower6.calcFlower()

        for(i in 0 until flower6.steps){
            Assert.assertEquals("flower6: x coordinate at time $i", f6[i].first, result6[i].first, delta )
            Assert.assertEquals("flower6: y coordinate at time $i", f6[i].second, result6[i].second, delta )
        }
    }

}