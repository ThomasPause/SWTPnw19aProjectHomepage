package com.example.oktopoi

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import kotlinx.android.synthetic.main.layout_flower_activity.*
import java.lang.Exception

/**
 * This class handles all the user-interface, user-input, visual output and calculations for the
 * flower-functionality
 *
 * @property flowerCalc instance of FlowerCalc-class, that handles calculation of the flower
 * @property flowerCanvasView instance of FlowerCanvasView-class, that provides canvas for the
 * flower to be drawn and animated on
 *
 * @property etRadius editText-view that accepts decimal input for the flower radius
 * @property etFreq1 editText-view that accepts whole number input for the inner frequency
 * @property etFreq2 editText-view that accepts whole number input for the outer frequency
 * @property etOffset editText-view that accepts decimal input for the rotation offset
 * @property swShowHand switch-view that allows for showing the hand movement or not
 *
 * default values for flower parameters to have a flower ready when activity is called
 * @property radius radius
 * @property freq1 inner frequency
 * @property freq2 outer frequency
 * @property offset rotation offset
 * @property lastFreq1 stores the last valid user input for inner frequency
 * @property lastFreq2 stores the last valid user input for outer frequency
 * @property lastOffset stores the last valid user input for offset
 *
 * @property thread handles the creation of the canvas within flowerCanvasView-instance
 * @property running tells if thread is still going or has stopped
 */

class FlowerActivity : AppCompatActivity(), Runnable {

    private lateinit var flowerCalc: FlowerCalc
    private lateinit var flowerCanvasView: FlowerCanvasView

    private lateinit var etRadius: EditText
    private lateinit var etFreq1: EditText
    private lateinit var etFreq2: EditText
    private lateinit var etOffset: EditText
    private lateinit var swShowHand: Switch

    private var radius = 0.5f
    private var freq1 = 2
    private var freq2 = 14
    private var offset = 0.0

    private var lastRadius = radius.toString()
    private var lastFreq1 = freq1.toString()
    private var lastFreq2 = freq2.toString()
    private var lastOffset = offset.toString()

    private var maxRadius = 3f

    private var thread = Thread(this)
    private var running = false

    /**
     * onCreate is called when the activity is started for the first time or after being destroyed.
     * The instances of FlowerCalc and FlowerCanvasView are instantiated here,
     * so are all the UI-Elements with different ActionListeners for handling user-input
     *
     * @param Bundle containing the values of our app
     *
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /*tells the activity what to show by referring to "layout_flower_activity.xml" in the layout-folder*/
        setContentView(R.layout.layout_flower_activity)

        /*
        flowerCalc is instantiated and initialized with default values for flower parameters
        specified above
         */
        flowerCalc = FlowerCalc(radius, freq1, freq2, offset, 720)

        /*flowerCanvasView is instantiated*/
        flowerCanvasView = FlowerCanvasView(this).apply {
            showHand = false
        }

        /*
        flowerCanvas is just an empty layout defined within the layout xml-file, so
        flowerCanvasView with all its contents is added to flowerCanvas
         */
        flowerCanvas.addView(flowerCanvasView)

        /*
        the four EditText-Views for inputting the flower parameters are instantiated here.
        The procedure for every one is roughly the same:
        1. fill in the input field of the EditText with the corresponding default value

        2. attach onEditorActionListener that listens to a confirmation of user-input by
        pressing the enter-button on the soft keyboard. It triggers an update of the flower

        3. attach onFocusChangeListener that also triggers an update of the flower, when a value
        has been given but without confirming it, the user switches directly to another EditText

        for all inputs a additional check condition is implemented, to make sure,
        that a valid number has been entered. If that's not the case, but the user tries to
        confirm the input anyways, the value in the textField is reset to the last known valid value
        */
        etRadius = TextInputRadius.apply {
            setText(radius.toString())
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val input = text.toString().toFloatOrNull()
                    if (input != null) {
                        if (input <= maxRadius) {
                            //cast user input to floating point number for consistency
                            setText(input.toString())
                            flowerCalc.radius = input
                            updateFlowerCanvasView()
                            lastRadius = input.toString()
                        } else {
                            setText(lastRadius)
                            Toast.makeText(context, "radius has to be <= 3", Toast.LENGTH_SHORT)
                                .show()
                        }
                    } else {
                        setText(lastRadius)
                        Toast.makeText(context, "enter valid number", Toast.LENGTH_SHORT)
                            .show()
                    }
                    hideKeyboard()
                    clearFocus()
                    true
                } else {
                    false
                }
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val input = text.toString().toFloatOrNull()
                    if(input != null) {
                        if (input <= maxRadius) {
                            //cast user input to floating point number for consistency
                            setText(input.toString())
                            flowerCalc.radius = input
                            updateFlowerCanvasView()
                            lastRadius = input.toString()
                        } else {
                            setText(lastRadius)
                            Toast.makeText(context, "radius has to be <= 3", Toast.LENGTH_SHORT)
                                .show()
                        }
                    } else {
                        setText(lastRadius)
                        Toast.makeText(context, "enter valid number", Toast.LENGTH_SHORT)
                            .show()
                    }
                }
            }
        }

        etFreq1 = TextInputFreq1.apply {
            setText(freq1.toString())
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val userInput = text.toString()
                    if (validateInput(userInput)) {
                        flowerCalc.freq1 = userInput.toInt()
                        updateFlowerCanvasView()
                        lastFreq1 = userInput
                    } else {
                        setText(lastFreq1)
                        if (userInput == "0") {
                            Toast.makeText(context, "value can't be 0", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "enter valid number", Toast.LENGTH_SHORT).show()
                        }
                    }
                    hideKeyboard()
                    clearFocus()
                    true
                } else {
                    false
                }
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val userInput = text.toString()
                    if (validateInput(userInput)) {
                        flowerCalc.freq1 = userInput.toInt()
                        updateFlowerCanvasView()
                        lastFreq1 = userInput
                    } else {
                        setText(lastFreq1)
                        if (userInput == "0") {
                            Toast.makeText(context, "value can't be 0", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "enter valid number", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }

        etFreq2 = TextInputFreq2.apply {
            setText(freq2.toString())
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val userInput = text.toString()
                    if (validateInput(userInput)) {
                        flowerCalc.freq2 = userInput.toInt()
                        updateFlowerCanvasView()
                        lastFreq2 = userInput
                    } else {
                        setText(lastFreq2)
                        if (userInput == "0") {
                            Toast.makeText(context, "value can't be 0", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "enter valid number", Toast.LENGTH_SHORT).show()
                        }
                    }
                    hideKeyboard()
                    clearFocus()
                    true
                } else {
                    false
                }
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val userInput = text.toString()
                    if (validateInput(userInput)) {
                        flowerCalc.freq2 = userInput.toInt()
                        updateFlowerCanvasView()
                        lastFreq2 = userInput
                    } else {
                        setText(lastFreq2)
                        if (userInput == "0") {
                            Toast.makeText(context, "value can't be 0", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "enter valid number", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }

        etOffset = TextInputOffset.apply {
            setText(offset.toString())
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) {
                    val input = text.toString().toDoubleOrNull()
                    if (input != null) {
                        //cast user input to floating point number for consistency
                        setText(input.toString())
                        flowerCalc.offset = text.toString().toDouble()
                        updateFlowerCanvasView()
                        lastOffset = input.toString()
                    } else {
                        setText(lastOffset)
                        Toast.makeText(context, "enter valid number", Toast.LENGTH_SHORT).show()
                    }
                    hideKeyboard()
                    clearFocus()
                    true
                } else {
                    false
                }
            }
            setOnFocusChangeListener { _, hasFocus ->
                if (!hasFocus) {
                    val input = text.toString().toDoubleOrNull()
                    if (input != null) {
                        //cast user input to floating point number for consistency
                        setText(input.toString())
                        flowerCalc.offset = text.toString().toDouble()
                        updateFlowerCanvasView()
                        lastOffset = input.toString()
                    } else {
                        setText(lastOffset)
                        Toast.makeText(context, "enter valid number", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

        /*
        the Switch for showing the Hand is instantiated and a onCheckedChangeListener is
        attached, that is triggered when the user clicks the switch and therefore changes
        its status
         */
        swShowHand = SwitchShowHand.apply {
            setOnCheckedChangeListener { _, isChecked ->
                flowerCanvasView.showHand = isChecked
            }
        }
    }

    /*
     * onResume is called once after the activity has been created and every time
     * the activity has been paused and is resumed again (e.g. went to background,
     * the app has lost focus to another app, etc.).
     * A thread is started then, that waits for the successful creation of the canvas within the
     * flowerCanvasView-instance. This is necessary, because in order to center and scale the flower
     * within the canvas, it has to know its size, which only becomes available the moment the
     * canvas has been created successfully, which might take a while.
     */
    override fun onResume() {
        super.onResume()
        running = true
        if (thread.state != Thread.State.NEW) thread = Thread(this)
        if (thread.state == Thread.State.NEW) thread.start()
    }

    /*
     * onPause is called every time the activity is paused, e.g. lost focus to another activity/app.
     * flowerCanvasView is paused then, which prevents a thread rendering on the canvas in the
     * background, even though the activity isn't even visible.
     */
    override fun onPause() {
        super.onPause()
        flowerCanvasView.pause()
    }

    /**
     * EditText.hideKeyboard makes the soft keyboard disappear after the user confirmed the input.
     * This would not happen automatically with the editText-Views.
     */
    private fun EditText.hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }

    /**
     * validateInput compares user input for the frequency parameters to a regex,
     * to make sure the input is neither "0", nor starts with "0", nor is just a "-" sign
     *
     * @param input String that should be transformed to an Integer number interpreted as frequency
     * @return true, if input is a valid frequency
     */
    internal fun validateInput(input: String): Boolean {
        return input.matches("-?[1-9]\\d*".toRegex())
    }

    /**
     * updateFlowerCanvasView is called every time the user changes one of the flower parameters,
     * either by inputting values in the corresponding editText-Views and switching to another
     * editText, or simply by confirming the input by clicking the enter-button on the soft keyboard.
     * Based on the altered parameters, the coordinates of the new flower are being calculated
     * within the calcFlower-instance and passed through to flowerCanvasView in order to be
     * processed there.
     */
    private fun updateFlowerCanvasView() {
        flowerCanvasView.updateFlowerAndHand(flowerCalc.calcFlower(), flowerCalc.calcHand())
    }

    /*
     * run is a inherited method from Thread and is called when the thread-instance is started.
     * It checks for a confirmation within the flowerCanvasView, that the surface including
     * the canvas has been created successfully. If that is the case, updateFlowerCanvasView() is
     * called, the flower is calculated and passed to the flowerCanvasView-instance to be rendered
     * onto the canvas.
     */
    override fun run() {
        while (running) {
            if (flowerCanvasView.surfaceCreated) {
                updateFlowerCanvasView()
                flowerCanvasView.resume()
                pauseThread()
            }
        }
    }

    /**
     * pauseThread ensures that, after the surface within flowerCanvasView has been created
     * and the flower has been rendered, the thread handling this process is terminated
     * correctly in order to prevent an exception to be thrown after the activity is created again.
     * That would be the case if a thread is started on top of another thread, that has not been
     * terminated successfully.
     */
    private fun pauseThread() {
        running = false
        while (true) {
            try {
                thread.join()
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}