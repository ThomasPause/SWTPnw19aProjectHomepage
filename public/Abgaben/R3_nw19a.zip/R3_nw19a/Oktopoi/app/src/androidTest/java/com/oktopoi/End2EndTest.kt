package com.oktopoi


import android.view.View
import android.view.ViewGroup
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.filters.LargeTest
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.rule.ActivityTestRule
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers.`is`
import org.hamcrest.Matchers.allOf
import org.hamcrest.TypeSafeMatcher
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/*
walkthrough the whole app
 */

@LargeTest
@RunWith(AndroidJUnit4ClassRunner::class)
class End2EndTest {

    @Rule
    @JvmField
    var mActivityTestRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun end2EndTest() {
        val textView = onView(
            allOf(
                withId(R.id.libraryEntryTextView), withText("ChurchWindow"),
                childAtPosition(
                    allOf(
                        withId(R.id.library_entry_layout),
                        childAtPosition(
                            withClassName(`is`("com.oktopoi.library.LibraryEntryView")),
                            0
                        )
                    ),
                    1
                )
            )
        )
        textView.perform(scrollTo(), click())

        val appCompatEditText = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("0.4"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText.perform(replaceText("1"))

        val appCompatEditText2 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("1"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText2.perform(closeSoftKeyboard())

        val appCompatEditText3 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText3.perform(replaceText("7"))

        val appCompatEditText4 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("7"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText4.perform(closeSoftKeyboard())

        val appCompatEditText5 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("90.0°"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText5.perform(replaceText("30"))

        val appCompatEditText6 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("30"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText6.perform(closeSoftKeyboard())

        val appCompatEditText7 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("30"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText7.perform(pressImeActionButton())

        val appCompatImageView = onView(
            allOf(
                withId(R.id.FlowersHandButton),
                childAtPosition(
                    allOf(
                        withId(R.id.FlowersControllerContainer),
                        childAtPosition(
                            withId(R.id.FlowerLayoutParent),
                            2
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageView.perform(click())

        val appCompatButton = onView(
            allOf(
                withId(R.id.FlowersLiveButton), withText("live"),
                childAtPosition(
                    allOf(
                        withId(R.id.FlowersControllerContainer),
                        childAtPosition(
                            withId(R.id.FlowerLayoutParent),
                            2
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        appCompatButton.perform(click())

        val appCompatButton2 = onView(
            allOf(
                withId(R.id.PlayButton),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.LiveControllerContainer),
                        5
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton2.perform(click())

        val appCompatButton3 = onView(
            allOf(
                withId(R.id.LiveHandButton),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatButton3.perform(click())

        val appCompatButton4 = onView(
            allOf(
                withId(R.id.LiveHandButton),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatButton4.perform(click())

        val appCompatButton5 = onView(
            allOf(
                withId(R.id.SpeedButton), withText("1/1x"),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    7
                ),
                isDisplayed()
            )
        )
        appCompatButton5.perform(click())

        val appCompatButton6 = onView(
            allOf(
                withId(R.id.btnTripleSpeed), withText("3/1x"),
                childAtPosition(
                    allOf(
                        withId(R.id.LivePlaybackSpeedContainer),
                        childAtPosition(
                            withId(R.id.LiveModeParent),
                            2
                        )
                    ),
                    4
                ),
                isDisplayed()
            )
        )
        appCompatButton6.perform(click())

        val appCompatButton7 = onView(
            allOf(
                withId(R.id.SpeedButton), withText("3/1x"),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    7
                ),
                isDisplayed()
            )
        )
        appCompatButton7.perform(click())

        val appCompatButton8 = onView(
            allOf(
                withId(R.id.btnQuarterSpeed), withText("1/4x"),
                childAtPosition(
                    allOf(
                        withId(R.id.LivePlaybackSpeedContainer),
                        childAtPosition(
                            withId(R.id.LiveModeParent),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton8.perform(click())

        val appCompatButton9 = onView(
            allOf(
                withId(R.id.PlayButton),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.LiveControllerContainer),
                        5
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton9.perform(click())

        val appCompatButton10 = onView(
            allOf(
                withId(R.id.ResetButton), withText("reset"),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        appCompatButton10.perform(click())

        val appCompatImageButton = onView(
            allOf(
                withContentDescription("Navigate up"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withClassName(`is`("com.google.android.material.appbar.AppBarLayout")),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton.perform(click())

        val appCompatImageButton2 = onView(
            allOf(
                withContentDescription("Open navigation drawer"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withClassName(`is`("com.google.android.material.appbar.AppBarLayout")),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton2.perform(click())

        val navigationMenuItemView = onView(
            allOf(
                childAtPosition(
                    allOf(
                        withId(R.id.design_navigation_view),
                        childAtPosition(
                            withId(R.id.nav_view),
                            0
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        navigationMenuItemView.perform(click())

        val appCompatCheckBox = onView(
            allOf(
                withId(R.id.flower_check_box), withText("Flowers"),
                childAtPosition(
                    allOf(
                        withId(R.id.LibraryLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatCheckBox.perform(click())

        val textView2 = onView(
            allOf(
                withId(R.id.libraryEntryTextView), withText("D"),
                childAtPosition(
                    allOf(
                        withId(R.id.library_entry_layout),
                        childAtPosition(
                            withClassName(`is`("com.oktopoi.library.LibraryEntryView")),
                            0
                        )
                    ),
                    1
                )
            )
        )
        textView2.perform(scrollTo(), click())

        val appCompatButton11 = onView(
            allOf(
                withId(R.id.DrawByHandLiveButton), withText("live"),
                childAtPosition(
                    allOf(
                        withId(R.id.DrawByHandControllerContainer),
                        childAtPosition(
                            withId(R.id.FlowerLayoutParent),
                            1
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        appCompatButton11.perform(click())

        val appCompatButton12 = onView(
            allOf(
                withId(R.id.PlayButton),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.LiveControllerContainer),
                        5
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton12.perform(click())

        val appCompatButton13 = onView(
            allOf(
                withId(R.id.LiveHandButton),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatButton13.perform(click())

        val appCompatButton14 = onView(
            allOf(
                withId(R.id.LiveHandButton),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatButton14.perform(click())

        val appCompatButton15 = onView(
            allOf(
                withId(R.id.SpeedButton), withText("1/1x"),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    7
                ),
                isDisplayed()
            )
        )
        appCompatButton15.perform(click())

        val appCompatButton16 = onView(
            allOf(
                withId(R.id.btnDoubleSpeed), withText("2/1x"),
                childAtPosition(
                    allOf(
                        withId(R.id.LivePlaybackSpeedContainer),
                        childAtPosition(
                            withId(R.id.LiveModeParent),
                            2
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        appCompatButton16.perform(click())

        val appCompatButton17 = onView(
            allOf(
                withId(R.id.SpeedButton), withText("2/1x"),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    7
                ),
                isDisplayed()
            )
        )
        appCompatButton17.perform(click())

        val appCompatButton18 = onView(
            allOf(
                withId(R.id.btnHalfSpeed), withText("1/2x"),
                childAtPosition(
                    allOf(
                        withId(R.id.LivePlaybackSpeedContainer),
                        childAtPosition(
                            withId(R.id.LiveModeParent),
                            2
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatButton18.perform(click())

        val appCompatButton19 = onView(
            allOf(
                withId(R.id.PlayButton),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.LiveControllerContainer),
                        5
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton19.perform(click())

        val appCompatButton20 = onView(
            allOf(
                withId(R.id.ResetButton), withText("reset"),
                childAtPosition(
                    allOf(
                        withId(R.id.LiveControllerContainer),
                        childAtPosition(
                            withClassName(`is`("android.widget.FrameLayout")),
                            1
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        appCompatButton20.perform(click())

        val appCompatImageButton3 = onView(
            allOf(
                withContentDescription("Navigate up"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withClassName(`is`("com.google.android.material.appbar.AppBarLayout")),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton3.perform(click())

        val appCompatButton21 = onView(
            allOf(
                withId(R.id.DrawByHandSaveButton),
                childAtPosition(
                    allOf(
                        withId(R.id.DrawByHandControllerContainer),
                        childAtPosition(
                            withId(R.id.FlowerLayoutParent),
                            1
                        )
                    ),
                    5
                ),
                isDisplayed()
            )
        )
        appCompatButton21.perform(click())

        val textInputEditText = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText.perform(replaceText("t"), closeSoftKeyboard())

        val appCompatButton22 = onView(
            allOf(
                withId(R.id.saveDialogButtonAccept), withText("OK"),
                childAtPosition(
                    allOf(
                        withId(R.id.saveDialogButtonContainer),
                        childAtPosition(
                            withId(R.id.saveDialogElementContainer),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton22.perform(click())
    }

    private fun childAtPosition(
        parentMatcher: Matcher<View>, position: Int
    ): Matcher<View> {

        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
                description.appendText("Child at position $position in parent ")
                parentMatcher.describeTo(description)
            }

            public override fun matchesSafely(view: View): Boolean {
                val parent = view.parent
                return parent is ViewGroup && parentMatcher.matches(parent)
                        && view == parent.getChildAt(position)
            }
        }
    }
}
