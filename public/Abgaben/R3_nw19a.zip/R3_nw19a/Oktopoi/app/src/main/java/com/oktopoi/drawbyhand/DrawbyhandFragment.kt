package com.oktopoi.drawbyhand

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.lifecycle.SavedStateViewModelFactory
import androidx.navigation.fragment.findNavController
//import androidx.navigation.fragment.navArgs
import androidx.navigation.navGraphViewModels
import com.oktopoi.MainActivity
import com.oktopoi.R
import com.oktopoi.curvetohand.CurveToHand
import com.oktopoi.library.*
import com.oktopoi.livemode.LiveModeViewModel
import com.oktopoi.utility.makeEditTextDialog
import com.oktopoi.utility.showToast
import kotlinx.android.synthetic.main.layout_drawbyhand_fragment.*

/**
 * This class allows the user to draw different closed figures with a touchpad, clear the drawing
 * and eventually calculate the figure.
 *
 * @property isLocked tells if the touch pad input is locked, default value is 'false'
 * @property libraryViewModel
 * @property liveButton button leading to LiveMode
 * @property mViewModel shared ViewModel with LiveModeFragment, allows passing a Drawing to
 * LiveMode in order to animate it
 */

class DrawbyhandFragment : Fragment(R.layout.layout_drawbyhand_fragment) {


    //    private val args: DrawbyhandFragmentArgs by navArgs() -> deprecated, replaced with ViewModel
    private var isLocked = false

    private val libraryViewModel: LibraryViewModel by navGraphViewModels(R.id.mobile_navigation)

    private lateinit var liveButton: Button

    private val mViewModel: LiveModeViewModel by navGraphViewModels(R.id.mobile_navigation)

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //Set title bar text
        (activity as MainActivity).supportActionBar?.title =
            resources.getString(R.string.menu_drawbyhand)

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        //Set ViewModel
        mViewModel.apply {
            SavedStateViewModelFactory(requireActivity().application, requireParentFragment())
        }

        liveButton = DrawByHandLiveButton

        //paintView is instantiated
        val paintView = PaintView(context!!)

        /*
        DrawPaintView is just a linear layout defined within the layout xml-file, so
        paintView with all its contents is added to DrawPaintView
         */
        DrawPaintView.addView(paintView)

        /*
        1. (formerly) DrawClearButton: attach onClickListener which clears the drawing and unlocks the touchpad
        input

        2. DrawCalculateButton: attach onClickListener which eventually returns the point list of the
        sampled path from the drawing
         */
        ClearButton.setOnClickListener {
            paintView.onClear()
            isLocked = false
        }

        liveButton.apply {

            setOnClickListener {

                val poiList = paintView.pointList
                if (poiList.isNotEmpty()) {

                    val curveToHand = CurveToHand(poiList, -20, 20)
                    val handList = curveToHand.calcHand()


                    mViewModel.setCurrentObjectToAnimate(Drawing(handList, poiList))

                    val action =
                        DrawbyhandFragmentDirections.actionNavDrawbyhandToLiveModeFragment()
                    findNavController().navigate(action)
                }
            }
        }

        DrawByHandSaveButton.apply {
            setOnClickListener {
                val saveDialog = makeEditTextDialog {
                    setTitle(context.resources.getString(R.string.hint_save_as_dialog))
                    eText.inputType = InputType.TYPE_CLASS_TEXT
                    positiveButtonClickListener {
                        val title = getInput().toString()
                        val fileHandler = FileHandler(context, LibraryFragment.directory)

                        val pointsList = paintView.onCalculate()
                        val data = Converter.pointsToString(pointsList)

                        if (fileHandler.fileExists("$title${FileFormatStrings[FileFormat.TouchPad]}")) {
                            showToast(context.resources.getString(R.string.file_name_taken))
                        } else if (!fileHandler.isValidFileName(title)) {
                            showToast(context.resources.getString(R.string.invalid_file_name))
                        } else if (fileHandler.writeFile(
                                "$title${FileFormatStrings[FileFormat.TouchPad]}",
                                data
                            )
                        ) {
                            showToast(
                                context.resources.getString(
                                    R.string.successfully_saved_file,
                                    title
                                )
                            )
                        } else {
                            showToast(context.resources.getString(R.string.failed_to_save_file))
                        }
                    }
                    negativeButtonClickListener {}
                }
                saveDialog.show()
            }
        }


        //attach onTouchListener which allows the user to draw if the touchpad is not locked
        paintView.setOnTouchListener { _, event ->
            val posX = event.x
            val posY = event.y

            // only 'false' if you start this fragment for the first time or if you press 'clear'
            if (!isLocked) {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> paintView.onActionDown(posX, posY)
                    MotionEvent.ACTION_MOVE -> paintView.onActionDrag(posX, posY)
                    MotionEvent.ACTION_UP -> {
                        //after closing the path, you can't draw again until you press 'clear'
                        paintView.onActionUp()
                        isLocked = true
                    }
                }
            }
            true
        }

        if (libraryViewModel.format == FileFormat.TouchPad) {

            println("Got a curve from library")

            paintView.onActionDown(
                libraryViewModel.pointList[0].first,
                libraryViewModel.pointList[0].second
            )
            for (point in libraryViewModel.pointList.subList(1, libraryViewModel.pointList.size)) {
                paintView.onActionDrag(point.first, point.second)
            }
            paintView.onActionUp()
            isLocked = true

            libraryViewModel.format = FileFormat.Unknown
        }

    }
}
