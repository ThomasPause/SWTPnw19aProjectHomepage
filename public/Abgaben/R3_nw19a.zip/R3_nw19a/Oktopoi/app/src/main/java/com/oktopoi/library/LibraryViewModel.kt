package com.oktopoi.library

import androidx.lifecycle.ViewModel

/**
 *
 * @property format format that is to be passed, set to Unknown if no file should be passed
 * @property radius
 * @property freq1
 * @property freq2
 * @property offset
 * @property pointList data for curves
 */
class LibraryViewModel : ViewModel() {


    var format: FileFormat = FileFormat.Unknown

    // Data for flowers
    var radius: Float = 0.0f
    var freq1: Int = 1
    var freq2: Int = 1
    var offset: Float = 0.0f

    var pointList: List<Pair<Float, Float>> = emptyList()
}