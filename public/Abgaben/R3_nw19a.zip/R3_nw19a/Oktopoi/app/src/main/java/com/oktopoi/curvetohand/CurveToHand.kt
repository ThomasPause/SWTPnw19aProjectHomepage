package com.oktopoi.curvetohand

import com.oktopoi.utility.Complex
import kotlin.math.*

/**
 * The CurveToHand class provides methods to calculate the hand curve to a given poi curve
 * via complex fourier transform.
 * The main radius is the greatest modulus of all fourier coefficients,
 * phase shift is the corresponding argument
 * and main frequency its corresponding frequency.
 *
 * Since there are countably many fourier coefficients, we can search for the main frequency only within a bounded range.
 * therefore we have the frequencies freqMin and freqMax as boundaries.
 *
 * @property poiCurve poi curve we want to calculate the hand curve for
 * @property freqMin lower boundary of the range where we search for the main frequency
 * @property freqMax upper boundary of the range where we search for the main frequency
 */
class CurveToHand(
    private val poiCurve: List<Pair<Float, Float>>,
    private val freqMin: Int,
    private val freqMax: Int
) {

    private val periodDuration: Int = poiCurve.size

    // We often need pi as a Float number, therefore we initialize it here instead of casting it every time
    private val pi = PI.toFloat()

    /* Calculating with floating point numbers may cause rounding errors which we don't want to detect.
       therefore we specify how accurate we want to test these numbers. */
    private val delta = 0.000001f

    /*
     * This function calculates the fourier coefficient for a given frequency as a complex number in cartesian coordinates
     * (pair of Floats where the first entry represents the real part and the second entry represents the imaginary part).
     *
     * @param freq frequency
     * @return fourier coefficient
     */
    internal fun fourier(freq: Int): Pair<Float, Float> {
        var cx = 0f
        var cy = 0f
        var a: Float
        var b: Float
        var x: Float
        var y: Float
        var point: Pair<Float, Float>

        for (t in 0 until periodDuration) {
            a = cos(2f * pi * freq * t / periodDuration)
            b = sin(2f * pi * freq * t / periodDuration)
            point = poiCurve[t]
            x = point.first
            y = point.second
            cx = cx + a * x + b * y
            cy = cy + a * y - b * x
        }

        cx /= periodDuration
        cy /= periodDuration

        return cx to cy

    }

    /*
     * This function searches for the fourier coefficient with the greatest absolute value (main radius)
     * for frequencies between freqMin and freqMax
     * and returns this coefficient in polar coordinates as well as the corresponding frequency (main frequency).
     *
     * @return triple consisting of the main frequency, the main radius and its corresponding argument (phase shift)
     */
    internal fun mainCircle(): Triple<Int, Float, Float> {

        /* The following variables will go through all possible fourier coefficients and their radii
         * to test which of the radii is the greatest.*/
        var coefficient: Pair<Float, Float>
        var radius: Float

        //In the following variables we store the values for the biggest radius we found so far.
        var currentFrequency = freqMin
        var currentCoefficient = fourier(freqMin)
        var currentRadius = Complex.calcRadius(currentCoefficient)

        for (k in freqMin..freqMax) {

            if (k != 0) {

                coefficient = fourier(k)
                radius = Complex.calcRadius(coefficient)

                if (currentRadius < radius - delta) {

                    currentFrequency = k
                    currentCoefficient = coefficient
                    currentRadius = radius

                }

            }

        }

        val phaseShift = Complex.calcAngle(currentCoefficient)

        return Triple(currentFrequency, currentRadius, phaseShift)
    }

    /**
     * This function calculates the hand movement to a curve (intended poi movement).
     *
     * @return list of coordinates that represent the hand movement
     */
    fun calcHand(): List<Pair<Float, Float>> {

        var result = mutableListOf<Pair<Float, Float>>()

        val mainCircle = mainCircle()
        val mainFreq =
            mainCircle.first.toFloat()  // mainFreq is the frequency between freqMin amd freqMax of the biggest fourier coefficient
        val mainRadius =
            mainCircle.second  // mainRadius is the biggest fourier coefficient for frequencies between freqMin and freqMax
        val mainPhaseShift = mainCircle.third

        var x: Float
        var y: Float
        val n = poiCurve.size
        var point: Pair<Float, Float>

        for (t in 0 until n) {
            point = poiCurve[t]
            x = point.first - mainRadius * cos(2f * pi * mainFreq * t / n + mainPhaseShift)
            y = point.second - mainRadius * sin(2f * pi * mainFreq * t / n + mainPhaseShift)
            result.add(Pair(x, y))
        }

        return result
    }
}