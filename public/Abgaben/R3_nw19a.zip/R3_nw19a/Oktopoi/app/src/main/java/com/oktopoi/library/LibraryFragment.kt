package com.oktopoi.library

import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.oktopoi.MainActivity
import com.oktopoi.R
import com.oktopoi.utility.makeEditTextDialog
import com.oktopoi.utility.makeSimpleAlertDialog
import com.oktopoi.utility.showToast
import kotlinx.android.synthetic.main.layout_library_fragment.*
import android.content.SharedPreferences
import android.util.TypedValue
import androidx.core.content.edit
import androidx.navigation.navGraphViewModels

/**
 * @property mViewModel
 * @property library_list the list that holds the LibraryEntryViews
 * @property flower_check_box checkbox to filter for flower files
 * @property touch_pad_check_box checkbox to filter for touch pad files
 * @property fileHandler
 *
 * @property oktopoiSettings
 * @property predefinedFilesInstalled
 *
 */

class LibraryFragment : Fragment(R.layout.layout_library_fragment) {

    private val mViewModel: LibraryViewModel by navGraphViewModels(R.id.mobile_navigation)

    private lateinit var libraryList: LinearLayout
    private lateinit var flowerCheckBox: CheckBox
    private lateinit var touchPadCheckBox: CheckBox
    private lateinit var fileHandler: FileHandler

    val oktopoiSettings = "oktopoiSettings"
    val predefinedFilesInstalled = "predefinedFilesInstalled"

    companion object {
        /**
         * The current instance of the LibraryFragment. Used by the LibraryEntryViews.
         */
        lateinit var instance: LibraryFragment

        /**
         * The directory where library files are saved
         */
        const val directory = "/library"
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //Set title bar text
        (activity as MainActivity).supportActionBar?.title =
            resources.getString(R.string.menu_library)

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        //sharedPreferences enthält die Information, ob die Default Dateien schon einmal geladen wurden
        val sharedPreferences = context?.getSharedPreferences(oktopoiSettings, Context.MODE_PRIVATE)

        if (sharedPreferences != null) {
            if (!sharedPreferences.getBoolean(predefinedFilesInstalled, false)) {
                installPredefinedFiles(sharedPreferences)
            }
        }

        // set the public accessor for this object
        instance = this

        // when we activate the filters, delete and rebuild all the entry views
        flowerCheckBox = flower_check_box
        flowerCheckBox.setOnClickListener {
            this@LibraryFragment.onPause()
            this@LibraryFragment.onResume()
        }
        touchPadCheckBox = touch_pad_check_box
        touchPadCheckBox.setOnClickListener {
            this@LibraryFragment.onPause()
            this@LibraryFragment.onResume()
        }
        flowerCheckBox.isChecked = true
        touchPadCheckBox.isChecked = true

        fileHandler = FileHandler(this.activity!!.applicationContext, directory)
    }

    /**
     * When the library was paused whe need to rebuild all the entry views,
     * because some other fragment may have made changes to the files.
     */
    override fun onResume() {
        super.onResume()

        libraryList = library_list
        createEntryViews()
    }

    /**
     * When the library is paused we better delete all the views,
     * because we rebuild them when we return.
     */
    override fun onPause() {
        super.onPause()

        libraryList.removeAllViews()
    }

    /*
     * Fills libraryList with views of all library entries.
     */
    private fun createEntryViews() {
        // get all the file names in the library directory
        var fileNames = mutableListOf<String>()
        fileNames.addAll(fileHandler.getFileNames())

        fileNames.sort()

        for (fileName: String in fileNames) {

            // retrieve file title and file format
            val fileFormat = fileHandler.getFileFormat(fileName)
            val title = fileHandler.getFileTitle(fileName)

            // if the file should be displayed, build a view
            if ((fileFormat == FileFormat.Flower && flower_check_box.isChecked) ||
                (fileFormat == FileFormat.TouchPad && touch_pad_check_box.isChecked) ||
                fileFormat == FileFormat.Unknown
            ) {

                val listEntry = LibraryEntryView(activity!!.baseContext, title, fileFormat, this)
                libraryList.addView(listEntry)
            }
        }
    }

    /**
     * Opens a saved flower in the FlowersFragment.
     *
     * @param fileName name of the flower file that is to be opened in the FlowersFragment
     */
    fun startFlowersFragment(fileName: String) {

        // Read data from the file
        mViewModel.format = FileFormat.Flower
        val data = fileHandler.readFile(fileName).split(" ")
        mViewModel.radius = data[0].toFloatOrNull()!!
        mViewModel.freq1 = data[1].toIntOrNull()!!
        mViewModel.freq2 = data[2].toIntOrNull()!!
        mViewModel.offset = data[3].toFloatOrNull()!!


        val action = LibraryFragmentDirections.actionNavLibraryToNavFlowers()
        findNavController().navigate(action)
    }

    /**
     * Opens a saved touchpad curve in the DrawByHandFragment.
     *
     * @param fileName name of the touchpad curve that is to be opened in the DrawByHandFragment
     */
    fun startDrawByHandFragment(fileName: String) {

        val data = fileHandler.readFile(fileName)

        mViewModel.format = FileFormat.TouchPad
        mViewModel.pointList = Converter.stringToPoints(data)

        val action = LibraryFragmentDirections.actionNavLibraryToNavDrawbyhand(
        )
        findNavController().navigate(action)
    }

    /**
     * Shows an EditDialogue to change a file name.
     *
     * @param entry the LibraryEntryView that links to the file that is to be renamed
     */
    fun showEditDialogue(entry: LibraryEntryView) {

        val editDialog = makeEditTextDialog {
            setTitle(resources.getString(R.string.rename_file_dialogue_title, entry.title))
            eText.inputType = InputType.TYPE_CLASS_TEXT
            eText.setText(entry.title)
            eText.setSelectAllOnFocus(true)
            positiveButtonClickListener {
                val newTitle = getInput().toString()
                if (!fileHandler.isValidFileName(newTitle)) {
                    showToast(resources.getString(R.string.invalid_file_name))
                } else if (fileHandler.fileExists("$newTitle${FileFormatStrings[entry.format]}")) {
                    showToast(resources.getString(R.string.file_name_taken))
                } else if (fileHandler.renameFile(
                        "${entry.title}${FileFormatStrings[entry.format]}",
                        "$newTitle${FileFormatStrings[entry.format]}"
                    )
                ) {
                    showToast(
                        resources.getString(
                            R.string.successfully_renamed_file,
                            entry.title,
                            newTitle
                        )
                    )
                    // restart library to reload the entries
                    this@LibraryFragment.onPause()
                    this@LibraryFragment.onResume()
                } else {
                    showToast(
                        resources.getString(
                            R.string.failed_to_rename_file,
                            entry.title,
                            newTitle
                        )
                    )
                }
            }
            negativeButtonClickListener {}
        }
        editDialog.show()
    }

    /**
     * Shows a dialogue to confirm the deletion of a file.
     *
     * @param entry the LibraryEntryView that links to the file that is to be deleted.
     */
    fun showDeletionDialog(entry: LibraryEntryView) {

        val deletionDialog = makeSimpleAlertDialog {
            setTitle(resources.getString(R.string.delete_file_dialogue_title, entry.title))
            setMessage(resources.getString(R.string.delete_file_warning_message))
            positiveButtonClickListener {
                if (fileHandler.deleteFile("${entry.title}${FileFormatStrings[entry.format]}")) {
                    showToast(resources.getString(R.string.successfully_deleted_file, entry.title))
                    libraryList.removeView(entry)
                } else {
                    showToast(resources.getString(R.string.failed_to_delete_file, entry.title))
                }
            }
            negativeButtonClickListener {}
        }
        deletionDialog.show()
    }

    /**
     *@param sharedPreferences
     *
     * */
    fun installPredefinedFiles(sharedPreferences: SharedPreferences) {

        sharedPreferences.edit {
            putBoolean(predefinedFilesInstalled, true)
            commit()
        }
    }
}
