package com.oktopoi.livemode

import androidx.lifecycle.ViewModel
import com.oktopoi.flowers.FlowersCalc

/**
 * LiveModeViewModel stores information relevant for both FlowersFragment and LiveModeFragment.
 * This information remains accessible beyond the fragment life cycle.
 *
 * @property currentObjectToAnimate the current flower / drawing that is to be displayed in LiveMode
 * @property currentFlower the last flower the user has created before leaving FlowersFragment
 * @property showHand stores showHand status so it is handed over to LiveMode, Flowers respectively
 */

class LiveModeViewModel : ViewModel() {

    private var currentObjectToAnimate: Any? = null
    private var currentFlower: FlowersCalc? = null
    var showHand: Boolean = false

    /**
     * sets the currentObjectToAnimate to the given object
     *
     * @param obj the object (FlowersCalc / Drawing) which is to be set
     */
    fun setCurrentObjectToAnimate(obj: Any) {
        this.currentObjectToAnimate = obj
    }

    /**
     * returns the currentObjectToAnimate
     *
     * @return currentObjectToAnimate (FlowersCalc or Drawing)
     */
    fun getCurrentObjectToAnimate(): Any? {
        return currentObjectToAnimate
    }

    /**
     * sets the currentFlower. This allows when reentering the FlowersFragment to show the same
     * flower which was active when leaving it
     *
     * @param flower the FlowersCalc to be stored
     */
    fun setCurrentFlower(flower: FlowersCalc) {
        this.currentFlower = flower
    }

    /**
     * returns the stored FlowersCalc
     *
     * @return the currently stored FlowersCalc
     */
    fun getCurrentFlower(): FlowersCalc? {
        return currentFlower
    }
}