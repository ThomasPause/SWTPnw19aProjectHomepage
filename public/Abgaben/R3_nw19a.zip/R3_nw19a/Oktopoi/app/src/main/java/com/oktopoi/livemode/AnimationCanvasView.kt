package com.oktopoi.livemode

import android.content.Context
import android.graphics.*
import android.graphics.Paint.ANTI_ALIAS_FLAG
import androidx.core.content.ContextCompat
import androidx.core.graphics.blue
import androidx.core.graphics.green
import androidx.core.graphics.red
import com.oktopoi.R
import com.oktopoi.utility.CanvasView

/**
 * Class to show and animate hand and flower path. Inherits all path functions from CanvasView.
 *
 * @property showHand indicates if hand curve visualization shall be displayed
 * @property animationPaused indicates if the animation has been paused
 * @property animationRunning indicated if the animation is running or has been stopped
 * @property renderThread thread for drawing onto canvas
 * @property running indicates if renderThread is running
 * @property flowerPath path of flower coordinates
 * @property handPath path of hand coordinates
 * @property padding distance to screen margin in percentage of screensize
 * @property poiPos the current position of the poi head during the animation
 * @property handPos the current position of the hand during the animation
 * @property poiList list of coordinates containing all points of poi path
 * @property handList list of coordinates containing all points of hand path
 * @property poiTrace list of coordinates containing all points of poi trace
 * @property animationSteps total amount of steps in the animation
 * @property currentStep current step the animation is in
 * @property lastStep step the animation was in last frame
 * @property TRACE_STROKE_WIDTH thickest point of the poi trace
 * @property colorFront color in the front of the poi trace
 * @property colorBack color in the back of the poi trace
 * @property playbackSpeedMultiplier multiplier for the playback speed
 * @property playbackSpeed current speed the animation is played back in
 * @property fpsCount current frames per second count
 * @property flowerPaint paint for drawing the underlying flower path
 * @property handPaint paint for drawing the underlying hand path
 * @property animatedHandPaint paint for drawing the circle representing current hand position
 * @property animatedPoiPaint paint for drawing the circle representing current poi position
 * @property tracePaint paint for defining minimal attributes for drawing the poi trace (colors for
 * the trace are defined with colorFront / colorBack)
 * @property stringPaint paint for drawing the string connecting the hand to the poi
 */
class AnimationCanvasView(context: Context?, viewSize: Pair<Int, Int>) :
    CanvasView(context, viewSize), Runnable {

    var showHand = false
    private var animationPaused: Boolean = false
    private var animationRunning: Boolean = false

    private var renderThread = Thread(this)
    private var running = false

    private var flowerPath: Path = Path()
    private var handPath: Path = Path()

    override val padding = 0.00f

    private var poiPos: Pair<Float, Float> = Pair(0f, 0f)
    private var handPos: Pair<Float, Float> = Pair(0f, 0f)

    private var poiList: List<Pair<Float, Float>>? = null
    private var handList: List<Pair<Float, Float>>? = null

    private var poiTrace: MutableList<Pair<Float, Float>> = mutableListOf()

    private var animationSteps: Int = 0
    private var currentStep: Int = 0
    private var lastStep: Int = 0

    private val TRACE_STROKE_WIDTH = 15f
    private val colorFront = Color.rgb(255, 0, 157)
    private val colorBack = Color.rgb(0, 233, 255)

    var playbackSpeedMultiplier = 4f
    var playbackSpeed: Float = 1.0f

    private var fpsCount: Float = 0f

//    private var combinedPathBoundsPath = Path() -> for debugging the scaling

    private val flowerPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        alpha = 200
        pathEffect = CornerPathEffect(10f)
    }

    private val handPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(getContext().applicationContext, R.color.colorAccent)
        style = Paint.Style.STROKE
    }

    private val animatedHandPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(100, 255, 100)
        style = Paint.Style.FILL
    }

    private val animatedPoiPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = colorFront
        style = Paint.Style.FILL
    }

    private val tracePaint = Paint(ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val stringPaint = Paint(ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(200, 200, 200)
        style = Paint.Style.STROKE
    }

//    private val debugTextPaint = Paint(ANTI_ALIAS_FLAG).apply {
//        color = Color.WHITE
//        style = Paint.Style.FILL
//        textAlign = Paint.Align.LEFT
//        textSize = 30f
//    }

    /**
     * update is called to hand over a poi and a hand list to the animationCanvas. Those lists of
     * coordinates are then scaled to size, transformed into a path object to show the underlying poi
     * and hand curve, and then transformed back to a coordinate list in order to be able to animate
     * both hand and poi step by step.
     *
     * @param flowerPointList a ordered list containing coordinates of the poi path
     * @param handPointList a ordered list containing coordinates of the hand path
     */
    fun update(
        flowerPointList: List<Pair<Float, Float>>,
        handPointList: List<Pair<Float, Float>>
    ) {
        flowerPath = pointsToPath(flowerPointList)
        handPath = pointsToPath(handPointList)
        val combinedPath = Path()
        combinedPath.apply {
            addPath(flowerPath)
            addPath(handPath)
        }

        val combinedPathBounds = RectF()
        combinedPath.computeBounds(combinedPathBounds, true)
        var scaleFactor = getScaleFactor(combinedPathBounds)
        scaleFactor *= (1 - 2 * 0.05f)
        val combinedPathCenterScaled = Pair(
            combinedPathBounds.centerX() * scaleFactor,
            combinedPathBounds.centerY() * scaleFactor
        )

        flowerPath.apply {
            scalePath(scaleFactor)
            translatePath(combinedPathCenterScaled)
        }

        handPath.apply {
            scalePath(scaleFactor)
            translatePath(combinedPathCenterScaled)
        }

////      DEBUGGING THE SCALING
//        combinedPathBoundsPath = Path()
//        combinedPathBoundsPath.addRect(combinedPathBounds, Path.Direction.CW)
//
//        combinedPathBoundsPath.apply {
//            scalePath(scaleFactor)
//            translatePath(combinedPathCenterScaled)
//        }

        //first of all disable animation
        var animationWasPlaying = false

        if (animationRunning) {
            animationRunning = false
            animationWasPlaying = true
        }

        poiList = transformPointsInPointList(flowerPointList, scaleFactor, combinedPathCenterScaled)
        handList = transformPointsInPointList(handPointList, scaleFactor, combinedPathCenterScaled)

        animationSteps = poiList!!.size

        //continue animation
        if (animationWasPlaying) {
            animationRunning = true
        }
    }

    /*
     * transformPointsInPointList scales and translates every point (coordinate) in a list
     * corresponding to a scale factor and a center point, which has to be determined beforehand
     * depending on the combined size of the poi and hand curve to be displayed.
     *
     * @param list list of coordinates
     * @param scaleFactor factor by which every point is supposed to be scaled by
     * @param center shifted center point towards which every point is supposed to be translated
     * @return the scaled and translated list of coordinates
     */
    private fun transformPointsInPointList(
        list: List<Pair<Float, Float>>,
        scaleFactor: Float,
        center: Pair<Float, Float>
    ): MutableList<Pair<Float, Float>> {
        val transformedPoints = mutableListOf<Pair<Float, Float>>()
        list.forEach {
            val scale = scaleFactor * (1 - (2 * padding))

            val itScaled =
                Pair(it.first * scale, it.second * scale)

            val transX = canvasWidth / 2f - center.first
            val transY = canvasHeight / 2f - center.second

            val itTranslated =
                Pair(itScaled.first + transX, itScaled.second + transY)
            transformedPoints.add(itTranslated)
        }
        return transformedPoints
    }

    /*
     * interpolateColors takes two colors as Ints and a time parameter t and calculates for every
     * color channel (R, G, B) the corresponding values depending on t and returns them as a color
     * as Int.
     */
    private fun interpolateColors(c1: Int, c2: Int, t: Float): Int {
        val r1 = c1.red
        val r2 = c2.red
        val g1 = c1.green
        val g2 = c2.green
        val b1 = c1.blue
        val b2 = c2.blue

        val r3 = (r1.toFloat() * (1 - t) + r2.toFloat() * t).toInt()
        val g3 = (g1.toFloat() * (1 - t) + g2.toFloat() * t).toInt()
        val b3 = (b1.toFloat() * (1 - t) + b2.toFloat() * t).toInt()

        return Color.rgb(r3, g3, b3)
    }

    /*
     * Different playback speeds are obtained by manipulating the number of the steps by which
     * the position in the poi and hand array jumps forward. For faster playback speeds more
     * elements are skipped for every iteration. To avoid holes in the poi trace in those cases,
     * we store the number of the last step and calculate all the elements in the array that
     * have been skipped due to fast playback speed and therefore were not added to the poi trace.
     * Those skipped elements are then added manually. If the trace reaches a certain length, the
     * last x elements are popped from the array, with the amount of elements to be popped depending on
     * the playback speed.
     */
    private fun updatePos() {

        //update poi position
        val increments = (playbackSpeed * playbackSpeedMultiplier).toInt()
        currentStep =
            if (currentStep < animationSteps - increments) (currentStep + increments) else 0
        poiPos = poiList!![currentStep]

        //add all elements to trace that lay between the current and the last step
        if (currentStep >= lastStep) {
            for (i in 0 until (currentStep - lastStep)) {
                poiTrace.add(0, poiList!![lastStep + i + 1])
            }
        } else {
            if (lastStep < poiList!!.size - 1) {
                for (i in (lastStep + 1) until (poiList!!.size)) {
                    poiTrace.add(0, poiList!![i])
                }
            }
            for (i in 0 until currentStep + 1) {
                poiTrace.add(0, poiList!![i])
            }
        }

        //cut trace if longer than maxLength
        val maxTraceLength = animationSteps * 0.75
        if (poiTrace.size >= maxTraceLength) {
            for (i in 0..increments) {
                poiTrace.removeIf {
                    it == poiTrace.last()
                }
            }
        }

        //update hand position
        handPos = handList!![currentStep]

        lastStep = currentStep
    }

    /**
     * Starts the animation.
     */
    fun startAnimation() {
        animationRunning = true
        animationPaused = false

        //update pos once to avoid artifacts
        updatePos()
    }

    /**
     * Pauses the animation.
     */
    fun pauseAnimation() {
        animationRunning = false
        animationPaused = true
    }

    /**
     * Stops the animation.
     */
    fun stopAnimation() {
        animationRunning = false
        animationPaused = false
    }

    /*
     * Resets the animation.
     */
    private fun resetAnimation() {
        currentStep = 0
        lastStep = 0
        clearTrace()
    }

    /*
     * Clears the poi trace, so if the animation is started once again, the trace starts to build
     * up from 0.
     */
    private fun clearTrace() {
        poiTrace.clear()
    }

    /**
     * draw creates a canvas object to be drawn on via the SurfaceHolder's lockCanvas-method.
     * The flower and if required the hand curve will be drawn and, as soon as unlockCanvasAndPost
     * is called, shown on the surface.
     */
    override fun draw() {
        if (holder.surface.isValid) {
            canvas = holder.lockCanvas()

            canvas.drawPaint(backgroundPaint)

            if (showHand) {
                canvas.drawPath(handPath, handPaint)
            }
            canvas.drawPath(flowerPath, flowerPaint)

//            //DEBUGGING: SHOW BOUNDS OF COMBINED PATHS TO DEBUG SCALING
//            canvas.drawPath(combinedPathBoundsPath, handPaint)

            if (animationRunning || animationPaused) {

                //Draw Hand and String
                if (showHand) {
                    val handX = handPos.first
                    val handY = handPos.second

                    canvas.drawCircle(handX, handY, TRACE_STROKE_WIDTH, animatedHandPaint)
                    canvas.drawLine(handX, handY, poiPos.first, poiPos.second, stringPaint)

                    //Show length of String (for debugging) --> deactivated
                    /*val stringLength =
                        sqrt((handX - poiPos.first).pow(2) + (handY - poiPos.second).pow(2))
                    canvas.drawText(
                        stringLength.toInt().toString(),
                        handX + TRACE_STROKE_WIDTH,
                        handY,
                        debugTextPaint
                    )*/
                }

                //Draw Trace
                if (poiTrace.size > 2) {

                    /*Reverse poiTrace-list, so the elements are drawn beginning at the end,
                    so the poi head is drawn last, therefore has the highest "z-value"*/
                    val reversePoiTrace = poiTrace.asReversed()

                    for (i in 0 until reversePoiTrace.size - 2) {

                        val thisElem = reversePoiTrace[i]
                        val nextElem = reversePoiTrace[i + 1]

                        val step = i / reversePoiTrace.size.toFloat()
                        val strokeWidth =
                            TRACE_STROKE_WIDTH * (step) + TRACE_STROKE_WIDTH / 10 * (1 - step)

                        tracePaint.color = interpolateColors(colorBack, colorFront, step)

                        /* Calling strokeWidth for every point in trace (up to 2000) is very
                         inefficient, yet necessary
                         TODO("Find slimmer way to draw trace without calling "strokeWidth" that often")
                         https://medium.com/rosberryapps/make-your-custom-view-60fps-in-android-4587bbffa557*/
                        tracePaint.strokeWidth = strokeWidth

                        canvas.drawLine(
                            thisElem.first,
                            thisElem.second,
                            nextElem.first,
                            nextElem.second,
                            tracePaint
                        )
                    }
                }

                //Draw Poi Head
                canvas.drawCircle(poiPos.first, poiPos.second, TRACE_STROKE_WIDTH, animatedPoiPaint)

            }
            //Show FPS counter --> deactivated
            //canvas.drawText(fpsCount.toInt().toString(), canvasWidth - 100f, 50f, debugTextPaint)

            holder.unlockCanvasAndPost(canvas)
        }
    }

    override fun run() {
        var beginTime: Long
        var timeDiff: Long
        val fpsStack = FloatArray(50)
        var counter = 0

        while (running) {
            //Calc fps
            beginTime = System.currentTimeMillis()

            //Update animation
            if (animationRunning) {
                updatePos()
            } else if (!animationRunning && !animationPaused) {
                //Check if Trace has already been reset
                if (poiTrace.isNotEmpty()) {
                    /*
                    Clear Trace and reset animation, do this here - within the thread - otherwise
                    the code may crash, because the thread tries to draw the trace, which has been
                    cleared already
                    */

                    resetAnimation()
                }
            }
            draw()
            timeDiff = System.currentTimeMillis() - beginTime
            fpsStack[counter] = 1000f / timeDiff

            var fpsAverage = 0f
            for (i in fpsStack.indices) {
                fpsAverage += fpsStack[i]
            }
            fpsAverage /= fpsStack.size
            fpsCount = fpsAverage

            counter = if (counter < fpsStack.size - 1) counter + 1 else 0
        }
    }

    /**
     * When FlowerFragment calls resume and running is set to true, the process of drawing onto the
     * canvas is launched by the run and draw methods. For each resume a new renderThread is created
     * and started.
     *
     */
    fun resume() {
        running = true
        if (renderThread.state == Thread.State.TERMINATED) {
            renderThread = Thread(this)
        }
        renderThread.start()
    }

    /**
     * When FlowerFragment calls pause, the main thread waits for the renderThread to terminate.
     *
     * @throws Exception
     *
     */
    fun pause() {
        running = false
        while (true) {
            try {
                renderThread.join()
                break
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
