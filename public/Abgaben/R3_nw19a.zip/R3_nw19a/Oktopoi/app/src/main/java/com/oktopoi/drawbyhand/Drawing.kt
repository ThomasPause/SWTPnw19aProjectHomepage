package com.oktopoi.drawbyhand

/**
 * Class representing a Drawing drawn by the user in DrawByHandMode. Allows for a drawing to be
 * passed to LiveMode
 *
 * @property hand list of coordinates representing the hand curve
 * @property poi list of coordinates representing to poi curve resulting from the hand curve
 */

class Drawing(var hand: List<Pair<Float, Float>>, var poi: List<Pair<Float, Float>>) {
}