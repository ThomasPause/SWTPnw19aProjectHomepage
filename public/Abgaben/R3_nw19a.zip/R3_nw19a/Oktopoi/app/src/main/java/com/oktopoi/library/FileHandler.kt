package com.oktopoi.library

import android.content.Context
import android.widget.Toast
import com.oktopoi.utility.showToast
import com.oktopoi.R
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Enum of all supported file formats.
 */
enum class FileFormat {
    Flower,
    TouchPad,
    Unknown
}

/**
 * Maps the file formats to the file name https://developer.android.com/reference/android/os/Parcel.html#primitives
 */
val FileFormatStrings =
    mapOf(
        FileFormat.Flower to ".flw",
        FileFormat.TouchPad to ".tp",
        FileFormat.Unknown to ""
    )

val example_flowers = mapOf(
    "ChurchWindow.flw" to R.string.church_window,
    "SevenPointedStar.flw" to R.string.seven_pointed_star
)

val example_curves = mapOf(
    "D.tp" to R.string.square,
    "nothing.tp" to R.string.diamond,
    "inkblob.tp" to R.string.test_curve
)

val example_files = example_flowers + example_curves

/**
 * Static class with basic functionality to read, write files into the internal storage.
 */
class FileHandler(private val context: Context, private val directory: String) {

    /**
     * Writes data into a file. Overwrites files with the same name.
     *
     * @param fileName name of the file to be written
     * @param data whatever is to be written into the file
     * @return true if the file was written
     */
    fun writeFile(fileName: String, data: String): Boolean {
        try {
            val internalDirectory = File(context.filesDir.toString() + directory)
            if (!internalDirectory.exists()) {
                if (!internalDirectory.mkdir()) {
                    throw Exception("Unable to make directory $internalDirectory")
                }
            }

            val file = File(internalDirectory.toString(), fileName)
            FileOutputStream(file).use {
                it.write(data.toByteArray())
                return true
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    /**
     * Appends data to the end of a file. If the file does not yet exist, it is created.
     * @param fileName name of the file to append to
     * @param data whatever is to be written into the file
     */
    fun appendFile(fileName: String, data: String) {
        try {
            val internalDirectory = File(context.filesDir.toString() + directory)
            if (!internalDirectory.exists()) {
                if (!internalDirectory.mkdir()) {
                    throw Exception("Unable to make directory $internalDirectory")
                }
            }

            val file = File(internalDirectory, fileName)
            file.appendText(data)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Reads data from a file in internal storage.
     * @param fileName name of the file to be read
     * @return content of that file, otherwise (if file does not exist) empty string
     */
    fun readFile(fileName: String): String {
        if (example_files.containsKey(fileName)) {
            return context.resources.getString(example_files.getValue(fileName))
        }
        return try {
            val path = context.filesDir.toString() + directory
            val file = File(path, fileName)

            FileInputStream(file).bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            e.printStackTrace()
            ""
        }
    }

    /**
     * Deletes a file from internal storage.
     * @param fileName file to be deleted
     * @return true if file was deleted
     */
    fun deleteFile(fileName: String): Boolean {
        try {
            val filesDir: File = context.filesDir
            val targetDir = File(filesDir.toString() + directory)
            val file = File(targetDir, fileName)
            return file.delete()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    /**
     *
    @param oldFile
    @param newFile
    @return
     * */
    fun renameFile(oldFile: String, newFile: String): Boolean {
        try {
            val filesDir: File = context.filesDir
            val targetDir = File(filesDir.toString() + directory)
            val file = File(targetDir, oldFile)
            file.renameTo(File(targetDir, newFile))

            return true
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    /**
     * Returns the names of all files in the root of the app's storage.
     *
     * @return List of the names from all files in the root folder of the app's internal storage
     */
    fun getFileNames(): List<String> {
        var fileNames = mutableListOf<String>()
        try {
            val path = context.filesDir

            val targetDir = path.toString() + directory
            val dirFileObj = File(targetDir)
            val files = dirFileObj.listFiles()

            if (files != null) {
                for (file in files) {
                    // get all file names from the Library folder
                    fileNames.add(file.toString().split('/').last())
                }
            }
            // get all file names from the res files
            fileNames.addAll(example_files.keys)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return fileNames
    }

    /**
     *
     * @param fileName
     * @return
     * */
    fun fileExists(fileName: String): Boolean {
        if (example_files.containsKey(fileName))
            return true

        val file = File(context.filesDir.toString() + directory + "/" + fileName)
        return file.exists()
    }

    /**
     *
     * @param name
     * @return
     * */
    fun isValidFileName(name: String): Boolean {
        if (name.contains('/') || name.isEmpty() || name.contains('.')) {
            return false
        }
        return true
    }

    /**
     *
     * @param fileName
     * @return
     * */
    fun getFileTitle(fileName: String): String {
        return fileName.split('.').first()
    }

    /**
     *
     * @param fileName
     * @return
     * */
    fun getFileFormat(fileName: String): FileFormat {
        return when (fileName.split('.').last()) {
            "flw" -> {
                FileFormat.Flower
            }
            "tp" -> {
                FileFormat.TouchPad
            }
            else -> FileFormat.Unknown
        }
    }


}
