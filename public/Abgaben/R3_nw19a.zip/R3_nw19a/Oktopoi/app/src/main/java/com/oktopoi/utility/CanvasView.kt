package com.oktopoi.utility

import android.content.Context
import android.graphics.*
import android.view.SurfaceView
import androidx.core.content.ContextCompat
import com.oktopoi.R

/**
 * Abstract class that provides canvas for drawing on and methods for calculating paths from
 * point lists and also path transformation methods
 *
 * @param context the context where the view is embedded in
 * @param viewSize the size of the view, needs to be determined by hosting fragment, in order for
 * the scale and translate methods to work
 *
 * @property canvas canvas for displaying flower and hand forms
 * @property canvasHeight height of canvas
 * @property canvasWidth width of canvas
 * @property padding distance to screen margin in percent of screensize
 * @property baseStrokeWidth strokeWidth relative to canvas size
 *
 */
abstract class CanvasView(context: Context?, viewSize: Pair<Int, Int>) :
    SurfaceView(context) {

    var canvasWidth = 0
    var canvasHeight = 0

    var canvas: Canvas = Canvas()

    var baseStrokeWidth: Float = 0f

    abstract val padding: Float

    val backgroundPaint = Paint().apply {
        color = ContextCompat.getColor(getContext().applicationContext, R.color.backgroundColor)
    }

    /**
     * The width and the height of the view is set here, based on the passed params.
     * Also the baseStrokeWidth is set as 1/100 of the pixel of the canvas (width-wise); this
     * allows to use this canvas class in basically every size and on every device with consistent
     * stroke width.
     */
    init {
        canvasWidth = viewSize.first
        canvasHeight = viewSize.second
        baseStrokeWidth = canvasWidth / 100f
    }

    abstract fun draw()

    /**
     * pointsToPath converts a given list of 2-dimensional coordinates to a Path object.
     * After the first tuple in the list is set as the path's starting point, an iterator over the list
     * delivers one point after the other and adds it to the path. At the end of the process, the contour of the path
     * is closed.
     *
     * @param pointList list of cartesian coordinates (pairs of x,y positions)
     * @return Path
     */
    fun pointsToPath(pointList: List<Pair<Float, Float>>): Path {
        val path = Path()
        path.moveTo(pointList[0].first, pointList[0].second)
        for (point in pointList) {
            path.lineTo(point.first, point.second)
        }
        path.close()
        return path
    }


    /**
     * getScaleFactor computes the factor by which a given rectangle needs to be
     * scaled to fit into the canvas. Between rectangle width and height, the greater value is used for
     * computing the scale factor. Since the canvas is designed to be square, the canvas width can be used
     * as numerator for either.
     *
     * @param pathBounds bounding rectangle of the path(s)
     * @return canvasWidth / scaleBy
     *
     */
    fun getScaleFactor(pathBounds: RectF): Float {
        val scaleBy = maxOf(pathBounds.width(), pathBounds.height())
        return canvasWidth.toFloat() / scaleBy
    }

    /**
     * scalePath scales a given path object to the desired size by calling the path class' transform-method.
     * The associated matrix object is defined to be scaled by the factor that getScaleFactor computes,
     * although factoring in a small distance to the canvas margin for design reasons.
     *
     * @param scaleFactor Float
     */
    fun Path.scalePath(scaleFactor: Float) {
        val scaleMatrix = Matrix()
        val scaleFactorWithPadding = scaleFactor * (1 - padding * 2)
        scaleMatrix.setScale(
            scaleFactorWithPadding,
            scaleFactorWithPadding
        )
        this.transform(scaleMatrix)
    }

    /**
     * translatePath relocates a given path object to the middle of the canvas. For that, the distance
     * between the canvas center and the center of the path contour (which will already be scaled when
     * this method is called) is used as translating factor for the associated matrix object.
     *
     * @param center Pair<Float, Float>
     */
    fun Path.translatePath(center: Pair<Float, Float>) {
        val translateMatrix = Matrix()
        translateMatrix.setTranslate(
            canvasWidth / 2f - center.first,
            canvasHeight / 2f - center.second
        )
        this.transform(translateMatrix)
    }
}
