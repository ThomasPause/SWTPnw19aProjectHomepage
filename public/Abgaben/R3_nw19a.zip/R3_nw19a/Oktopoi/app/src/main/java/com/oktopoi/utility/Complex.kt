package com.oktopoi.utility

import kotlin.math.*

object Complex {

    // since pi is often needed as a float number we introduce it here instead of casting it everywhere
    private val pi = PI.toFloat()

    // delta specifies the accuracy to which we want to test float numbers for equality
    private const val delta = 0.000001f

    /**
     * this function calculates the modulus (= distance to 0 / radius) of a given complex number in cartesian coordinates
     * (Pair of Floats where the first entry represents the real part and the second entry represents the imaginary part)
     *
     * @param numberCart complex number in cartesian coordinates
     * @return distance of the given number to 0 in the Gaussian plain
     */
    fun calcRadius(numberCart: Pair<Float, Float>): Float {
        val x = numberCart.first
        val y = numberCart.second
        return sqrt(x * x + y * y)
    }

    /**
     * this function returns the argument (= angle to real axis) of a complex number given in cartesian coordinates
     * (Pair of Floats where the first entry represents the real part and the second entry represents the imaginary part)
     *
     * note that for numbers in the first  quadrant the result is between 0 and pi/2
     *                              second quadrant the result is between pi/2 and pi
     *                              third  quadrant the result is between pi and 3/4 pi
     *                              fourth quadrant the result is between -pi/2 and 0
     * for purely imaginary numbers with negative imaginary part the result is -pi/2
     * for 0 it's 0
     *
     * since testing for 0 on float numbers may lead to unpredictable results,
     * we test only if the variables deviate more than delta from 0
     *
     * @param numberCart complex number in cartesian coordinates
     * @return angle between the given number and the real axis in the Gaussian plain
     */
    fun calcAngle(numberCart: Pair<Float, Float>): Float {
        val x = numberCart.first
        val y = numberCart.second

        return if (x < delta && 0f - delta < x) {   // if x = 0 ...
            if (y < delta && 0f - delta < y) {        // if x = 0 and y = 0 ...
                0f
            } else if (delta < y) {                 // if x = 0 and y > 0 ...
                pi / 2f
            } else {                                // if x = 0 and y < 0 ...
                -pi / 2f
            }
        } else {                                    // if x != 0 ...
            val phi = atan(y / x)
            if (delta < x) {                        // if x > 0
                phi
            } else {                                // if x < 0
                phi + pi

            }
        }

    }

    /**
     * this function calculates the real part of a given complex number in polar coordinates
     * (Pair of Floats where the first entry represents the modulus and the second entry represents the argument)
     *
     * @param numberPolar complex number in polar coordinates
     * @return real part of the given number
     */
    fun calcRe(numberPolar: Pair<Float, Float>): Float {
        val radius = numberPolar.first
        val angle = numberPolar.second
        return radius * cos(angle)
    }

    /**
     * this function calculates the imaginary part of a given complex number in polar coordinates
     * (Pair of Floats where the first entry represents the modulus and the second entry represents the argument)
     *
     * @param numberPolar complex number in polar coordinates
     * @return imaginary part of the given number
     */
    fun calcIm(numberPolar: Pair<Float, Float>): Float {
        val radius = numberPolar.first
        val angle = numberPolar.second
        return radius * sin(angle)
    }

}