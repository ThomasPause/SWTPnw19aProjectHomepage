package com.oktopoi

import com.oktopoi.flowers.FlowersCalc
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import kotlin.math.sqrt

class FlowersCalcTest {

    /* calculating with floating point numbers may cause rounding errors which we don't want to detect
        therefor we specify here the accuracy to which we want to test these numbers*/
    private val delta = 0.0001f

    // Arrange
    private val flower0 = FlowersCalc(0.0f, 0, 0, 0.0f, 600)
    private val flower1 = FlowersCalc(1.5f, 0, 1, 0.5f, 30)
    private val flower2 = FlowersCalc(1f, 2, 0, 2.25f, 50)
    private val flower3 = FlowersCalc(2.7f, -4, 1, 1.0f / 3.0f, 12)
    private val flower4 = FlowersCalc(0.8f, -7, -12, 0.25f, 48)
    private val flower5 = FlowersCalc(0.001f, 12, 8, 4.0f, 120)
    private val flower6 = FlowersCalc(4f / 3f, 10, -5, 0.75f, 12)
    private val flower7 = FlowersCalc(1.2f, 117000, 65000, 0.125f, 24)
    private val flower8 = FlowersCalc(0.5f, 3, -3, 0.0f, 9)
    private val flower9 = FlowersCalc(1f, 1, -1, 0.5f, 20)

    /*
         * In this test we verify that the greatestCommonDivisor() function works correctly
         * cases tested: normal input, big numbers, zero input, different signs
         */
    @Test
    fun `Test greatestCommonDivisor to assert greatest common divisor of freq1 and freq 2`() {

        val gcd0 = flower0.greatestCommonDivisor()
        assertEquals(gcd0, 1, "flower0: freq1 = 0, freq2 = 0")

        val gcd1 = flower1.greatestCommonDivisor()
        assertEquals(gcd1, 1, "flower1: freq1 = 0, freq2 = 1")

        val gcd2 = flower2.greatestCommonDivisor()
        assertEquals(gcd2, 1, "flower2: freq1 = 2, freq2 = 0")

        val gcd3 = flower3.greatestCommonDivisor()
        assertEquals(gcd3, 1, "flower3: freq1 = -4, freq2 = 1")

        val gcd4 = flower4.greatestCommonDivisor()
        assertEquals(gcd4, 1, "flower4: freq1 = -7, freq2 = -12")

        val gcd5 = flower5.greatestCommonDivisor()
        assertEquals(gcd5, 4, "flower5: freq1 = 12, freq2 = 8")

        val gcd6 = flower6.greatestCommonDivisor()
        assertEquals(gcd6, 5, "flower6: freq1 = 10, freq2 = -5")

        val gcd7 = flower7.greatestCommonDivisor()
        assertEquals(gcd7, 13000, "flower7: freq1 = 117000, freq2 = 65000")

        val gcd8 = flower8.greatestCommonDivisor()
        assertEquals(gcd8, 3, "flower8: freq1 = 3, freq2 = 3")

        val gcd9 = flower9.greatestCommonDivisor()
        assertEquals(gcd9, 1, "flower9: freq1 = 1, freq2 = -1")

    }


    /*
         * this test makes sure that the xHand(t) function calculates the x position of the hand at time t correctly
         */
    @Test
    fun `Test xHand to assert x position of hand at time t`() {

        val xHand0 = flower0.xHand(0)
        assertEquals(xHand0, 1f, delta, "flower0 (t=0)")

        val xHand1 = flower1.xHand(5)
        assertEquals(xHand1, 1f, delta, "flower1 (t=0)")

        val xHand2 = flower2.xHand(30)
        assertEquals(xHand2, 0.30902f, delta, "flower2 (t=0)")

        val xHand3 = flower3.xHand(15)
        assertEquals(xHand3, 1f, delta, "flower3 (t=0)")

        val xHand4 = flower4.xHand(11)
        assertEquals(xHand4, -0.79335f, delta, "flower4 (t=0)")

        val xHand5 = flower5.xHand(55)
        assertEquals(xHand5, -0.70711f, delta, "flower5 (t=0)")

        val xHand6 = flower6.xHand(1)
        assertEquals(xHand6, 0.5f, delta, "flower6 (t=0)")

        val xHand7 = flower7.xHand(0)
        assertEquals(xHand7, 1f, delta, "flower7 (t=0)")

        val xHand8 = flower8.xHand(4)
        assertEquals(xHand8, -0.93969f, delta, "flower8 (t=0)")

        val xHand9 = flower9.xHand(11)
        assertEquals(xHand9, -0.95106f, delta, "flower9 (t=0)")
    }

    /*
         * this test makes sure that the yHand(t) function calculates the x position of the hand at time t correctly
         */
    @Test
    fun `Test yHand to assert y position of hand at time t`() {

        val yHand0 = flower0.yHand(0)
        assertEquals(yHand0, 0f, delta, "flower0 (t=0)")

        val yHand1 = flower1.yHand(5)
        assertEquals(yHand1, 0f, delta, "flower1 (t=0)")

        val yHand2 = flower2.yHand(30)
        assertEquals(yHand2, 0.95106f, delta, "flower2 (t=0)")

        val yHand3 = flower3.yHand(15)
        assertEquals(yHand3, 0f, delta, "flower3 (t=0)")

        val yHand4 = flower4.yHand(11)
        assertEquals(yHand4, 0.60876f, delta, "flower4 (t=0)")

        val yHand5 = flower5.yHand(55)
        assertEquals(yHand5, 0.70711f, delta, "flower5 (t=0)")

        val yHand6 = flower6.yHand(1)
        assertEquals(yHand6, 0.86603f, delta, "flower6 (t=0)")

        val yHand7 = flower7.yHand(0)
        assertEquals(yHand7, 0f, delta, "flower7 (t=0)")

        val yHand8 = flower8.yHand(4)
        assertEquals(yHand8, 0.34202f, delta, "flower8 (t=0)")

        val yHand9 = flower9.yHand(11)
        assertEquals(yHand9, -0.30901f, delta, "flower9 (t=0)")
    }

    /*
         * this test makes sure that the xFlower(t) function calculates the x position of the poi head at time t correctly
         */
    @Test
    fun `Test xFlower to assert x position of poi at time t`() {

        val xFlower0 = flower0.xFlower(0)
        assertEquals(xFlower0, 1f, delta, "flower0 (t=0)")

        val xFlower1 = flower1.xFlower(5)
        assertEquals(xFlower1, 0.25f, delta, "flower1 (t=0)")

        val xFlower2 = flower2.xFlower(30)
        assertEquals(xFlower2, 0.30902f, delta, "flower2 (t=0)")

        val xFlower3 = flower3.xFlower(15)
        assertEquals(xFlower3, -1.338269f, delta, "flower3 (t=0)")

        val xFlower4 = flower4.xFlower(11)
        assertEquals(xFlower4, -1.59335f, delta, "flower4 (t=0)")

        val xFlower5 = flower5.xFlower(55)
        assertEquals(xFlower5, -0.70624f, delta, "flower5 (t=0)")

        val xFlower6 = flower6.xFlower(1)
        assertEquals(xFlower6, -1f / 6f, delta, "flower6 (t=0)")

        val xFlower7 = flower7.xFlower(0)
        assertEquals(xFlower7, 1.84853f, delta, "flower7 (t=0)")

        val xFlower8 = flower8.xFlower(4)
        assertEquals(xFlower8, -1.40954f, delta, "flower8 (t=0)")

        val xFlower9 = flower9.xFlower(11)
        assertEquals(xFlower9, 0f, delta, "flower9 (t=0)")
    }

    /*
         * this test makes sure that the yFlower(t) function calculates the y position of the poi head at time t correctly
         */
    @Test
    fun `Test yFlower to assert y position of poi at time t`() {

        val yFlower0 = flower0.yFlower(0)
        assertEquals(yFlower0, 0f, delta, "flower0 (t=0)")

        val yFlower1 = flower1.yFlower(5)
        assertEquals(yFlower1, -1.29904f, delta, "flower1 (t=0)")

        val yFlower2 = flower2.yFlower(30)
        assertEquals(yFlower2, 1.95106f, delta, "flower2 (t=0)")

        val yFlower3 = flower3.yFlower(15)
        assertEquals(yFlower3, -1.35f, delta, "flower3 (t=0)")

        val yFlower4 = flower4.yFlower(11)
        assertEquals(yFlower4, 0.60876f, delta, "flower4 (t=0)")

        val yFlower5 = flower5.yFlower(55)
        assertEquals(yFlower5, 0.70661f, delta, "flower5 (t=0)")

        val yFlower6 = flower6.yFlower(1)
        assertEquals(yFlower6, -0.28868f, delta, "flower6 (t=0)")

        val yFlower7 = flower7.yFlower(0)
        assertEquals(yFlower7, 0.84853f, delta, "flower7 (t=0)")

        val yFlower8 = flower8.yFlower(4)
        assertEquals(yFlower8, 0.17101f, delta, "flower8 (t=0)")

        val yFlower9 = flower9.yFlower(11)
        assertEquals(yFlower9, -0.61803f, delta, "flower9 (t=0)")
    }

    /*
         * This test verifies that calcHand() calculates the hand coordinates of flower6 correctly
         */
    @Test
    fun `Test calcHand() to assert list of hand coordinates`() {

        val a = sqrt(0.75f) // auxiliary variable emerges often in the expected result

        val result6: List<Pair<Float, Float>> = listOf(
            Pair(1f, 0f),
            Pair(0.5f, a),
            Pair(-0.5f, a),
            Pair(-1f, 0f),
            Pair(-0.5f, -a),
            Pair(0.5f, -a),
            Pair(1f, 0f),
            Pair(0.5f, a),
            Pair(-0.5f, a),
            Pair(-1f, 0f),
            Pair(-0.5f, -a),
            Pair(0.5f, -a)
        )
        val hand6 = flower6.calcHand()

        for (i in 0 until flower6.steps) {
            assertEquals(
                hand6[i].first,
                result6[i].first,
                delta,
                "flower6: x coordinate at time $i"
            )
            assertEquals(
                hand6[i].second,
                result6[i].second,
                delta,
                "flower6: y coordinate at time $i"
            )
        }
    }

    /*
         * This test verifies that calcFlower() calculates the flower coordinates of flower6 correctly
         */
    @Test
    fun `Test calcFlower() to assert list of flower coordinates`() {

        val a = 0.65470f // auxiliary variable emerges often in the expected result
        val b = 0.28868f // auxiliary variable emerges often in the expected result
        val c = 0.19936f // auxiliary variable emerges often in the expected result
        val d = 2.02073f // auxiliary variable emerges often in the expected result
        val e = 1.53269f // auxiliary variable emerges often in the expected result

        val result6: List<Pair<Float, Float>> = listOf(
            Pair(1f, -4f / 3f),
            Pair(-1f / 6f, -b),
            Pair(-1f - a, c),
            Pair(-7f / 3f, 0f),
            Pair(-1f - a, -c),
            Pair(-1f / 6f, b),
            Pair(1f, 4f / 3f),
            Pair(7f / 6f, d),
            Pair(a, e),
            Pair(1f / 3f, 0f),
            Pair(a, -e),
            Pair(7f / 6f, -d)
        )
        val f6 = flower6.calcFlower()

        for (i in 0 until flower6.steps) {
            assertEquals(f6[i].first, result6[i].first, delta, "flower6: x coordinate at time $i")
            assertEquals(f6[i].second, result6[i].second, delta, "flower6: y coordinate at time $i")
        }
    }
}