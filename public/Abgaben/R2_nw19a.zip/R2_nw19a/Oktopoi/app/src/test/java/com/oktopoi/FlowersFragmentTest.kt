package com.oktopoi

import com.oktopoi.flowers.FlowersFragment
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test


class FlowersFragmentTest {

    private val testFragment = FlowersFragment()

    @Test
    fun `Test validateInput regex matching`() {
        assertFalse(testFragment.validateInput("0"), "Value 0 should fail")
        assertFalse(testFragment.validateInput("05"), "Value 05 should fail")
        assertFalse(testFragment.validateInput("-"), "Value - should fail")
        assertFalse(testFragment.validateInput("-0.5"), "Value -0.5 should fail")
        assertTrue(testFragment.validateInput("-102"), "Value -102 should pass")
        assertTrue(testFragment.validateInput("99999950"), "Value 99999950 should pass")


    }
}
