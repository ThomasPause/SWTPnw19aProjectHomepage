package com.oktopoi

import android.view.View
import android.view.ViewGroup
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.filters.LargeTest
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.rule.ActivityTestRule
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers.`is`
import org.hamcrest.Matchers.allOf
import org.hamcrest.TypeSafeMatcher
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/*start app
create flower (2.2, 15, 7, 0.2)
save it as ‘F’
click ok
open NavigationDrawer
go to library Fragment
rename ‘F’ to ‘Flower’
uncheck flowers
check flowers
click on ‘Flower’
open NavigationDrawer
go to library Fragment
delete ‘Flower’
open NavigationDrawer
go to DrawByHand Fragment
press clear
press save and type in ‘D’
click ok
open NavigationDrawer
go to library Fragment
rename ‘D’ to ‘Drawing’
uncheck  touchpad curves
check  touchpad curves
delete ‘Drawing’*/

@LargeTest
@RunWith(AndroidJUnit4ClassRunner::class)
class End2EndTest {

    @Rule
    @JvmField
    var mActivityTestRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun end2EndTest() {
        val appCompatEditText = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("0.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText.perform(click())

        val appCompatEditText2 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("0.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText2.perform(replaceText("2.2"))

        val appCompatEditText3 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("2.2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText3.perform(closeSoftKeyboard())

        val appCompatEditText4 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("2.2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText4.perform(pressImeActionButton())

        val appCompatEditText5 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText5.perform(replaceText("15"))

        val appCompatEditText6 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("15"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText6.perform(closeSoftKeyboard())

        val appCompatEditText7 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("15"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText7.perform(pressImeActionButton())

        val appCompatEditText8 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("14"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText8.perform(replaceText("7"))

        val appCompatEditText9 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("7"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText9.perform(closeSoftKeyboard())

        val appCompatEditText10 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("7"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText10.perform(pressImeActionButton())

        val appCompatEditText11 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.0"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText11.perform(replaceText("0.2"))

        val appCompatEditText12 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText12.perform(closeSoftKeyboard())

        val appCompatEditText13 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText13.perform(pressImeActionButton())

        val appCompatButton = onView(
            allOf(
                withId(R.id.SaveButton), withText("Save"),
                childAtPosition(
                    allOf(
                        withId(R.id.FlowerLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        appCompatButton.perform(click())

        val textInputEditText = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText.perform(click())

        val textInputEditText2 = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText2.perform(replaceText("F"), closeSoftKeyboard())

        val appCompatButton2 = onView(
            allOf(
                withId(R.id.saveDialogButtonAccept), withText("OK"),
                childAtPosition(
                    allOf(
                        withId(R.id.saveDialogButtonContainer),
                        childAtPosition(
                            withId(R.id.saveDialogElementContainer),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton2.perform(click())

        val appCompatImageButton = onView(
            allOf(
                withContentDescription("Open navigation drawer"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withClassName(`is`("com.google.android.material.appbar.AppBarLayout")),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton.perform(click())

        val navigationMenuItemView = onView(
            allOf(
                childAtPosition(
                    allOf(
                        withId(R.id.design_navigation_view),
                        childAtPosition(
                            withId(R.id.nav_view),
                            0
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        navigationMenuItemView.perform(click())

        val imageButton = onView(
            allOf(
                withId(R.id.libraryEntryImageButtonEdit),
                childAtPosition(
                    allOf(
                        withId(R.id.library_entry_layout),
                        childAtPosition(
                            withClassName(`is`("com.oktopoi.library.LibraryEntryView")),
                            0
                        )
                    ),
                    2
                )
            )
        )
        imageButton.perform(scrollTo(), click())

        val textInputEditText3 = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText3.perform(click())

        val textInputEditText4 = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText4.perform(replaceText("Flower"), closeSoftKeyboard())

        val appCompatButton3 = onView(
            allOf(
                withId(R.id.saveDialogButtonAccept), withText("OK"),
                childAtPosition(
                    allOf(
                        withId(R.id.saveDialogButtonContainer),
                        childAtPosition(
                            withId(R.id.saveDialogElementContainer),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton3.perform(click())

        val appCompatCheckBox = onView(
            allOf(
                withId(R.id.flower_check_box), withText("Flowers"),
                childAtPosition(
                    allOf(
                        withId(R.id.LibraryLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatCheckBox.perform(click())

        val appCompatCheckBox2 = onView(
            allOf(
                withId(R.id.flower_check_box), withText("Flowers"),
                childAtPosition(
                    allOf(
                        withId(R.id.LibraryLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatCheckBox2.perform(click())

        val textView = onView(
            allOf(
                withId(R.id.libraryEntryTextView), withText("Flower"),
                childAtPosition(
                    allOf(
                        withId(R.id.library_entry_layout),
                        childAtPosition(
                            withClassName(`is`("com.oktopoi.library.LibraryEntryView")),
                            0
                        )
                    ),
                    1
                )
            )
        )
        textView.perform(scrollTo(), click())

        val appCompatImageButton2 = onView(
            allOf(
                withContentDescription("Open navigation drawer"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withClassName(`is`("com.google.android.material.appbar.AppBarLayout")),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton2.perform(click())

        val navigationMenuItemView2 = onView(
            allOf(
                childAtPosition(
                    allOf(
                        withId(R.id.design_navigation_view),
                        childAtPosition(
                            withId(R.id.nav_view),
                            0
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        navigationMenuItemView2.perform(click())

        // Added a sleep statement to match the app's execution delay.
        // The recommended way to handle such scenarios is to use Espresso idling resources:
        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
        Thread.sleep(160)

        val imageButton2 = onView(
            allOf(
                withId(R.id.libraryEntryImageButtonDelete),
                childAtPosition(
                    allOf(
                        withId(R.id.library_entry_layout),
                        childAtPosition(
                            withClassName(`is`("com.oktopoi.library.LibraryEntryView")),
                            0
                        )
                    ),
                    3
                )
            )
        )
        imageButton2.perform(scrollTo(), click())

        val appCompatButton4 = onView(
            allOf(
                withId(R.id.alertDialogButtonAccept), withText("OK"),
                childAtPosition(
                    allOf(
                        withId(R.id.alertDialogButtonContainer),
                        childAtPosition(
                            withId(R.id.alertDialogElementContainer),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton4.perform(click())

        val appCompatImageButton3 = onView(
            allOf(
                withContentDescription("Open navigation drawer"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withClassName(`is`("com.google.android.material.appbar.AppBarLayout")),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton3.perform(click())

        val navigationMenuItemView3 = onView(
            allOf(
                childAtPosition(
                    allOf(
                        withId(R.id.design_navigation_view),
                        childAtPosition(
                            withId(R.id.nav_view),
                            0
                        )
                    ),
                    2
                ),
                isDisplayed()
            )
        )
        navigationMenuItemView3.perform(click())

        /*val appCompatButton5 = onView(
            allOf(
                withId(R.id.DrawClearButton), withText("clear"),
                childAtPosition(
                    allOf(
                        withId(R.id.DrawButtonContainer),
                        childAtPosition(
                            withId(R.id.FlowerLayoutParent),
                            1
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton5.perform(click())*/

        val appCompatButton6 = onView(
            allOf(
                withId(R.id.DrawCalculateButton), withText("save"),
                childAtPosition(
                    allOf(
                        withId(R.id.DrawButtonContainer),
                        childAtPosition(
                            withId(R.id.FlowerLayoutParent),
                            1
                        )
                    ),
                    2
                ),
                isDisplayed()
            )
        )
        appCompatButton6.perform(click())

        val textInputEditText5 = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText5.perform(click())

        val textInputEditText6 = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText6.perform(replaceText("D"), closeSoftKeyboard())

        val appCompatButton7 = onView(
            allOf(
                withId(R.id.saveDialogButtonAccept), withText("OK"),
                childAtPosition(
                    allOf(
                        withId(R.id.saveDialogButtonContainer),
                        childAtPosition(
                            withId(R.id.saveDialogElementContainer),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton7.perform(click())

        val appCompatImageButton4 = onView(
            allOf(
                withContentDescription("Open navigation drawer"),
                childAtPosition(
                    allOf(
                        withId(R.id.toolbar),
                        childAtPosition(
                            withClassName(`is`("com.google.android.material.appbar.AppBarLayout")),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageButton4.perform(click())

        val navigationMenuItemView4 = onView(
            allOf(
                childAtPosition(
                    allOf(
                        withId(R.id.design_navigation_view),
                        childAtPosition(
                            withId(R.id.nav_view),
                            0
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        navigationMenuItemView4.perform(click())

        val imageButton3 = onView(
            allOf(
                withId(R.id.libraryEntryImageButtonEdit),
                childAtPosition(
                    allOf(
                        withId(R.id.library_entry_layout),
                        childAtPosition(
                            withClassName(`is`("com.oktopoi.library.LibraryEntryView")),
                            0
                        )
                    ),
                    2
                )
            )
        )
        imageButton3.perform(scrollTo(), click())

        val textInputEditText7 = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText7.perform(click())

        val textInputEditText8 = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText8.perform(replaceText("Drawing"), closeSoftKeyboard())

        val appCompatButton8 = onView(
            allOf(
                withId(R.id.saveDialogButtonAccept), withText("OK"),
                childAtPosition(
                    allOf(
                        withId(R.id.saveDialogButtonContainer),
                        childAtPosition(
                            withId(R.id.saveDialogElementContainer),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton8.perform(click())

        val appCompatCheckBox3 = onView(
            allOf(
                withId(R.id.touch_pad_check_box), withText("Touchpad Curves"),
                childAtPosition(
                    allOf(
                        withId(R.id.LibraryLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatCheckBox3.perform(click())

        val appCompatCheckBox4 = onView(
            allOf(
                withId(R.id.touch_pad_check_box), withText("Touchpad Curves"),
                childAtPosition(
                    allOf(
                        withId(R.id.LibraryLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatCheckBox4.perform(click())

        // Added a sleep statement to match the app's execution delay.
        // The recommended way to handle such scenarios is to use Espresso idling resources:
        // https://google.github.io/android-testing-support-library/docs/espresso/idling-resource/index.html
        Thread.sleep(160)

        val imageButton4 = onView(
            allOf(
                withId(R.id.libraryEntryImageButtonDelete),
                childAtPosition(
                    allOf(
                        withId(R.id.library_entry_layout),
                        childAtPosition(
                            withClassName(`is`("com.oktopoi.library.LibraryEntryView")),
                            0
                        )
                    ),
                    3
                )
            )
        )
        imageButton4.perform(scrollTo(), click())

        val appCompatButton9 = onView(
            allOf(
                withId(R.id.alertDialogButtonAccept), withText("OK"),
                childAtPosition(
                    allOf(
                        withId(R.id.alertDialogButtonContainer),
                        childAtPosition(
                            withId(R.id.alertDialogElementContainer),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton9.perform(click())
    }

    private fun childAtPosition(
        parentMatcher: Matcher<View>, position: Int
    ): Matcher<View> {

        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
                description.appendText("Child at position $position in parent ")
                parentMatcher.describeTo(description)
            }

            public override fun matchesSafely(view: View): Boolean {
                val parent = view.parent
                return parent is ViewGroup && parentMatcher.matches(parent)
                        && view == parent.getChildAt(position)
            }
        }
    }
}
