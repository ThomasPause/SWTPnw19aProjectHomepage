package com.oktopoi

import android.view.View
import android.view.ViewGroup
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.filters.LargeTest
import androidx.test.internal.runner.junit4.AndroidJUnit4ClassRunner
import androidx.test.rule.ActivityTestRule
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers.allOf
import org.hamcrest.TypeSafeMatcher
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/*
agenda of FlowersTest
start app
check if radius is 0.5
change radius to 1.5
press ok
check if freq1 is 2
change freq1 to 8
press ok
check if freq2 is 14
change freq2 to 10
press ok
check if offset is 0.0
change offset to 0.75
press ok
activate ‘show hand’ by switch
click ‘save’
type in ‘test’
press ok
*/

@LargeTest
@RunWith(AndroidJUnit4ClassRunner::class)
class FlowersTest {

    @Rule
    @JvmField
    var mActivityTestRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun flowersTest() {
        val editText = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("0.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        editText.check(matches(withText("0.5")))

        val appCompatEditText = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("0.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText.perform(click())

        val appCompatEditText2 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("0.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText2.perform(replaceText("1.5"))

        val appCompatEditText3 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("1.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText3.perform(closeSoftKeyboard())

        val appCompatEditText4 = onView(
            allOf(
                withId(R.id.TextInputRadius), withText("1.5"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputRadiusLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText4.perform(pressImeActionButton())

        val editText2 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        editText2.check(matches(withText("2")))

        val appCompatEditText5 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("2"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText5.perform(replaceText("8"))

        val appCompatEditText6 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("8"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText6.perform(closeSoftKeyboard())

        val appCompatEditText7 = onView(
            allOf(
                withId(R.id.TextInputFreq1), withText("8"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq1Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText7.perform(pressImeActionButton())

        val editText3 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("14"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        editText3.check(matches(withText("14")))

        val appCompatEditText8 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("14"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText8.perform(replaceText("10"))

        val appCompatEditText9 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("10"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText9.perform(closeSoftKeyboard())

        val appCompatEditText10 = onView(
            allOf(
                withId(R.id.TextInputFreq2), withText("10"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputFreq2Layout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText10.perform(pressImeActionButton())

        val editText4 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.0"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        editText4.check(matches(withText("0.0")))

        val appCompatEditText11 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.0"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText11.perform(replaceText("0.75"))

        val appCompatEditText12 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.75"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText12.perform(closeSoftKeyboard())

        val appCompatEditText13 = onView(
            allOf(
                withId(R.id.TextInputOffset), withText("0.75"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.TextInputOffsetLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatEditText13.perform(pressImeActionButton())

        val switch = onView(
            allOf(
                withId(R.id.SwitchShowHand),
                childAtPosition(
                    allOf(
                        withId(R.id.HandSwitchContainer),
                        childAtPosition(
                            withId(R.id.FlowerLayoutParent),
                            1
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        switch.perform(click())

        val appCompatButton = onView(
            allOf(
                withId(R.id.SaveButton), withText("Save"),
                childAtPosition(
                    allOf(
                        withId(R.id.FlowerLayoutParent),
                        childAtPosition(
                            withId(R.id.nav_host_fragment),
                            0
                        )
                    ),
                    3
                ),
                isDisplayed()
            )
        )
        appCompatButton.perform(click())

        val textInputEditText = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText.perform(click())

        val textInputEditText2 = onView(
            allOf(
                withId(R.id.saveDialogEditText),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.saveDialogEditTextLayout),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText2.perform(replaceText("test"), closeSoftKeyboard())

        val appCompatButton2 = onView(
            allOf(
                withId(R.id.saveDialogButtonAccept), withText("OK"),
                childAtPosition(
                    allOf(
                        withId(R.id.saveDialogButtonContainer),
                        childAtPosition(
                            withId(R.id.saveDialogElementContainer),
                            2
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatButton2.perform(click())
    }

    private fun childAtPosition(
        parentMatcher: Matcher<View>, position: Int
    ): Matcher<View> {

        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
                description.appendText("Child at position $position in parent ")
                parentMatcher.describeTo(description)
            }

            public override fun matchesSafely(view: View): Boolean {
                val parent = view.parent
                return parent is ViewGroup && parentMatcher.matches(parent)
                        && view == parent.getChildAt(position)
            }
        }
    }
}
