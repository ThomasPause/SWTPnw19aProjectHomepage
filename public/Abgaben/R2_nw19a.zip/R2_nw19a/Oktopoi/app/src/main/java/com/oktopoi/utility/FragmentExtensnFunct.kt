package com.oktopoi.utility

import android.app.AlertDialog
import androidx.fragment.app.Fragment

/**
These Extension Functions can be called in a Fragment directly
 **/

/**
 * makeEditTextDialog provides a custom dialog with a EditText-View and methods to get
 * User-Input from the Dialog
 *
 * @param func functions of the EditTextDialog-class that can be passed
 * @return instance of EditTextDialog
 */

inline fun Fragment.makeEditTextDialog(func: EditTextDialog.() -> Unit): AlertDialog =
    EditTextDialog(this.context!!).apply {
        func()
    }.create()

/**
 * makeSimpleAlertDialog provides a custom alertDialog
 *
 * @param func functions of the SimpleAlertDialog-class that can be passed
 * @return instance of SimpleAlertDialog
 */

inline fun Fragment.makeSimpleAlertDialog(func: SimpleAlertDialog.() -> Unit): AlertDialog =
    SimpleAlertDialog(this.context!!).apply {
        func()
    }.create()

/**
 *  showToast shows a toast with the message within the given context
 *
 * @param message a String containing the message to Toast is supposed to show
 */

fun Fragment.showToast(message: String) =
    android.widget.Toast.makeText(this.context, message, android.widget.Toast.LENGTH_SHORT).show()
