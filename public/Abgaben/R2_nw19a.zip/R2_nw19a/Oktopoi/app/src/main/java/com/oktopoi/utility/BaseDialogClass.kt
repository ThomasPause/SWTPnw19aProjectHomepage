package com.oktopoi.utility

import android.app.AlertDialog
import android.view.View

/**
 * BaseDialogClass is the parent class for all custom dialogs.
 * It provides a AlertDialog.Builder and implements a function to return a dialog.
 *
 * @property dialogView a View that will be inflated with a layout and set to the dialog via the
 * builder
 * @property builder c
 * @property dialog the created dialog
 */

abstract class BaseDialogClass {

    abstract val dialogView: View
    abstract val builder: AlertDialog.Builder

    open var dialog: AlertDialog? = null

    /**
     * Simple Method to create an AlertDialog
     *
     * @return AlertDialog from builder
     */

    open fun create(): AlertDialog {
        dialog = builder
            .create()

        return dialog!!
    }
}