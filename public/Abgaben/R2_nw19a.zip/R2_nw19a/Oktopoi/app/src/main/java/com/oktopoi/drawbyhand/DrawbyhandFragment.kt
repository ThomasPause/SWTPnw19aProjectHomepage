package com.oktopoi.drawbyhand

import android.annotation.SuppressLint
import android.os.Bundle
import android.text.InputType
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.navArgs
import com.oktopoi.MainActivity
import com.oktopoi.R
import com.oktopoi.library.*
import com.oktopoi.utility.makeEditTextDialog
import com.oktopoi.utility.showToast
import kotlinx.android.synthetic.main.layout_drawbyhand_fragment.*


/**
 * This class allows the user to draw different closed figures with a touch pad, to clear the drawing
 * and eventually to calculate the figure
 *
 * @property isLocked tells if the touchpad input is locked, default value is 'false'
 */

class DrawbyhandFragment : Fragment(R.layout.layout_drawbyhand_fragment) {

    private val args: DrawbyhandFragmentArgs by navArgs()
    private var isLocked = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        //Set title bar text
        (activity as MainActivity).supportActionBar?.title =
            resources.getString(R.string.menu_drawbyhand)

        return super.onCreateView(inflater, container, savedInstanceState)
    }

    @SuppressLint("ClickableViewAccessibility")
//    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
//        super.onViewCreated(view, savedInstanceState)
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        //paintView is instantiated
        val paintView = PaintView(context!!)

        /*
        DrawPaintView is just a linear layout defined within the layout xml-file, so
        paintView with all its contents is added to DrawPaintView
         */
        DrawPaintView.addView(paintView)

        /*
        1. DrawClearButton: attach onClickListener which clears the drawing and unlocks the touchpad
        input

        2. DrawCalculateButton: attach onClickListener which eventually returns the point list of the
        sampled path from the drawing
         */
        DrawClearButton.setOnClickListener {
            paintView.onClear()
            isLocked = false
        }

        DrawCalculateButton.apply {
            setOnClickListener {
                val saveDialog = makeEditTextDialog {
                    setTitle(context.resources.getString(R.string.hint_save_as_dialog))
                    eText.inputType = InputType.TYPE_CLASS_TEXT
                    positiveButtonClickListener {
                        val title = getInput().toString()
                        val fileHandler = FileHandler(context, LibraryFragment.directory)

                        val pointsList = paintView.onCalculate()
                        val data = Converter.pointsToString(pointsList)

                        if (fileHandler.fileExists("$title${FileFormatStrings[FileFormat.TouchPad]}")) {
                            showToast(context.resources.getString(R.string.file_name_taken))
                        } else if (!fileHandler.isValidFileName(title)) {
                            showToast(context.resources.getString(R.string.invalid_file_name))
                        } else if (fileHandler.writeFile(
                                "$title${FileFormatStrings[FileFormat.TouchPad]}",
                                data
                            )
                        ) {
                            showToast(
                                context.resources.getString(
                                    R.string.successfully_saved_file,
                                    title
                                )
                            )
                        } else {
                            showToast(context.resources.getString(R.string.failed_to_save_file))
                        }
                    }
                    negativeButtonClickListener {}
                }
                saveDialog.show()
            }

            if (args.inputCurveData != "emptyString") {
                println("We got this: ${args.inputCurveData}!!!!!!!!!!!!!")
                val data = args.inputCurveData.split('\n')

                paintView.onActionDown(
                    data.first().split(" ").first().toFloatOrNull()!!,
                    data.first().split(" ").last().toFloatOrNull()!!
                )
                for (line in data) {

                    if (line.isEmpty())
                        continue

                    println("Line: $line")
                    paintView.onActionDrag(
                        line.split(" ").first().toFloatOrNull()!!,
                        line.split(" ").last().toFloatOrNull()!!
                    )
                }
                paintView.onActionUp()
                isLocked = true
            }
        }


        //attach onTouchListener which allows the user to draw if the touchpad is not locked
        paintView.setOnTouchListener { _, event ->
            val posX = event.x
            val posY = event.y

            // only 'false' if you start this fragment for the first time or if you press 'clear'
            if (!isLocked) {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> paintView.onActionDown(posX, posY)
                    MotionEvent.ACTION_MOVE -> paintView.onActionDrag(posX, posY)
                    MotionEvent.ACTION_UP -> {
                        //after closing the path, you can't draw again until you press 'clear'
                        paintView.onActionUp()
                        isLocked = true
                    }
                }
            }
            true
        }
    }
}
