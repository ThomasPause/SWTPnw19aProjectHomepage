package com.oktopoi.library

import com.oktopoi.flowers.FlowersCalc

/**
 * this object provides methods for converting objects into strings that can be written in a file
 * and reconvert them
 */
object Converter {

    /*redundant method: flowersCalc.toString does the same
    fun flowerToString(flower: FlowersCalc): String {
        return "${flower.radius} ${flower.freq1} ${flower.freq2} ${flower.offset}"
    }*/

    /**
     * string to flower takes a string that contains information about radius, freq1, freq2 and offset
     * to create a flowersCalc object
     * if the input string doesn't have the right format it will throw an exception
     *
     * @param param string that contains flower parameters
     * @return a FlowersCalc object with the parameters read from the string
     */
    @Throws(Exception::class)
    fun stringToFlower(param: String): FlowersCalc {

        val paramArray = param.split(" ")
        if (paramArray.size != 4) {
            throw Exception("wrong number of parameters")
        }

        val radius =
            paramArray[0].toFloatOrNull() ?: throw Exception("no valid radius in this string")
        if (radius > 3) {
            throw Exception("radius should not be bigger than 3")
        }
        if (radius < 0) {
            throw Exception("radius should not be smaller than 0")
        }

        val freq1 = paramArray[1].toIntOrNull() ?: throw Exception("no valid freq1 in this string")
        val freq2 = paramArray[2].toIntOrNull() ?: throw Exception("no valid freq2 in this string")
        val offset =
            paramArray[3].toFloatOrNull() ?: throw Exception("no valid offset in this string")

        return FlowersCalc(radius, freq1, freq2, offset, 720)
    }

    /**
     * this method takes a list of points (x and y coordinates) and returns a string
     * x and y coordinate are separated by space, points by new line
     *
     * @param points list of points (Float Pairs)
     * @return string that contains information about all points in the list
     */
    fun pointsToString(points: List<Pair<Float, Float>>): String {
        val result = StringBuilder()
        for (point in points) {
            result.append("${point.first} ${point.second}\n")
        }
        return result.toString()
    }

    /**
     * this method converts a string to a list of points (Float pairs)
     * the string should have string representations of two float numbers in each line
     * if the string doesn't have the right format it will throw an exception
     *
     * @param string that contains information about all points
     * @return a list of Float pairs that represent coordinates of points
     */
    @Throws(Exception::class)
    fun stringToPoints(string: String): List<Pair<Float, Float>> {

        var result = mutableListOf<Pair<Float, Float>>()
        var coordinates: List<String>
        var x: Float?
        var y: Float?

        val pointArray = string.split("\n")

        for (point in pointArray) {

            coordinates = point.split(" ")
            if (coordinates.size != 2) throw Exception("not 2 strings in this line")

            x = coordinates[0].toFloatOrNull()
            if (x == null) throw Exception("invalid x coordinate")

            y = coordinates[1].toFloatOrNull()
            if (y == null) throw Exception("invalid y coordinate")

            result.add(Pair(x, y))
        }

        return result

    }
}